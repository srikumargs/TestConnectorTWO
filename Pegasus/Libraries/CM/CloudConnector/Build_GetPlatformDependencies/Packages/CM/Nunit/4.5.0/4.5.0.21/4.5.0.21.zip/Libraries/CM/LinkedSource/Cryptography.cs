using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.IO;

#if !NO_SAGE_DIAGNOSTICS_REFERENCE
using Sage.Diagnostics;
#endif

// This source file resides in the "LinkedSource" source code folder in order to enable multiple assemblies
// to shared the implementation without requiring the Cryptography class to be exposed as a public
// type of any shared assembly.
//
// Requires:
//  - Sage.CRE.Core.dll (unless NO_SAGE_DIAGNOSTICS_REFERENCE is defined)
namespace Sage.CRE.LinkedSource
{
    /// <summary>
    /// The supported symmetric algorithms used by the Cryptography class.
    /// </summary>
    internal enum CryptoAlgorithm
    {
        /// <summary>
        /// There is no crypto algorithm
        /// </summary>
        /// <remarks>
        /// This is default value the runtime automatically initializes any CryptoAlgorithm instance to
        /// </remarks>
        None = 0,

        /// <summary>
        /// DES encryption. [Defaults: IV=8, Key=8]
        /// </summary>
        DES = 1,

        /// <summary>
        /// RC2 encryption. [Defaults: IV=8, Key=16]
        /// </summary>
        RC2 = 2,

        /// <summary>
        /// Rijndael encryption. [Defaults: IV=16, Key=32]
        /// </summary>
        Rijndael = 3,

        /// <summary>
        /// Triple-DES encryption. [Defaults: IV=8, Key=24]
        /// </summary>
        TripleDES = 4
    };

    /// <summary>
    /// 
    /// </summary>
    internal static class CryptoAlgorithmName
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static String None
        { get { return String.Empty; } }

        public static String DES
        { get { return typeof(System.Security.Cryptography.DES).Name; } }

        public static String RC2
        { get { return typeof(System.Security.Cryptography.RC2).Name; } }

        public static String Rijndael
        { get { return typeof(System.Security.Cryptography.Rijndael).Name; } }

        public static String TripleDES
        { get { return typeof(System.Security.Cryptography.TripleDES).Name; } }
    }

    /// <summary>
    /// Class used to provide cryptography services.
    /// </summary>
    internal sealed class Cryptography
    {
        public Cryptography(CryptoAlgorithm cryptoAlgorithm)
        {
            _cryptoAlgorithm = cryptoAlgorithm;
            _symmetricAlgorithm = SymmetricAlgorithm.Create(GetCryptoAlgorithmName(_cryptoAlgorithm));
        }

        /// <summary>
        /// Get a Key for the corresponding CryptoAlgorithm.
        /// </summary>
        /// <returns>Returns the key byte array.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Byte[] Key
        { get { return _symmetricAlgorithm.Key; } }

        /// <summary>
        /// Get an IV for the corresponding CryptoAlgorithm.
        /// </summary>
        /// <returns>Returns the IV byte array.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Byte[] IV
        { get { return _symmetricAlgorithm.IV; } }

        /// <summary>
        /// Get the secret key block size, in bytes, for the corresponding CryptoAlgorithm.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Int32 KeyLength
        {
            get
            {
                Int32 result = 0;

                foreach (KeySizes keySizes in _symmetricAlgorithm.LegalKeySizes)
                {
                    if (result == 0 || keySizes.MaxSize > result)
                    {
                        result = keySizes.MaxSize;
                    }
                }

                result /= 8;

                return result;
            }
        }

        /// <summary>
        /// Get the mandatory IV length, in bytes, for the corresponding CryptoAlgorithm.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Int32 IVLength
        { get { return (_symmetricAlgorithm.BlockSize / 8); } }

        /// <summary>
        /// Encrypt a stream; use the specified initialization vector
        /// </summary>
        /// <param name="unEncryptedStream">The stream to encrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>An encrypted stream</returns>
        public MemoryStream EncryptStream(Stream unEncryptedStream, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(unEncryptedStream, "unEncryptedStream", typeof(Cryptography).FullName);
#endif

            _symmetricAlgorithm.Key = key;
            _symmetricAlgorithm.IV = iv;

            return TransformStream(unEncryptedStream, _symmetricAlgorithm.CreateEncryptor());
        }

        /// <summary>
        /// Encrypt a stream; generate the initialization vector and return it
        /// </summary>
        /// <param name="unEncryptedStream">The stream to encrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <returns>An encrypted stream</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public MemoryStream EncryptStream(Stream unEncryptedStream, Byte[] key, out Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(unEncryptedStream, "unEncryptedStream", typeof(Cryptography).FullName);
#endif

            iv = null;

            _symmetricAlgorithm.Key = key;
            _symmetricAlgorithm.GenerateIV();
            iv = _symmetricAlgorithm.IV;

            return EncryptStream(unEncryptedStream, key, iv);
        }

        /// <summary>
        /// Encrypt a string; use the specified initialization vector
        /// </summary>
        /// <param name="unEncryptedString">The string to encrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>An encrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public String EncryptString(String unEncryptedString, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonEmptyString(unEncryptedString, "unEncryptedString", typeof(Cryptography).FullName);
#endif

            return GetBase64StringFromBytes(EncryptStringToBytes(unEncryptedString, key, iv));
        }

        /// <summary>
        /// Encrypt a string; generate the initialization vector and return it
        /// </summary>
        /// <param name="unEncryptedString">The string to encrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <returns>An encrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public String EncryptString(String unEncryptedString, Byte[] key, out Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonEmptyString(unEncryptedString, "unEncryptedString", typeof(Cryptography).FullName);
#endif

            return GetBase64StringFromBytes(EncryptStringToBytes(unEncryptedString, key, out iv));
        }

        /// <summary>
        /// Encrypt a string; use the specified initialization vector
        /// </summary>
        /// <param name="unEncryptedString">The string to encrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>A byte array representation of the encrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Byte[] EncryptStringToBytes(String unEncryptedString, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonEmptyString(unEncryptedString, "unEncryptedString", typeof(Cryptography).FullName);
#endif

            return EncryptBytes(GetBytesFromString(unEncryptedString), key, iv);
        }

        /// <summary>
        /// Encrypt a string; generate the initialization vector and return it
        /// </summary>
        /// <param name="unEncryptedString">The string to encrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <returns>A byte array representation of the encrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Byte[] EncryptStringToBytes(String unEncryptedString, Byte[] key, out Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonEmptyString(unEncryptedString, "unEncryptedString", typeof(Cryptography).FullName);
#endif

            return EncryptBytes(GetBytesFromString(unEncryptedString), key, out iv);
        }

        /// <summary>
        /// Encrypt a set of bytes; use the specified initialization vector
        /// </summary>
        /// <param name="unEncryptedBytes">The bytes to encrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>An encrypted set of bytes</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Byte[] EncryptBytes(Byte[] unEncryptedBytes, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(unEncryptedBytes, "unEncryptedBytes", typeof(Cryptography).FullName);
#endif

            _symmetricAlgorithm.Key = key;
            _symmetricAlgorithm.IV = iv;

            return _symmetricAlgorithm.CreateEncryptor().TransformFinalBlock(unEncryptedBytes, 0, unEncryptedBytes.GetLength(0));
        }

        /// <summary>
        /// Encrypt a set of bytes; generate the initialization vector and return it
        /// </summary>
        /// <param name="unEncryptedBytes">The bytes to encrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <returns>An encrypted set of bytes</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Byte[] EncryptBytes(Byte[] unEncryptedBytes, Byte[] key, out Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(unEncryptedBytes, "unEncryptedBytes", typeof(Cryptography).FullName);
#endif

            iv = null;

            _symmetricAlgorithm.Key = key;
            _symmetricAlgorithm.GenerateIV();
            iv = _symmetricAlgorithm.IV;

            return EncryptBytes(unEncryptedBytes, key, iv);
        }

        /// <summary>
        /// Decrypt a stream
        /// </summary>
        /// <param name="encryptedStream">The stream to decrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>A decrypted stream</returns>
        public MemoryStream DecryptStream(Stream encryptedStream, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(encryptedStream, "encryptedStream", typeof(Cryptography).FullName);
#endif

            _symmetricAlgorithm.Key = key;
            _symmetricAlgorithm.IV = iv;

            return TransformStream(encryptedStream, _symmetricAlgorithm.CreateDecryptor());
        }

        /// <summary>
        /// Decrypt a string
        /// </summary>
        /// <param name="encryptedString">The string to decrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>The decrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public String DecryptString(String encryptedString, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonEmptyString(encryptedString, "encryptedString", typeof(Cryptography).FullName);
#endif

            return GetStringFromBytes(DecryptBytes(GetBytesFromBase64String(encryptedString), key, iv));
        }

        /// <summary>
        /// Decrypt a set of bytes
        /// </summary>
        /// <param name="encryptedBytes">The bytes to decrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>A string representation of the decrypted bytes</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public String DecryptBytesToString(Byte[] encryptedBytes, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(encryptedBytes, "encryptedBytes", typeof(Cryptography).FullName);
#endif

            return GetStringFromBytes(DecryptBytes(encryptedBytes, key, iv));
        }

        /// <summary>
        /// Decrypt a set of bytes
        /// </summary>
        /// <param name="encryptedBytes">The bytes to decrypt</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>A decrypted set of bytes</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public Byte[] DecryptBytes(Byte[] encryptedBytes, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(encryptedBytes, "encryptedBytes", typeof(Cryptography).FullName);
#endif

            _symmetricAlgorithm.Key = key;
            _symmetricAlgorithm.IV = iv;

            return _symmetricAlgorithm.CreateDecryptor().TransformFinalBlock(encryptedBytes, 0, encryptedBytes.GetLength(0));
        }

        /// <summary>
        /// Get a Key for the corresponding CryptoAlgorithm.
        /// </summary>
        /// <returns>Returns the key byte array.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Byte[] GetKey(CryptoAlgorithm cryptoAlgorithm)
        { return (new Cryptography(cryptoAlgorithm).Key); }

        /// <summary>
        /// Get an IV for the corresponding CryptoAlgorithm.
        /// </summary>
        /// <returns>Returns the IV byte array.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Byte[] GetIV(CryptoAlgorithm cryptoAlgorithm)
        { return (new Cryptography(cryptoAlgorithm).IV); }

        /// <summary>
        /// Get the secret key block size, in bytes, for the corresponding CryptoAlgorithm.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Int32 GetKeyLength(CryptoAlgorithm cryptoAlgorithm)
        { return (new Cryptography(cryptoAlgorithm).KeyLength); }

        /// <summary>
        /// Get the mandatory IV length, in bytes, for the corresponding CryptoAlgorithm.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Int32 GetIVLength(CryptoAlgorithm cryptoAlgorithm)
        { return (new Cryptography(cryptoAlgorithm).IVLength); }

        /// <summary>
        /// Encrypt a stream; use the specified initialization vector
        /// </summary>
        /// <param name="unEncryptedStream">The stream to encrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>An encrypted stream</returns>
        public static MemoryStream EncryptStream(Stream unEncryptedStream, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).EncryptStream(unEncryptedStream, key, iv)); }

        /// <summary>
        /// Encrypt a stream; generate the initialization vector and return it
        /// </summary>
        /// <param name="unEncryptedStream">The stream to encrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <returns>An encrypted stream</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static MemoryStream EncryptStream(Stream unEncryptedStream, CryptoAlgorithm cryptoAlgorithm, Byte[] key, out Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).EncryptStream(unEncryptedStream, key, out iv)); }

        /// <summary>
        /// Encrypt a string; use the specified initialization vector
        /// </summary>
        /// <param name="unEncryptedString">The string to encrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>An encrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static String EncryptString(String unEncryptedString, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).EncryptString(unEncryptedString, key, iv)); }

        /// <summary>
        /// Encrypt a string; generate the initialization vector and return it
        /// </summary>
        /// <param name="unEncryptedString">The string to encrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <returns>An encrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static String EncryptString(String unEncryptedString, CryptoAlgorithm cryptoAlgorithm, Byte[] key, out Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).EncryptString(unEncryptedString, key, out iv)); }

        /// <summary>
        /// Encrypt a string; use the specified initialization vector
        /// </summary>
        /// <param name="unEncryptedString">The string to encrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>A byte array representation of the encrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Byte[] EncryptStringToBytes(String unEncryptedString, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).EncryptStringToBytes(unEncryptedString, key, iv)); }

        /// <summary>
        /// Encrypt a string; generate the initialization vector and return it
        /// </summary>
        /// <param name="unEncryptedString">The string to encrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <returns>A byte array representation of the encrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Byte[] EncryptStringToBytes(String unEncryptedString, CryptoAlgorithm cryptoAlgorithm, Byte[] key, out Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).EncryptStringToBytes(unEncryptedString, key, out iv)); }

        /// <summary>
        /// Encrypt a set of bytes; use the specified initialization vector
        /// </summary>
        /// <param name="unEncryptedBytes">The bytes to encrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>An encrypted set of bytes</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Byte[] EncryptBytes(Byte[] unEncryptedBytes, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).EncryptBytes(unEncryptedBytes, key, iv)); }

        /// <summary>
        /// Encrypt a set of bytes; generate the initialization vector and return it
        /// </summary>
        /// <param name="unEncryptedBytes">The bytes to encrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The reference to the generated initialization vector for the symmetric algorithm used by this call</param>
        /// <returns>An encrypted set of bytes</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Byte[] EncryptBytes(Byte[] unEncryptedBytes, CryptoAlgorithm cryptoAlgorithm, Byte[] key, out Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).EncryptBytes(unEncryptedBytes, key, out iv)); }

        /// <summary>
        /// Decrypt a stream
        /// </summary>
        /// <param name="encryptedStream">The stream to decrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>A decrypted stream</returns>
        public static MemoryStream DecryptStream(Stream encryptedStream, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).DecryptStream(encryptedStream, key, iv)); }

        /// <summary>
        /// Decrypt a string
        /// </summary>
        /// <param name="encryptedString">The string to decrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>The decrypted string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static String DecryptString(String encryptedString, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).DecryptString(encryptedString, key, iv)); }

        /// <summary>
        /// Decrypt a set of bytes
        /// </summary>
        /// <param name="encryptedBytes">The bytes to decrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>A string representation of the decrypted bytes</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static String DecryptBytesToString(Byte[] encryptedBytes, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).DecryptBytesToString(encryptedBytes, key, iv)); }

        /// <summary>
        /// Decrypt a set of bytes
        /// </summary>
        /// <param name="encryptedBytes">The bytes to decrypt</param>
        /// <param name="cryptoAlgorithm">The symmetric cryptography algorithm to use</param>
        /// <param name="key">The secret key for the symmetric algorithm</param>
        /// <param name="iv">The initialization vector for the symmetric algorithm</param>
        /// <returns>A decrypted set of bytes</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static Byte[] DecryptBytes(Byte[] encryptedBytes, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        { return (new Cryptography(cryptoAlgorithm).DecryptBytes(encryptedBytes, key, iv)); }

        /// <summary>
        /// Returns the corresponding algorithm name for the specified CryptoAlgorithm.
        /// </summary>
        /// <param name="cryptoAlgorithm">The algorithm to return the name for</param>
        /// <returns>The name of crypto algorithm</returns>
        public static String GetCryptoAlgorithmName(CryptoAlgorithm cryptoAlgorithm)
        {
            String result = String.Empty;
            switch (cryptoAlgorithm)
            {
                case CryptoAlgorithm.DES:
                    result = CryptoAlgorithmName.DES;
                    break;

                case CryptoAlgorithm.RC2:
                    result = CryptoAlgorithmName.RC2;
                    break;

                case CryptoAlgorithm.Rijndael:
                    result = CryptoAlgorithmName.Rijndael;
                    break;

                case CryptoAlgorithm.TripleDES:
                    result = CryptoAlgorithmName.TripleDES;
                    break;

                default:
                    throw new ArgumentOutOfRangeException("cryptoAlgorithm");
            }
            return result;
        }

        /// <summary>
        /// Returns the corresponding CryptoAlgorithm for the specified algorithm name.
        /// </summary>
        /// <param name="cryptoAlgorithmName">The algorithm to return the name for</param>
        /// <returns>The name of crypto algorithm</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static CryptoAlgorithm GetCryptoAlgorithm(String cryptoAlgorithmName)
        {
            CryptoAlgorithm result = CryptoAlgorithm.None;

            if (cryptoAlgorithmName == CryptoAlgorithmName.DES)
            {
                result = CryptoAlgorithm.DES;
            }
            else if (cryptoAlgorithmName == CryptoAlgorithmName.RC2)
            {
                result = CryptoAlgorithm.RC2;
            }
            else if (cryptoAlgorithmName == CryptoAlgorithmName.Rijndael)
            {
                result = CryptoAlgorithm.Rijndael;
            }
            else if (cryptoAlgorithmName == CryptoAlgorithmName.TripleDES)
            {
                result = CryptoAlgorithm.TripleDES;
            }
            else
            {
                throw new ArgumentOutOfRangeException("cryptoAlgorithmName");
            }

            return result;
        }

        #region Private Methods
        /// <summary>
        /// Convert an array of bytes into a ASCII string
        /// </summary>
        /// <param name="inputBytes">The bytes to convert</param>
        /// <returns>A string that represents the input bytes</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private static String GetStringFromBytes(Byte[] inputBytes)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            Assertions.Assert(inputBytes != null);
#endif

            return Encoding.ASCII.GetString(inputBytes, 0, inputBytes.Length);
        }

        /// <summary>
        /// Convert a string into an array of bytes
        /// </summary>
        /// <param name="inputString">The string to convert</param>
        /// <returns>An array of bytes that represents the input string</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private static Byte[] GetBytesFromString(String inputString)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            Assertions.Assert(inputString != null && inputString.Length > 0);
#endif

            Byte[] bytes = new Byte[Encoding.ASCII.GetByteCount(inputString)];
            Encoding.ASCII.GetBytes(inputString.ToCharArray(), 0, inputString.Length, bytes, 0);

            return bytes;
        }

        /// <summary>
        /// Convert the supplied base-64 string into an equivalent 8-bit unsigned integer array 
        /// </summary>
        /// <param name="inputString">A string representation, encoded in base-64 digits.</param>
        /// <returns>An array of 8-bit unsigned integers equivalent to inputString.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private static Byte[] GetBytesFromBase64String(String inputString)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            Assertions.Assert(inputString != null && inputString.Length > 0);
#endif

            return Convert.FromBase64String(inputString);
        }

        /// <summary>
        /// Converts the supplied 8-bit unsigned integer array to an equivalent string representation encoded with base-64 digits.
        /// </summary>
        /// <param name="inputBytes">An array of 8-bit unsigned integers.</param>
        /// <returns>The String representation, in base 64, of the contents of inputBytes.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private static String GetBase64StringFromBytes(Byte[] inputBytes)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            Assertions.Assert(inputBytes != null);
#endif

            return Convert.ToBase64String(inputBytes);
        }

        /// <summary>
        /// Encrypts/decrypts the specified stream using the specfied ICryptoTransform
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="cryptoTransform"></param>
        /// <returns></returns>
        private static MemoryStream TransformStream(Stream stream, ICryptoTransform cryptoTransform)
        {
            MemoryStream tempResult = null;
            MemoryStream result = null;

            try
            {
                tempResult = new MemoryStream();
                CryptoStream cryptoStream = new CryptoStream(tempResult, cryptoTransform, CryptoStreamMode.Write);

                Byte[] buffer = new Byte[1024];
                Int32 count = stream.Read(buffer, 0, buffer.Length);
                while (count > 0)
                {
                    cryptoStream.Write(buffer, 0, count);
                    count = stream.Read(buffer, 0, buffer.Length);
                }
                cryptoStream.FlushFinalBlock();

                tempResult.Seek(0, SeekOrigin.Begin);
                result = tempResult; // using "temp result try/finally in factory method pattern" to get around CA2000: object 'result' is not disposed along all exception paths
                tempResult = null;
            }
            finally
            {
                if (tempResult != null)
                {
                    tempResult.Close();
                }
            }

            return result;
        }
        #endregion

        #region Private fields
        private readonly CryptoAlgorithm _cryptoAlgorithm;
        private readonly SymmetricAlgorithm _symmetricAlgorithm;
        #endregion
    }
}
