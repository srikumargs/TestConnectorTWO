#if DEBUG

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Diagnostics.CodeAnalysis;
using NUnit.Framework;

using Sage.Diagnostics;
using Sage.CRE.LinkedSource;

[assembly: SuppressMessage("Microsoft.Design", "CA1020:AvoidNamespacesWithFewTypes", Scope = "namespace", Target = "Sage.CRE.LinkedSource.NUnit.Tests")]
namespace Sage.CRE.LinkedSource.NUnit.Tests
{
    /// <summary>
    /// Class that provides unit tests for the Cryptography class
    /// </summary>
    [TestFixture]
    public class CryptographyTests
    {
        /// <summary>
        /// Test roundtrip encryption/decryption of some arbitrary string;  verify decrypted string matches original.
        /// </summary>
        [Test]
        public void EncryptDecryptString()
        {
            Cryptography cryptography = new Cryptography(CryptoAlgorithm.DES);
            Byte[] key = EncryptionKey;
            Byte[] iv = EncryptionIV;
            for(int i = 0 ; i < 10000 ; i++)
            {
                VerboseTrace.WriteLine(this, "EncryptDecryptString i={0}", i);

                StringBuilder originalTextStringBuilder = new StringBuilder(Random.Next(1, 0x7FFF));
                PopulateStringBuilder(originalTextStringBuilder, originalTextStringBuilder.Capacity);

                string originalText = originalTextStringBuilder.ToString();
                string cypherText = cryptography.EncryptString(originalText, key, iv);
                string clearText = cryptography.DecryptString(cypherText, key, iv);

                Assert.AreEqual(originalText, clearText);
            }
        }

        /// <summary>
        /// Test roundtrip encryption/decryption of some arbitrary bytes;  verify decrypted bytes matches original.
        /// </summary>
        [Test]
        public void EncryptDecryptBytes()
        {
            Cryptography cryptography = new Cryptography(CryptoAlgorithm.DES);
            Byte[] key = EncryptionKey;
            Byte[] iv = EncryptionIV;
            for (int i = 0; i < 10000; i++)
            {
                VerboseTrace.WriteLine(this, "EncryptDecryptBytes i={0}", i);

                byte[] originalBytes = new byte[Random.Next(1, 0x7FFF)];
                PopulateBytes(originalBytes, originalBytes.Length);

                byte[] cypherBytes = cryptography.EncryptBytes(originalBytes, key, iv);
                byte[] clearBytes = cryptography.DecryptBytes(cypherBytes, key, iv);

                Assert.AreEqual(originalBytes, clearBytes);
            }
        }

        /// <summary>
        /// Test roundtrip encryption/decryption of some arbitrary stream;  verify decrypted stream matches original.
        /// </summary>
        [Test]
        public void EncryptDecryptStream()
        {
            Cryptography cryptography = new Cryptography(CryptoAlgorithm.DES);
            Byte[] key = EncryptionKey;
            Byte[] iv = EncryptionIV;
            for (int i = 0; i < 10000; i++)
            {
                VerboseTrace.WriteLine(this, "EncryptDecryptStream i={0}", i);

                MemoryStream originalStream = new MemoryStream(Random.Next(1, 0x7FFF));
                PopulateStream(originalStream, (int)originalStream.Capacity);

                MemoryStream cypherStream = (MemoryStream)cryptography.EncryptStream(originalStream, key, iv);

                cypherStream.Seek(0, SeekOrigin.Begin);
                Stream clearStream = cryptography.DecryptStream(cypherStream, key, iv);

                byte[] clearStreamBuffer = new byte[originalStream.Capacity];
                for(int j = 0 ; j < clearStreamBuffer.Length ; j++)
                {
                    clearStreamBuffer[j] = (byte) clearStream.ReadByte();
                }
                Assert.AreEqual(originalStream.GetBuffer(), clearStreamBuffer);
            }
        }

#region Private properties
        private static System.Random Random
        {
            get
            {
                return _random;
            }
        }
#endregion

#region Private methods
        /// <summary>
        /// Retrieve the decryption key
        /// </summary>
        private static byte[] EncryptionKey
        {
            get
            {
                return new byte[] { 0xD, 0x20, 0x8A, 0xCF, 0x3D, 0xA5, 0xC, 0x98 };
            }
        }

        private static byte[] EncryptionIV
        {
            get
            {
                return new byte[] { 0x5C, 0x10, 0x6F, 0xB4, 0x18, 0x40, 0xD8, 0xEE };
            }
        }

        private static void PopulateStringBuilder(StringBuilder stringBuilder, int length)
        {
            for(int i = 0 ; i < length ; i++)
            {
                stringBuilder.Append(GetNextRandomAsciiChar());
            }
        }

        private static void PopulateBytes(byte[] bytes, int length)
        {
            for(int i = 0 ; i < length ; i++)
            {
                bytes[i] = GetNextRandomByte();
            }
        }

        private static void PopulateStream(MemoryStream stream, int length)
        {
            for(int i = 0 ; i < length ; i++)
            {
                stream.WriteByte(GetNextRandomByte());
            }

            stream.Seek(0, SeekOrigin.Begin);
        }

        private static char GetNextRandomAsciiChar()
        {
            return Convert.ToChar(Random.Next(0x00, 0x7F + 1));
        }

        private static byte GetNextRandomByte()
        {
            return Convert.ToByte(Random.Next(Byte.MinValue, Byte.MaxValue));
        }
#endregion

#region Private fields
        private static System.Random _random = new Random();
#endregion
    }
}

#endif