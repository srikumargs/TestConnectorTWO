﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Sage.CRE.HostingFramework.ServiceLibrary")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

[assembly: InternalsVisibleTo("Sage.CRE.HostingFramework.Test, PublicKey=0024000004800000940000000602000000240000525341310004000001000100339ebe8d4b54a0e8dc1043056c156f5b9e4dcde4c4ab25790e7739271bc2493b928b805359044b0a8b45532572e7d45cf7574fa723cdb69a2d256d906098e033feea97b5ab6318b671f1cffe23b1f07585cf6a45e67c64e080335881e9fd5819a618ab35f5740ea658c9b5d6981f02cc37c82fc36743687d0b070c0a137d18cb")]
