﻿namespace Sage.CRE.HostingFramework.Service.Internal
{
    public enum WindowsFirewallConfigurationResult
    {
        None = 0,

        Success,

        NoChangesRequired
    }
}
