using System;
using System.Runtime.InteropServices;
using System.ServiceModel;
using System.Threading;
using System.Windows.Forms;
using Sage.CRE.HostingFramework.Proxy;
using Sage.CRE.HostingFramework.Proxy.Advanced;
using Sage.CRE.HostingFramework.TestChatServiceInterfaces;
using Sage.CRE.HostingFramework.TestChatServiceProxy;
using Sage.CRE.HostingFramework.TestChatServiceProxy.Internal;

namespace Sage.CRE.HostingFramework.TestChatServiceClient
{
    [CallbackBehavior(UseSynchronizationContext = false)]
    public partial class MainForm : Form, IChatCallback
    {
        public MainForm(String server, String name)
            : this()
        {
            if (!String.IsNullOrEmpty(server))
            {
                _server = server;
            }
            if (!String.IsNullOrEmpty(name))
            {
                _name = name;
            }
        }

        public MainForm()
        {
            InitializeComponent();
            ShowConnectMenuItem(true);
        }

        private void connectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _chattersListBox.Items.Clear();
            NameForm nameForm = new NameForm();
            if (nameForm.ShowDialog() == DialogResult.OK)
            {
                _server = nameForm._serverTextBox.Text;
                _name = nameForm._nameTextBox.Text;
                nameForm.Close();
            }

            Connect();
        }

        private void Connect()
        {
            _messageTextBox.Focus();
            Application.DoEvents();

            _pleaseWaitShowing = new ManualResetEvent(false);

            String[] splitServer = _server.Split(':');
            String catalogServiceHostName = splitServer[0];
            Int32 catalogServicePortNumber = Convert.ToInt32(splitServer[1]);

            _subscriptionServiceProxy = ChatSubscriptionServiceProxyFactory.CreateFromCatalog(catalogServiceHostName, catalogServicePortNumber, this);
            _subscriptionServiceProxy.Connect();
            _subscriptionServiceProxy.Subscribe(null);

            _chatServiceProxy = ChatServiceProxyFactory.CreateFromCatalog(catalogServiceHostName, catalogServicePortNumber);
            _chatServiceProxy.BeginJoin(_name, new AsyncCallback(OnEndJoin), null);

            _pleaseWaitForm = new PleaseWaitForm();
            _pleaseWaitForm.ShowingEvent = _pleaseWaitShowing;
            _pleaseWaitForm.ShowDialog();
        }

        private void OnEndJoin(IAsyncResult iar)
        {
            _pleaseWaitShowing.WaitOne();
            try
            {
                String[] list = _chatServiceProxy.EndJoin(iar);
                HandleEndJoin(list);
            }
            catch (Exception ex)
            {
                AppendText(ex.ToString());
                HandleEndJoinError();
            }
        }

        private void HandleEndJoinError()
        {
            if (_pleaseWaitForm.InvokeRequired)
            {
                _pleaseWaitForm.BeginInvoke((MethodInvoker)delegate() { HandleEndJoinError(); });
            }
            else
            {
                _pleaseWaitForm.ShowError("Error: Cannot connect to chat!");
                ExitChatSession();
            }
        }

        private void HandleEndJoin(String[] list)
        {
            if (_pleaseWaitForm.InvokeRequired)
            {
                _pleaseWaitForm.BeginInvoke((MethodInvoker)delegate() { HandleEndJoin(list); });
            }
            else
            {
                lock (_syncRoot)
                {
                    if (list == null)
                    {
                        _pleaseWaitForm.ShowError("Error: Username already exist!");
                        ExitChatSession();
                    }
                    else
                    {
                        _pleaseWaitForm.Close();
                        _pleaseWaitShowing.Reset();
                        ShowConnectMenuItem(false);
                        foreach (string name in list)
                        {
                            if (!_chattersListBox.Items.Contains(name))
                            {
                                _chattersListBox.Items.Add(name);
                            }
                        }
                        AppendText("Connected at " + DateTime.Now.ToString() + " with user name " + _name + Environment.NewLine);
                        label1.Text = String.Format("# chatters: {0}", _chattersListBox.Items.Count);
                        label2.Text = _name;
                    }
                }
            }
        }

        private void SayAndClear(String msg)
        {
            if (!String.IsNullOrEmpty(msg))
            {
                try
                {
                    _chatServiceProxy.Say(_name, msg);
                    _messageTextBox.Text = String.Empty;
                }
                catch (Exception ex)
                {
                    AbortProxyAndUpdateUI();
                    AppendText("Disconnected at " + DateTime.Now.ToString() + Environment.NewLine);
                    AppendText(ex.ToString());
                    Error("Error: Connection to chat server lost!");
                }
            }
        }

        private void Error(String errMessage)
        {
            MessageBox.Show(errMessage, "Connection error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            ExitChatSession();
        }

        private void btnSay_Click(Object sender, EventArgs e)
        {
            SayAndClear(_messageTextBox.Text);
            _messageTextBox.Focus();
        }

        private void disconnectToolStripMenuItem_Click(Object sender, EventArgs e)
        {
            ExitChatSession();
            AppendText("Disconnected at " + DateTime.Now.ToString() + Environment.NewLine);
        }

        public void Receive(String senderName, String message)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate(){Receive(senderName, message);});
            }
            else
            {
                lock (_syncRoot)
                {
                    AppendText(senderName + ": " + message + Environment.NewLine);
                }
            }
        }

        public void UserEnter(String name)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UserEnter(name); });
            }
            else
            {
                lock (_syncRoot)
                {
                    AppendText("User " + name + " enter at " + DateTime.Now.ToString() + Environment.NewLine);
                    if (name != _name)
                    {
                        if (!_chattersListBox.Items.Contains(name))
                        {
                            _chattersListBox.Items.Add(name);
                        }
                    }
                    label1.Text = String.Format("# chatters: {0}", _chattersListBox.Items.Count);
                }
            }
        }

        public void UserLeave(String name)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UserLeave(name); });
            }
            else
            {
                lock (_syncRoot)
                {
                    AppendText("User " + name + " leave at " + DateTime.Now.ToString() + Environment.NewLine);
                    if (name != _name)
                    {
                        if (_chattersListBox.Items.Contains(name))
                        {
                            _chattersListBox.Items.Remove(name);
                        }
                    }
                    label1.Text = String.Format("# chatters: {0}", _chattersListBox.Items.Count);
                }
            }
        }

        private void AppendText(String text)
        {
            _chatRichTextBox.Text += text;
            SendMessage(_chatRichTextBox.Handle, WM_VSCROLL, SB_BOTTOM, new IntPtr(0));
        }

        private void ShowConnectMenuItem(Boolean show)
        {
            _connectToolStripMenuItem.Enabled = show;
            _disconnectToolStripMenuItem.Enabled = _sayButton.Enabled = !show;
        }

        private void txtMessage_KeyDown(Object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter && _sayButton.Enabled)
            {
                SayAndClear(_messageTextBox.Text);
            }
        }

        private void exitToolStripMenuItem_Click(Object sender, EventArgs e)
        {
            ExitChatSession();
            ExitApplication();
        }

        private void ChatForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            ExitChatSession();
            ExitApplication();
        }

        private void ExitChatSession()
        {
            try
            {
                _subscriptionServiceProxy.Unsubscribe(null);
                _subscriptionServiceProxy.Disconnect();
                _chatServiceProxy.Leave(_name);
            }
            catch { }
            finally
            {
                AbortProxyAndUpdateUI();
            }
        }

        private void AbortProxyAndUpdateUI()
        {
            if (_subscriptionServiceProxy != null)
            {
                _subscriptionServiceProxy.Close();
                _subscriptionServiceProxy = null;
            }
            if (_chatServiceProxy != null)
            {
                _chatServiceProxy.Close();
                _chatServiceProxy = null;
            }
            ShowConnectMenuItem(true);
        }

        private void ExitApplication()
        {
            Application.Exit();
        }

        private void txtMessage_KeyPress(Object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                e.Handled = true;
                _sayButton.PerformClick();
            }
        }

        private void ChatForm_Resize(Object sender, EventArgs e)
        {
            SendMessage(_chatRichTextBox.Handle, WM_VSCROLL, SB_BOTTOM, new IntPtr(0));
        }

        private void ChatForm_Load(Object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(_server) && !String.IsNullOrEmpty(_name))
            {
                Connect();
            }
        }

        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int msg, int wParam, IntPtr lParam);
        private const int WM_VSCROLL = 0x115;
        private const int SB_BOTTOM = 7;

        private ChatSubscriptionServiceProxy _subscriptionServiceProxy;
        private ChatServiceProxy _chatServiceProxy;
        private string _server;
        private string _name;

        private PleaseWaitForm _pleaseWaitForm;

        private ManualResetEvent _pleaseWaitShowing;
        private readonly Object _syncRoot = new Object();
    }
}