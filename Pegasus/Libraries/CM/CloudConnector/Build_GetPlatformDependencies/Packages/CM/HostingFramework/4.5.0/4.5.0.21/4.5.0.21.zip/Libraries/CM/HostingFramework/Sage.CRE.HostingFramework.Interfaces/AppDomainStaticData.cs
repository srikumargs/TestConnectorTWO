﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Concurrent;

namespace Sage.CRE.HostingFramework.Interfaces
{
    /// <summary>
    /// Possible keys for the app domain static data dictionary
    /// </summary>
    public enum AppDomainStaticDataKey
    {
        /// <summary>
        /// Default initializer value
        /// </summary>
        None = 0,

        /// <summary>
        /// Indicate whether the hosting framework is stopping
        /// </summary>
        IsStopping
    }

    /// <summary>
    /// Class to hold static data per app domain for each hosted service
    /// </summary>
    public static class AppDomainStaticData
    {
        /// <summary>
        /// Accessor for the internal IDictionary implementation
        /// </summary>
        public static IDictionary<AppDomainStaticDataKey, string> Dictionary
        {
            get { return _dictionary; }
        }

        /// <summary>
        /// Specific IDictionary implementation that we're using
        /// </summary>
        private static readonly ConcurrentDictionary<AppDomainStaticDataKey, string> _dictionary =
            new ConcurrentDictionary<AppDomainStaticDataKey, string>();
    }
}
