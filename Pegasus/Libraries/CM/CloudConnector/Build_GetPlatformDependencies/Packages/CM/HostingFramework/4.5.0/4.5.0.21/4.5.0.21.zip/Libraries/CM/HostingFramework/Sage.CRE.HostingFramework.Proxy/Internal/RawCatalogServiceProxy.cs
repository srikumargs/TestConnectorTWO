﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using Sage.CRE.HostingFramework.Interfaces;

namespace Sage.CRE.HostingFramework.Proxy.Internal
{
    /// <summary>
    /// The most basic proxy for ICatalogService.
    /// </summary>
    /// <remarks>
    /// Provides no logic, no error handling, no fault tolerance. Clients should usually consider using the more robust,
    /// non-raw, public RetryClientBase-derived proxy instead of this one.
    /// </remarks>
    internal sealed class RawCatalogServiceProxy : ClientBase<ICatalogService>, ICatalogService
    {
        /// <summary>
        /// 
        /// </summary>
        public RawCatalogServiceProxy()
            : base()
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        public RawCatalogServiceProxy(String endpointConfigurationName)
            : base(endpointConfigurationName)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public RawCatalogServiceProxy(String endpointConfigurationName, String remoteAddress)
            : base(endpointConfigurationName, remoteAddress)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public RawCatalogServiceProxy(String endpointConfigurationName, EndpointAddress remoteAddress)
            : base(endpointConfigurationName, remoteAddress)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="binding"></param>
        /// <param name="remoteAddress"></param>
        public RawCatalogServiceProxy(System.ServiceModel.Channels.Binding binding, EndpointAddress remoteAddress)
            : base(binding, remoteAddress)
        { }

        #region ICatalogService Members

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ServiceInfo> GetServiceInfo()
        { return base.Channel.GetServiceInfo(); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        public ServiceInfo GetServiceInfoByName(String serviceName)
        { return base.Channel.GetServiceInfoByName(serviceName); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="scheme"></param>
        /// <returns></returns>
        public Uri GetServiceUri(String serviceName, String scheme)
        { return base.Channel.GetServiceUri(serviceName, scheme); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="address"></param>
        /// <param name="scheme"></param>
        /// <returns></returns>
        public Uri GetServiceWithAddressUri(String serviceName, String address, String scheme)
        { return base.Channel.GetServiceWithAddressUri(serviceName, address, scheme); }

        #endregion
    }
}
