﻿using System;
using System.Net.Security;
using System.ServiceModel;

namespace Sage.CRE.HostingFramework.TestChatServiceInterfaces
{
    /// <summary>
    /// interface for defining the events that are fired by the ChatSubscriptionService.
    /// </summary>
    [ServiceContract(Namespace = "http://Sage.CRE.HostingFramework.com", ProtectionLevel = ProtectionLevel.EncryptAndSign)]
    public interface IChatCallback
    {
        /// <summary>
        /// Occurs when someone says something
        /// </summary>
        /// <param name="senderName">The name of the person who said it</param>
        /// <param name="message">What they said</param>
        [OperationContract(IsOneWay = true)]
        void Receive(String senderName, String message);

        /// <summary>
        /// Occurs when someone joins the chat room
        /// </summary>
        /// <param name="name">The name of the person who joined</param>
        [OperationContract(IsOneWay = true)]
        void UserEnter(String name);

        /// <summary>
        /// Occurs when someone leaves the chat room
        /// </summary>
        /// <param name="name">The name of the person who left</param>
        [OperationContract(IsOneWay = true)]
        void UserLeave(String name);
    }
}
