﻿using System;

namespace Sage.CRE.HostingFramework.Proxy.Advanced
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TServiceProxy"></typeparam>
    public interface ICatalogedServiceWithAddressProxyFactoryParams<TServiceProxy> : ICatalogedServiceProxyFactoryParams<TServiceProxy>
    {
        /// <summary>
        /// 
        /// </summary>
        String Address
        { get; }
    }
}
