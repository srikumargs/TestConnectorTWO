﻿using System;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using NetFw;
using System.Reflection;
using System.IO;
using System.Globalization;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    public static class WindowsFirewallConfiguration
    {
        public static INetFwMgr TryCreateFirewallManager(out WindowsFirewallCreationResult result)
        {
            result = WindowsFirewallCreationResult.None;

            INetFwMgr firewallManager = null;
            try
            {
                Type firewallManagerType = Type.GetTypeFromProgID("HNetCfg.FwMgr", false);
                if (firewallManagerType != null)
                {
                    firewallManager = (INetFwMgr)Activator.CreateInstance(firewallManagerType);
                }
            }
            catch (InvalidComObjectException)
            {
            }
            catch (COMException)
            {
                // catch cases where CreateInstance fails (e.g., on W2K8 Server, CreateInstance of the firewall
                // manager will fail if the Windows Firewall service is disabled.
            }

            if (firewallManager != null)
            {
                try
                {
                    INetFwProfile profile = firewallManager.LocalPolicy.CurrentProfile;
                    result = WindowsFirewallCreationResult.Success;
                }
                catch (COMException ex)
                {
                    firewallManager = null;

                    if (ex.ErrorCode == -2147023143)
                    {
                        // On Vista, the Windows Firewall is named "MpsSvc"
                        // On XP and 2003 Server, the Windows Firewall is named "SharedAccess"
                        Boolean mpsSvcServiceInstalled = false;
                        Boolean mpsSvcServiceRunning = false;
                        try
                        {
                            using (ServiceController serviceController = new ServiceController("MpsSvc"))
                            {
                                mpsSvcServiceRunning = (serviceController.Status == ServiceControllerStatus.Running); // access a real property to force an exception to be thrown if service is not installed
                                mpsSvcServiceInstalled = true;
                            }
                        }
                        catch (InvalidOperationException)
                        {
                            // this exception gets thrown when trying to access a property for a service that is not actually installed
                        }

                        Boolean sharedAccessServiceInstalled = false;
                        Boolean sharedAccessServiceRunning = false;
                        try
                        {
                            using (ServiceController serviceController = new ServiceController("SharedAccess"))
                            {
                                sharedAccessServiceRunning = (serviceController.Status == ServiceControllerStatus.Running); // access a real property to force an exception to be thrown if service is not installed
                                sharedAccessServiceInstalled = true;
                            }
                        }
                        catch (InvalidOperationException)
                        {
                            // this exception gets thrown when trying to access a property for a service that is not actually installed
                        }

                        if (mpsSvcServiceInstalled)
                        {
                            if (!mpsSvcServiceRunning)
                            {
                                result = WindowsFirewallCreationResult.FirewallServiceNotRunning;
                            }
                        }
                        else if (sharedAccessServiceInstalled && !sharedAccessServiceRunning)
                        {
                            result = WindowsFirewallCreationResult.FirewallServiceNotRunning;
                        }

                        if (result == WindowsFirewallCreationResult.None)
                        {
                            throw;
                        }
                    }
                }
            }
            else
            {
                result = WindowsFirewallCreationResult.ComponentActivationFailure;
            }

            return firewallManager;
        }

        public static WindowsFirewallConfigurationResult AddApplicationException(INetFwProfile profile, String imageFilePath)
        {
            WindowsFirewallConfigurationResult result = WindowsFirewallConfigurationResult.None;

            INetFwAuthorizedApplication firewallAuthorizedApplication = null;
            try
            {
                firewallAuthorizedApplication = profile.AuthorizedApplications.Item(InternalConfig.ServiceExeFilePath);
            }
            catch (System.IO.FileNotFoundException)
            {
                // missing the file will be handled below
            }

            if (firewallAuthorizedApplication == null || !firewallAuthorizedApplication.Enabled)
            {
                Boolean addToProfile = false;
                if (firewallAuthorizedApplication == null)
                {
                    Type firewallAuthorizedApplicationType = Type.GetTypeFromProgID("HNetCfg.FwAuthorizedApplication");
                    firewallAuthorizedApplication = (INetFwAuthorizedApplication)Activator.CreateInstance(firewallAuthorizedApplicationType);
                    addToProfile = true;
                }

                firewallAuthorizedApplication.Name = InternalConfig.ServiceDisplayName;
                firewallAuthorizedApplication.ProcessImageFileName = InternalConfig.ServiceExeFilePath;
                firewallAuthorizedApplication.IpVersion = NET_FW_IP_VERSION_.NET_FW_IP_VERSION_ANY;
                //firewallAuthorizedApplication.RemoteAddresses = "*"; // specify Scope or RemoteAddresses ... not both
                firewallAuthorizedApplication.Scope = NET_FW_SCOPE_.NET_FW_SCOPE_ALL;
                firewallAuthorizedApplication.Enabled = true;

                if (addToProfile)
                {
                    profile.AuthorizedApplications.Add(firewallAuthorizedApplication);
                }

                result = WindowsFirewallConfigurationResult.Success;
            }
            else
            {
                result = WindowsFirewallConfigurationResult.NoChangesRequired;
            }

            return result;
        }

        public static Boolean AddApplicationRule(TextWriter installContextLogWriter, String ruleName, String imageFilePath,  FirewallAPI.NET_FW_ACTION_ action)
        {
            installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "Begin {0}.AddApplicationRule() (CodeBase={1})", _myTypeName, Assembly.GetExecutingAssembly().CodeBase));

            Boolean result = false;

            try
            {
                FirewallAPI.INetFwRule firewallRule = (FirewallAPI.INetFwRule)Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FWRule"));
                firewallRule.Action = action;
                //firewallRule.Description = InternalConfig.ServiceDisplayName;
                firewallRule.Direction = FirewallAPI.NET_FW_RULE_DIRECTION_.NET_FW_RULE_DIR_IN;
                firewallRule.ApplicationName = imageFilePath;
                firewallRule.Enabled = true;
                firewallRule.InterfaceTypes = "All";
                firewallRule.Name = ruleName;

                FirewallAPI.INetFwPolicy2 firewallPolicy = (FirewallAPI.INetFwPolicy2)Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwPolicy2"));
                firewallPolicy.Rules.Add(firewallRule);
                result = true;

                installContextLogWriter.WriteLine(String.Format(@"Successfully added Advanced Windows Firewall application rule '{0}'", ruleName));
            }
            catch (Exception ex)
            {
                installContextLogWriter.WriteLine(String.Format(@"Failed to add Advanced Windows Firewall application rule '{0}'. An exception occurred:\n\n{0}", ruleName, ex.ToString()));
            }
            finally
            {
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "End {0}.AddApplicationRule() (CodeBase={1}); result was '{2}'", _myTypeName, Assembly.GetExecutingAssembly().CodeBase, result));
            }

            return result;
        }

        public static Boolean RemoveApplicationExceptionAdvanced(TextWriter installContextLogWriter, String ruleName)
        {
            installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "Begin {0}.RemoveApplicationExceptionAdvanced() (CodeBase={1})", _myTypeName, Assembly.GetExecutingAssembly().CodeBase));

            Boolean result = false;

            try
            {
                FirewallAPI.INetFwPolicy2 firewallPolicy = (FirewallAPI.INetFwPolicy2)Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwPolicy2"));
                firewallPolicy.Rules.Remove(ruleName);
                result = true;

                installContextLogWriter.WriteLine(String.Format(@"Successfully removed Advanced Windows Firewall application rule '{0}'", ruleName));
            }
            catch (Exception ex)
            {
                installContextLogWriter.WriteLine(String.Format(@"Failed to remove Advanced Windows Firewall application rule '{0}'. An exception occurred:\n\n{0}", ruleName, ex.ToString()));
            }
            finally
            {
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "End {0}.RemoveApplicationExceptionAdvanced() (CodeBase={1}); result was '{2}'", _myTypeName, Assembly.GetExecutingAssembly().CodeBase, result));
            }

            return result;
        }

        public static WindowsFirewallConfigurationResult RemoveApplicationException(INetFwProfile profile, String imageFilePath)
        {
            WindowsFirewallConfigurationResult result = WindowsFirewallConfigurationResult.None;

            try
            {
                profile.AuthorizedApplications.Remove(InternalConfig.ServiceExeFilePath);
                result = WindowsFirewallConfigurationResult.Success;
            }
            catch (System.IO.FileNotFoundException)
            {
                // missing the file will be handled below
                result = WindowsFirewallConfigurationResult.NoChangesRequired;
            }

            return result;
        }

        private static String _myTypeName = typeof(WindowsFirewallConfiguration).FullName;
    }
}
