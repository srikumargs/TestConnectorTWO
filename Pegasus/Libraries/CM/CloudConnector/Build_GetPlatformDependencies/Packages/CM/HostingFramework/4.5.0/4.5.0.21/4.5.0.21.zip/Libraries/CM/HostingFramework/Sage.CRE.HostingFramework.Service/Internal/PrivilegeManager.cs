﻿using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    internal static class PrivilegeManager
    {
        #region Public methods
        public static void GrantShutdownPrivilege(TextWriter installContextLogWriter)
        {
            installContextLogWriter.WriteLine("Begin GrantShutdownPrivilege");

            IntPtr processTokenHandle = IntPtr.Zero;
            IntPtr currentProcessHandle = IntPtr.Zero;
            try
            {
                currentProcessHandle = GetCurrentProcess();

                Boolean ok = OpenProcessToken(currentProcessHandle, TokenAccessRights.TOKEN_ADJUST_PRIVILEGES | TokenAccessRights.TOKEN_QUERY, ref processTokenHandle);
                if (!ok)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Failed to OpenProcessToken");
                }

                LUID luid = new LUID();
                ok = LookupPrivilegeValue(null, SE_SHUTDOWN_NAME, ref luid);
                if (!ok)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Failed to LookupPrivilegeValue");
                }

                TOKEN_PRIVILEGES tokenPrivileges = new TOKEN_PRIVILEGES();
                tokenPrivileges.PrivilegeCount = 1;
                tokenPrivileges.Privileges = new LUID_AND_ATTRIBUTES[] { new LUID_AND_ATTRIBUTES() };
                tokenPrivileges.Privileges[0].Luid = luid;
                tokenPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
                ok = AdjustTokenPrivileges(processTokenHandle, false, ref tokenPrivileges, 0, IntPtr.Zero, IntPtr.Zero);
                if (!ok)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Failed to AdjustTokenPrivileges");
                }

                installContextLogWriter.WriteLine("GrantShutdownPrivilege completed successfully");
            }
            finally
            {
                if (processTokenHandle != IntPtr.Zero)
                {
                    CloseHandle(processTokenHandle);
                }
            }
        }
        #endregion

        #region Private P/Invoke signatures & types
        // Don't reference other Sage assemblies (e.g., Sage.PInvoke) in code that runs during install

        private const Int32 ANYSIZE_ARRAY = 1;
        private const String SE_SHUTDOWN_NAME = "SeShutdownPrivilege";
        private const Int32 SE_PRIVILEGE_ENABLED = 2;
        private const String ADVAPI32 = "advapi32.dll";
        private const String KERNEL32 = "kernel32.dll";

        [Flags]
        enum StandardRights : int
        {
            READ_CONTROL = 0x00020000,
            STANDARD_RIGHTS_REQUIRED = 0x000F0000,
            STANDARD_RIGHTS_READ = READ_CONTROL,
            STANDARD_RIGHTS_WRITE = READ_CONTROL,
            STANDARD_RIGHTS_EXECUTE = READ_CONTROL
        }

        [Flags]
        enum TokenAccessRights : int
        {
            TOKEN_ASSIGN_PRIMARY = 0x0001,
            TOKEN_DUPLICATE = 0x0002,
            TOKEN_IMPERSONATE = 0x0004,
            TOKEN_QUERY = 0x0008,
            TOKEN_QUERY_SOURCE = 0x0010,
            TOKEN_ADJUST_PRIVILEGES = 0x0020,
            TOKEN_ADJUST_GROUPS = 0x0040,
            TOKEN_ADJUST_DEFAULT = 0x0080,
            TOKEN_ADJUST_SESSIONID = 0x0100,
            TOKEN_READ = (StandardRights.STANDARD_RIGHTS_READ | TOKEN_QUERY),
            TOKEN_WRITE = (StandardRights.STANDARD_RIGHTS_WRITE | TOKEN_ADJUST_PRIVILEGES | TOKEN_ADJUST_GROUPS | TOKEN_ADJUST_DEFAULT),
            TOKEN_EXECUTE = StandardRights.STANDARD_RIGHTS_EXECUTE,
            TOKEN_ALL_ACCESS = (StandardRights.STANDARD_RIGHTS_REQUIRED | TOKEN_ASSIGN_PRIMARY |
                TOKEN_DUPLICATE | TOKEN_IMPERSONATE | TOKEN_QUERY | TOKEN_QUERY_SOURCE |
                TOKEN_ADJUST_PRIVILEGES | TOKEN_ADJUST_GROUPS | TOKEN_ADJUST_DEFAULT |
                TOKEN_ADJUST_SESSIONID)
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct LUID
        {
            public UInt32 LowPart;
            public Int32 HighPart;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct LUID_AND_ATTRIBUTES
        {
            public LUID Luid;
            public UInt32 Attributes;
        }

        // The Pack attribute specified here is important. We are in essence cheating here because
        // the Privileges field is actually a variable size array of structs.  We use the Pack=1
        // to align the Privileges field exactly after the PrivilegeCount field when marshalling
        // this struct to Win32.
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct TOKEN_PRIVILEGES
        {
            public UInt32 PrivilegeCount;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = ANYSIZE_ARRAY)]
            public LUID_AND_ATTRIBUTES[] Privileges;
        }

        [DllImport(ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern Boolean AdjustTokenPrivileges(IntPtr TokenHandle,
            [MarshalAs(UnmanagedType.Bool)]Boolean DisableAllPrivileges,
            ref TOKEN_PRIVILEGES NewState,
            Int32 BufferLength,
            IntPtr PreviousState,
            IntPtr ReturnLength);

        [DllImport(ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern Boolean LookupPrivilegeValue(String lpSystemName, String lpName, ref LUID lpLuid);

        [DllImport(ADVAPI32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern Boolean OpenProcessToken(IntPtr ProcessHandle, TokenAccessRights DesiredAccess, ref IntPtr TokenHandle);

        [DllImport(KERNEL32)]
        private static extern IntPtr GetCurrentProcess();

        [DllImport(KERNEL32, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern Boolean CloseHandle(IntPtr handle);
        #endregion
    }
}
