﻿using System;
using System.Net.Sockets;
using System.ServiceModel;
using System.Threading;
using Sage.CRE.HostingFramework.Proxy.Internal;
using Sage.ServiceModel;

namespace Sage.CRE.HostingFramework.Proxy.Advanced
{
    /// <summary>
    /// Generic helper to facilitate creation of ProxyFactory classes
    /// </summary>
    /// <typeparam name="TServiceProxy">The type of the service proxy that will be created</typeparam>
    /// <typeparam name="TFactoryParams">The type of the params object (implments ICatalogedServiceProxyFactoryParams)</typeparam>
    public class CatalogedServiceProxyFactory<TServiceProxy, TFactoryParams>
        where TServiceProxy : class
        where TFactoryParams : ICatalogedServiceProxyFactoryParams<TServiceProxy>, new()
    {
        /// <summary>
        /// Initializes a new instance of the TServiceProxy class via the HostingFramework catalog. 
        /// </summary>
        /// <param name="catalogServiceHostName">Host name of the machine running the HostingFramework CatalogService</param>
        /// <param name="catalogServicePortNumber">Port number of the HostingFramework CatalogService</param>
        /// <returns></returns>
        public static TServiceProxy CreateFromCatalog(String catalogServiceHostName, Int32 catalogServicePortNumber)
        { return CreateFromCatalog(catalogServiceHostName, catalogServicePortNumber, null); }

        /// <summary>
        /// Initializes a new instance of the TServiceProxy class via the HostingFramework catalog. 
        /// </summary>
        /// <param name="catalogServiceHostName">Host name of the machine running the HostingFramework CatalogService</param>
        /// <param name="catalogServicePortNumber">Port number of the HostingFramework CatalogService</param>
        /// <param name="instanceForContext">An optional parameter used to supply an instance context for callback interfaces (can be null)</param>
        /// <returns></returns>
        public static TServiceProxy CreateFromCatalog(String catalogServiceHostName, Int32 catalogServicePortNumber, Object instanceForContext)
        {
            TFactoryParams factoryParams = new TFactoryParams();
            var withAddressFactoryParams = (factoryParams as ICatalogedServiceWithAddressProxyFactoryParams<TServiceProxy>);

            return CreatePrivate(catalogServiceHostName,
                catalogServicePortNumber,
                factoryParams.ServiceName,
                withAddressFactoryParams != null ? withAddressFactoryParams.Address : String.Empty,
                delegate(EndpointAddress endpointAddress, InstanceContext instanceContext)
                { return factoryParams.Create(endpointAddress, instanceContext); },
                instanceForContext);
        }

        /// <summary>
        /// Initializes a new instance of the TServiceProxy class via the HostingFramework catalog. 
        /// </summary>
        /// <param name="catalogServiceUri">Address to the HostingFramework CatalogService</param>
        /// <returns></returns>
        public static TServiceProxy CreateFromCatalog(Uri catalogServiceUri)
        { return CreateFromCatalog(catalogServiceUri, null); }

        /// <summary>
        /// Initializes a new instance of the TServiceProxy class via the HostingFramework catalog. 
        /// </summary>
        /// <param name="catalogServiceUri">Address to the HostingFramework CatalogService</param>
        /// <param name="instanceForContext">An optional parameter used to supply an instance context for callback interfaces (can be null)</param>
        /// <returns></returns>
        public static TServiceProxy CreateFromCatalog(Uri catalogServiceUri, Object instanceForContext)
        {
            TFactoryParams factoryParams = new TFactoryParams();
            var withAddressFactoryParams = (factoryParams as ICatalogedServiceWithAddressProxyFactoryParams<TServiceProxy>);

            return CreatePrivate(catalogServiceUri,
                factoryParams.ServiceName,
                withAddressFactoryParams != null ? withAddressFactoryParams.Address : String.Empty,
                delegate(EndpointAddress endpointAddress, InstanceContext instanceContext)
                { return factoryParams.Create(endpointAddress, instanceContext); },
                instanceForContext);
        }

        /// <summary>
        /// Initializes a new instance of the TServiceProxy class using the specified target address. 
        /// </summary>
        /// <param name="endpointAddress">The address of the service endpoint.</param>
        /// <param name="instanceContext"></param>
        /// <returns></returns>
        public static TServiceProxy Create(EndpointAddress endpointAddress, InstanceContext instanceContext)
        {
            if (endpointAddress.Uri.Scheme == "net.tcp")
            {
                // Try to find out if the host and port are correct, as quickly as possible, before letting WCF remote calls
                // go off and try to do something 
                TcpHelper.TestConnect(endpointAddress.Uri, NET_TCP_CONNECT_TIMEOUT);
            }

            TFactoryParams factoryParams = new TFactoryParams();

            return factoryParams.Create(endpointAddress, instanceContext);
        }

        private delegate TServiceProxy CreationDelegate(EndpointAddress endpointAddress, InstanceContext instanceContext);

        private static TServiceProxy CreatePrivate(String catalogServiceHostName, Int32 portNumber, String serviceName, String address, CreationDelegate creationDelegate, Object instanceForContext)
        { return CreatePrivate(new Uri(String.Format("net.tcp://{0}:{1}/CatalogService", catalogServiceHostName, portNumber)), serviceName, address, creationDelegate, instanceForContext); }

        private static TServiceProxy CreatePrivate(Uri catalogServiceUri, String serviceName, String address,  CreationDelegate creationDelegate, Object instanceForContext)
        {
            TServiceProxy result = default(TServiceProxy);

            EndpointAddress endpointAddress = null;
            NetTcpBinding binding = null;
            CatalogServiceProxy catalogServiceProxy = null;
            Uri serviceUri = null;
            try
            {
                if (catalogServiceUri.Scheme == "net.tcp")
                {
                    // Try to find out if the host and port are correct, as quickly as possible, before letting WCF remote calls
                    // go off and try to do something 
                    TcpHelper.TestConnect(catalogServiceUri, NET_TCP_CONNECT_TIMEOUT);
                }

                endpointAddress = new EndpointAddress(catalogServiceUri);
                binding = new NetTcpBinding(SecurityMode.Transport, true);
                binding.Security.Transport.ProtectionLevel = System.Net.Security.ProtectionLevel.EncryptAndSign;
                binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Windows;

                catalogServiceProxy = new CatalogServiceProxy(delegate() { return new RawCatalogServiceProxy(binding, endpointAddress); });
                serviceUri = catalogServiceProxy.GetServiceWithAddressUri(serviceName, address, binding.Scheme);
                catalogServiceProxy.Close();
                catalogServiceProxy = null;

                endpointAddress = new EndpointAddress(serviceUri.ToString());

                InstanceContext context = null;
                if (instanceForContext != null)
                {
                    context = new InstanceContext(instanceForContext);
                }

                result = creationDelegate(endpointAddress, context);
            }
            finally
            {
                if (catalogServiceProxy != null)
                {
                    catalogServiceProxy.Abort();
                    catalogServiceProxy = null;
                }
            }

            return result;
        }

        private const Int32 NET_TCP_CONNECT_TIMEOUT = 10 * 1000;
    }
}
