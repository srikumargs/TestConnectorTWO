﻿using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace Sage.CRE.HostingFramework.Interfaces
{
    /// <summary>
    /// 
    /// </summary>
    /// 
    [ServiceContract(SessionMode = SessionMode.Allowed, Namespace = Constants.SERVICE_NAMESPACE)]
    public interface IHostSupervisor
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceInfo"></param>
        [OperationContract(IsOneWay = true)]
        void RegisterService(ServiceInfo serviceInfo);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        [OperationContract(IsOneWay = true)]
        void UnregisterService(String name);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="serviceStatus"></param>
        [OperationContract(IsOneWay=true)]
        void UpdateServiceStatus(String name, CommunicationState serviceStatus);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [OperationContract(IsOneWay = false)]
        IEnumerable<ServiceInfo> GetServiceInfo();
    }
}
