﻿using System;
using System.Globalization;
using System.IO;
using Sage.Configuration;
using Sage.CRE.LinkedSource;
using Sage.CRE.HostingFramework.LinkedSource;
using System.Reflection;
using System.Collections.Generic;
using System.Security.AccessControl;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    internal static class InternalConfig
    {
        /// <summary>
        /// The registry subkey for the Windows Service entry
        /// </summary>
        public static String ServiceRegistrySubKey
        { get { return String.Format(CultureInfo.InvariantCulture, @"SYSTEM\CurrentControlSet\Services\{0}", ServiceName); } }

        public static String ServiceDataRegistrySubKey
        { get { return String.Format(CultureInfo.InvariantCulture, @"SOFTWARE\Sage\CRE\HostingFramework\{0}", ServiceName); } }

        /// <summary>
        /// The directory where service start result calls will report errors to
        /// </summary>
        public static String ServiceStartErrorResultFilePath
        {
            get
            {
                return
                    Path.Combine(
                        System.Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments),
                        ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceStartErrorResultFilename);
            }
        }


        /// <summary>
        /// The file system rights that should be granted explicitly for the service account user
        /// When installing the service
        /// </summary>
        public static FileSystemRights ServiceAccountUserFileSystemRights
        {
            get
            {
                return
                    FileSystemRights.Read | FileSystemRights.Write | FileSystemRights.CreateFiles |
                    FileSystemRights.Delete |
                    FileSystemRights.Synchronize | FileSystemRights.ListDirectory |
                    FileSystemRights.DeleteSubdirectoriesAndFiles | FileSystemRights.Traverse |
                    FileSystemRights.ExecuteFile;
            }
        }

        public static string HostingFrameworkServicesFolder
        { get { return Path.Combine(Path.GetDirectoryName(ServiceExeFilePath), @"HostingFrameworkServices"); } }

        public static String ServiceName
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).Name; } }

        public static String ServiceVersion
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).Version; } }

        public static String ServiceDisplayName
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).DisplayName; } }

        public static String ServiceFileName
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).FileName; } }

        public static String ServiceProcessRunningMutexName
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceProcessRunningMutexName; } }

        public static String ServiceReadyMutexName
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceReadyMutexName; } }

        public static String ServiceExeFilePath
        { get { return ServiceConstantsFactory.GetConstants(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName).ExeFilePath; } }

        public static String ServiceDescription
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).Description; } }

        public static Int32 NotifyHostReadyTimeout
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).NotifyHostReadyTimeout; } }

        public static Dictionary<String, String> BaseAddressTemplates
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).BaseAddressTemplates; } }

        public static Dictionary<String, String> BaseAddressTemplatePorts
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).BaseAddressTemplatePorts; } }

        public static String InstanceApplicationDataFolder
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).InstanceApplicationDataFolder; } }

        public static Boolean RemoveUsersPermissionToAppData
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).RemoveUsersPermissionToAppData; } }

        public static Boolean BlockApplicationIncomingConnections
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).BlockApplicationIncomingConnections; } }

        public static String ServiceAccountUser
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceAccountUser; } }

        public static String ServiceAccountPassword
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceAccountPassword; } }

        public static String ServiceStartType
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceStartType; } }

        public static String ServiceFirstFailureAction
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceFirstFailureAction; } }

        public static String ServiceSecondFailureAction
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceSecondFailureAction; } }

        public static String ServiceSubsequentFailureAction
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceSubsequentFailureAction; } }

        public static String ServiceDelayedStart
        { get { return ServiceConstantsFactory.GetConstants(ServiceExeFilePath).ServiceDelayedStart; } }
    }
}
