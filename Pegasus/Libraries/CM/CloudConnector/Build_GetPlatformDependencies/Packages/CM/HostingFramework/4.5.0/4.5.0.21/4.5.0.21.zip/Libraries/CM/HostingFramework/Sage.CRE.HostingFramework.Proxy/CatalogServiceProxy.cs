﻿using System;
using System.Collections.Generic;
using Sage.CRE.HostingFramework.Interfaces;
using Sage.ServiceModel;

namespace Sage.CRE.HostingFramework.Proxy
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class CatalogServiceProxy : RetryClientBase<ICatalogService>, ICatalogService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="rawProxyCreationFunction"></param>
        public CatalogServiceProxy(RetryClientBase<ICatalogService>.CreationFunction rawProxyCreationFunction)
            : base(rawProxyCreationFunction)
        { }

        #region ICatalogService Members

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ServiceInfo> GetServiceInfo()
        { return (IEnumerable<ServiceInfo>)RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.GetServiceInfo(); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        public ServiceInfo GetServiceInfoByName(String serviceName)
        { return (ServiceInfo)RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.GetServiceInfoByName(serviceName); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="scheme"></param>
        /// <returns></returns>
        public Uri GetServiceUri(String serviceName, String scheme)
        { return (Uri)RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.GetServiceUri(serviceName, scheme); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="address"></param>
        /// <param name="scheme"></param>
        /// <returns></returns>
        public Uri GetServiceWithAddressUri(String serviceName, String address, String scheme)
        { return (Uri)RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.GetServiceWithAddressUri(serviceName, address, scheme); }); }

        #endregion
    }
}
