﻿namespace Sage.CRE.HostingFramework.ServiceMonitor
{
    internal partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "Machine name:",
            "Unknown"}, -1);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "Port number:",
            "Unknown"}, -1);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "Status:",
            "Unknown"}, -1);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "Uptime:",
            "Unknown"}, -1);
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new string[] {
            "Version:",
            "Unknown"}, -1);
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem(new string[] {
            "Server:",
            "Unknown"}, -1);
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this._notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this._contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this._monitorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this._exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._tabControl = new System.Windows.Forms.TabControl();
            this._generalTabPage = new System.Windows.Forms.TabPage();
            this._generalListView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._servicesTabPage = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this._servicesListView = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._urisListView = new System.Windows.Forms.ListView();
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._toolStrip = new System.Windows.Forms.ToolStrip();
            this._settingsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._refreshToolStripSplitButton = new System.Windows.Forms.ToolStripSplitButton();
            this._nowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this._fiveSecondsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._tenSecondsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._thirtySecondsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._sixtySecondsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._twoMinutesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._fiveMinutesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._tenMinutesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._noneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._statusStrip = new System.Windows.Forms.StatusStrip();
            this._toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this._contextMenuStrip.SuspendLayout();
            this._tabControl.SuspendLayout();
            this._generalTabPage.SuspendLayout();
            this._servicesTabPage.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this._toolStrip.SuspendLayout();
            this._statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // _notifyIcon
            // 
            this._notifyIcon.ContextMenuStrip = this._contextMenuStrip;
            this._notifyIcon.Visible = true;
            this._notifyIcon.DoubleClick += new System.EventHandler(this._notifyIcon_DoubleClick);
            // 
            // _contextMenuStrip
            // 
            this._contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._monitorToolStripMenuItem,
            this._settingsToolStripMenuItem,
            this.toolStripSeparator1,
            this._exitToolStripMenuItem});
            this._contextMenuStrip.Name = "contextMenuStrip1";
            this._contextMenuStrip.Size = new System.Drawing.Size(127, 76);
            // 
            // _monitorToolStripMenuItem
            // 
            this._monitorToolStripMenuItem.Name = "_monitorToolStripMenuItem";
            this._monitorToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this._monitorToolStripMenuItem.Text = "&Monitor...";
            this._monitorToolStripMenuItem.Click += new System.EventHandler(this._monitorToolStripMenuItem_Click);
            // 
            // _settingsToolStripMenuItem
            // 
            this._settingsToolStripMenuItem.Name = "_settingsToolStripMenuItem";
            this._settingsToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this._settingsToolStripMenuItem.Text = "&Settings...";
            this._settingsToolStripMenuItem.Click += new System.EventHandler(this._settingsToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(123, 6);
            // 
            // _exitToolStripMenuItem
            // 
            this._exitToolStripMenuItem.Name = "_exitToolStripMenuItem";
            this._exitToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this._exitToolStripMenuItem.Text = "E&xit";
            this._exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // _tabControl
            // 
            this._tabControl.Controls.Add(this._generalTabPage);
            this._tabControl.Controls.Add(this._servicesTabPage);
            this._tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tabControl.Location = new System.Drawing.Point(0, 25);
            this._tabControl.Name = "_tabControl";
            this._tabControl.SelectedIndex = 0;
            this._tabControl.Size = new System.Drawing.Size(624, 217);
            this._tabControl.TabIndex = 7;
            // 
            // _generalTabPage
            // 
            this._generalTabPage.Controls.Add(this._generalListView);
            this._generalTabPage.Location = new System.Drawing.Point(4, 22);
            this._generalTabPage.Name = "_generalTabPage";
            this._generalTabPage.Padding = new System.Windows.Forms.Padding(3);
            this._generalTabPage.Size = new System.Drawing.Size(616, 191);
            this._generalTabPage.TabIndex = 0;
            this._generalTabPage.Text = "General";
            this._generalTabPage.UseVisualStyleBackColor = true;
            // 
            // _generalListView
            // 
            this._generalListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this._generalListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._generalListView.FullRowSelect = true;
            this._generalListView.GridLines = true;
            this._generalListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this._generalListView.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6});
            this._generalListView.Location = new System.Drawing.Point(3, 3);
            this._generalListView.MultiSelect = false;
            this._generalListView.Name = "_generalListView";
            this._generalListView.Size = new System.Drawing.Size(610, 185);
            this._generalListView.TabIndex = 0;
            this._generalListView.UseCompatibleStateImageBehavior = false;
            this._generalListView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Width = 150;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Width = 100;
            // 
            // _servicesTabPage
            // 
            this._servicesTabPage.Controls.Add(this.splitContainer1);
            this._servicesTabPage.Location = new System.Drawing.Point(4, 22);
            this._servicesTabPage.Name = "_servicesTabPage";
            this._servicesTabPage.Padding = new System.Windows.Forms.Padding(3);
            this._servicesTabPage.Size = new System.Drawing.Size(616, 191);
            this._servicesTabPage.TabIndex = 1;
            this._servicesTabPage.Text = "Services";
            this._servicesTabPage.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this._servicesListView);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this._urisListView);
            this.splitContainer1.Size = new System.Drawing.Size(610, 185);
            this.splitContainer1.SplitterDistance = 100;
            this.splitContainer1.TabIndex = 0;
            // 
            // _servicesListView
            // 
            this._servicesListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader3,
            this.columnHeader6,
            this.columnHeader4});
            this._servicesListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._servicesListView.FullRowSelect = true;
            this._servicesListView.GridLines = true;
            this._servicesListView.HideSelection = false;
            this._servicesListView.Location = new System.Drawing.Point(0, 0);
            this._servicesListView.MultiSelect = false;
            this._servicesListView.Name = "_servicesListView";
            this._servicesListView.Size = new System.Drawing.Size(610, 100);
            this._servicesListView.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this._servicesListView.TabIndex = 2;
            this._servicesListView.UseCompatibleStateImageBehavior = false;
            this._servicesListView.View = System.Windows.Forms.View.Details;
            this._servicesListView.SelectedIndexChanged += new System.EventHandler(this._servicesListView_SelectedIndexChanged);
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Name";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Description";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Status";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "AppDomainId";
            // 
            // _urisListView
            // 
            this._urisListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader11});
            this._urisListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._urisListView.FullRowSelect = true;
            this._urisListView.GridLines = true;
            this._urisListView.Location = new System.Drawing.Point(0, 0);
            this._urisListView.MultiSelect = false;
            this._urisListView.Name = "_urisListView";
            this._urisListView.Size = new System.Drawing.Size(610, 81);
            this._urisListView.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this._urisListView.TabIndex = 3;
            this._urisListView.UseCompatibleStateImageBehavior = false;
            this._urisListView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Uri";
            // 
            // _toolStrip
            // 
            this._toolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this._toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._settingsToolStripButton,
            this._refreshToolStripSplitButton});
            this._toolStrip.Location = new System.Drawing.Point(0, 0);
            this._toolStrip.Name = "_toolStrip";
            this._toolStrip.Size = new System.Drawing.Size(624, 25);
            this._toolStrip.TabIndex = 8;
            this._toolStrip.Text = "toolStrip1";
            // 
            // _settingsToolStripButton
            // 
            this._settingsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._settingsToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("_settingsToolStripButton.Image")));
            this._settingsToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._settingsToolStripButton.Name = "_settingsToolStripButton";
            this._settingsToolStripButton.Size = new System.Drawing.Size(62, 22);
            this._settingsToolStripButton.Text = "Settings...";
            this._settingsToolStripButton.Click += new System.EventHandler(this._settingsToolStripButton_Click);
            // 
            // _refreshToolStripSplitButton
            // 
            this._refreshToolStripSplitButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._nowToolStripMenuItem,
            this.toolStripSeparator,
            this._fiveSecondsToolStripMenuItem,
            this._tenSecondsToolStripMenuItem,
            this._thirtySecondsToolStripMenuItem,
            this._sixtySecondsToolStripMenuItem,
            this._twoMinutesToolStripMenuItem,
            this._fiveMinutesToolStripMenuItem,
            this._tenMinutesToolStripMenuItem,
            this._noneToolStripMenuItem});
            this._refreshToolStripSplitButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this._refreshToolStripSplitButton.Name = "_refreshToolStripSplitButton";
            this._refreshToolStripSplitButton.Size = new System.Drawing.Size(62, 22);
            this._refreshToolStripSplitButton.Text = "Refresh";
            this._refreshToolStripSplitButton.ButtonClick += new System.EventHandler(this._refreshToolStripSplitButton_ButtonClick);
            // 
            // _nowToolStripMenuItem
            // 
            this._nowToolStripMenuItem.Name = "_nowToolStripMenuItem";
            this._nowToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this._nowToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this._nowToolStripMenuItem.Text = "&Now";
            this._nowToolStripMenuItem.Click += new System.EventHandler(this._nowToolStripMenuItem_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(160, 6);
            // 
            // _fiveSecondsToolStripMenuItem
            // 
            this._fiveSecondsToolStripMenuItem.CheckOnClick = true;
            this._fiveSecondsToolStripMenuItem.Name = "_fiveSecondsToolStripMenuItem";
            this._fiveSecondsToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this._fiveSecondsToolStripMenuItem.Text = "Every &5 seconds";
            this._fiveSecondsToolStripMenuItem.Click += new System.EventHandler(this._fiveSecondsToolStripMenuItem_Click);
            // 
            // _tenSecondsToolStripMenuItem
            // 
            this._tenSecondsToolStripMenuItem.CheckOnClick = true;
            this._tenSecondsToolStripMenuItem.Name = "_tenSecondsToolStripMenuItem";
            this._tenSecondsToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this._tenSecondsToolStripMenuItem.Text = "Every &10 seconds";
            this._tenSecondsToolStripMenuItem.Click += new System.EventHandler(this._tenSecondsToolStripMenuItem_Click);
            // 
            // _thirtySecondsToolStripMenuItem
            // 
            this._thirtySecondsToolStripMenuItem.CheckOnClick = true;
            this._thirtySecondsToolStripMenuItem.Name = "_thirtySecondsToolStripMenuItem";
            this._thirtySecondsToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this._thirtySecondsToolStripMenuItem.Text = "Every &30 seconds";
            this._thirtySecondsToolStripMenuItem.Click += new System.EventHandler(this._thirtySecondsToolStripMenuItem_Click);
            // 
            // _sixtySecondsToolStripMenuItem
            // 
            this._sixtySecondsToolStripMenuItem.CheckOnClick = true;
            this._sixtySecondsToolStripMenuItem.Name = "_sixtySecondsToolStripMenuItem";
            this._sixtySecondsToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this._sixtySecondsToolStripMenuItem.Text = "Every &60 seconds";
            this._sixtySecondsToolStripMenuItem.Click += new System.EventHandler(this._sixtySecondsToolStripMenuItem_Click);
            // 
            // _twoMinutesToolStripMenuItem
            // 
            this._twoMinutesToolStripMenuItem.CheckOnClick = true;
            this._twoMinutesToolStripMenuItem.Name = "_twoMinutesToolStripMenuItem";
            this._twoMinutesToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this._twoMinutesToolStripMenuItem.Text = "Every &2 minutes";
            this._twoMinutesToolStripMenuItem.Click += new System.EventHandler(this._twoMinutesToolStripMenuItem_Click);
            // 
            // _fiveMinutesToolStripMenuItem
            // 
            this._fiveMinutesToolStripMenuItem.CheckOnClick = true;
            this._fiveMinutesToolStripMenuItem.Name = "_fiveMinutesToolStripMenuItem";
            this._fiveMinutesToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this._fiveMinutesToolStripMenuItem.Text = "Every &5 minutes";
            this._fiveMinutesToolStripMenuItem.Click += new System.EventHandler(this._fiveMinutesToolStripMenuItem_Click);
            // 
            // _tenMinutesToolStripMenuItem
            // 
            this._tenMinutesToolStripMenuItem.CheckOnClick = true;
            this._tenMinutesToolStripMenuItem.Name = "_tenMinutesToolStripMenuItem";
            this._tenMinutesToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this._tenMinutesToolStripMenuItem.Text = "Every &10 minutes";
            this._tenMinutesToolStripMenuItem.Click += new System.EventHandler(this._tenMinutesToolStripMenuItem_Click);
            // 
            // _noneToolStripMenuItem
            // 
            this._noneToolStripMenuItem.Name = "_noneToolStripMenuItem";
            this._noneToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this._noneToolStripMenuItem.Text = "N&one";
            this._noneToolStripMenuItem.Click += new System.EventHandler(this._noneToolStripMenuItem_Click);
            // 
            // _statusStrip
            // 
            this._statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._toolStripStatusLabel,
            this.toolStripStatusLabel1});
            this._statusStrip.Location = new System.Drawing.Point(0, 242);
            this._statusStrip.Name = "_statusStrip";
            this._statusStrip.Size = new System.Drawing.Size(624, 22);
            this._statusStrip.TabIndex = 9;
            this._statusStrip.Text = "statusStrip1";
            // 
            // _toolStripStatusLabel
            // 
            this._toolStripStatusLabel.Name = "_toolStripStatusLabel";
            this._toolStripStatusLabel.Size = new System.Drawing.Size(609, 17);
            this._toolStripStatusLabel.Spring = true;
            this._toolStripStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 264);
            this.Controls.Add(this._tabControl);
            this.Controls.Add(this._statusStrip);
            this.Controls.Add(this._toolStrip);
            this.MinimumSize = new System.Drawing.Size(640, 300);
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Sage CRE Hosting Framework Monitor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this._contextMenuStrip.ResumeLayout(false);
            this._tabControl.ResumeLayout(false);
            this._generalTabPage.ResumeLayout(false);
            this._servicesTabPage.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this._toolStrip.ResumeLayout(false);
            this._toolStrip.PerformLayout();
            this._statusStrip.ResumeLayout(false);
            this._statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NotifyIcon _notifyIcon;
        private System.Windows.Forms.ContextMenuStrip _contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem _monitorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.TabControl _tabControl;
        private System.Windows.Forms.TabPage _generalTabPage;
        private System.Windows.Forms.TabPage _servicesTabPage;
        private System.Windows.Forms.ListView _generalListView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ToolStrip _toolStrip;
        private System.Windows.Forms.ToolStripSplitButton _refreshToolStripSplitButton;
        private System.Windows.Forms.ToolStripMenuItem _fiveSecondsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _tenSecondsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _thirtySecondsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _sixtySecondsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _twoMinutesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _fiveMinutesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _tenMinutesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _nowToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.StatusStrip _statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel _toolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem _settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _noneToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListView _servicesListView;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ListView _urisListView;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ToolStripButton _settingsToolStripButton;
    }
}

