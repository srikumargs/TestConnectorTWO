namespace Sage.CRE.HostingFramework.TestChatServiceClient
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._chattersListBox = new System.Windows.Forms.ListBox();
            this._menuStrip = new System.Windows.Forms.MenuStrip();
            this._chatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._disconnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._toolStripMenuItemSeparator = new System.Windows.Forms.ToolStripSeparator();
            this._exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._messageTextBox = new System.Windows.Forms.TextBox();
            this._sayButton = new System.Windows.Forms.Button();
            this._chatRichTextBox = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this._menuStrip.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // _chattersListBox
            // 
            this._chattersListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._chattersListBox.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this._chattersListBox.FormattingEnabled = true;
            this._chattersListBox.IntegralHeight = false;
            this._chattersListBox.ItemHeight = 17;
            this._chattersListBox.Location = new System.Drawing.Point(0, 0);
            this._chattersListBox.Name = "_chattersListBox";
            this._chattersListBox.Size = new System.Drawing.Size(152, 354);
            this._chattersListBox.Sorted = true;
            this._chattersListBox.TabIndex = 4;
            // 
            // _menuStrip
            // 
            this._menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._chatToolStripMenuItem});
            this._menuStrip.Location = new System.Drawing.Point(0, 0);
            this._menuStrip.Name = "_menuStrip";
            this._menuStrip.Size = new System.Drawing.Size(624, 24);
            this._menuStrip.TabIndex = 5;
            this._menuStrip.Text = "menuStrip1";
            // 
            // _chatToolStripMenuItem
            // 
            this._chatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._connectToolStripMenuItem,
            this._disconnectToolStripMenuItem,
            this._toolStripMenuItemSeparator,
            this._exitToolStripMenuItem});
            this._chatToolStripMenuItem.Name = "_chatToolStripMenuItem";
            this._chatToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this._chatToolStripMenuItem.Text = "Chat";
            // 
            // _connectToolStripMenuItem
            // 
            this._connectToolStripMenuItem.Name = "_connectToolStripMenuItem";
            this._connectToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this._connectToolStripMenuItem.Text = "&Connect";
            this._connectToolStripMenuItem.Click += new System.EventHandler(this.connectToolStripMenuItem_Click);
            // 
            // _disconnectToolStripMenuItem
            // 
            this._disconnectToolStripMenuItem.Name = "_disconnectToolStripMenuItem";
            this._disconnectToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this._disconnectToolStripMenuItem.Text = "Disconnect";
            this._disconnectToolStripMenuItem.Click += new System.EventHandler(this.disconnectToolStripMenuItem_Click);
            // 
            // _toolStripMenuItemSeparator
            // 
            this._toolStripMenuItemSeparator.Name = "_toolStripMenuItemSeparator";
            this._toolStripMenuItemSeparator.Size = new System.Drawing.Size(130, 6);
            // 
            // _exitToolStripMenuItem
            // 
            this._exitToolStripMenuItem.Name = "_exitToolStripMenuItem";
            this._exitToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this._exitToolStripMenuItem.Text = "Exit";
            this._exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // _messageTextBox
            // 
            this._messageTextBox.AcceptsReturn = true;
            this._messageTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._messageTextBox.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this._messageTextBox.Location = new System.Drawing.Point(12, 412);
            this._messageTextBox.Name = "_messageTextBox";
            this._messageTextBox.Size = new System.Drawing.Size(438, 25);
            this._messageTextBox.TabIndex = 0;
            this._messageTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMessage_KeyDown);
            this._messageTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMessage_KeyPress);
            // 
            // _sayButton
            // 
            this._sayButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._sayButton.Location = new System.Drawing.Point(456, 413);
            this._sayButton.Name = "_sayButton";
            this._sayButton.Size = new System.Drawing.Size(156, 25);
            this._sayButton.TabIndex = 1;
            this._sayButton.Text = "&Say";
            this._sayButton.UseVisualStyleBackColor = true;
            this._sayButton.Click += new System.EventHandler(this.btnSay_Click);
            // 
            // _chatRichTextBox
            // 
            this._chatRichTextBox.BackColor = System.Drawing.SystemColors.Window;
            this._chatRichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._chatRichTextBox.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this._chatRichTextBox.Location = new System.Drawing.Point(0, 0);
            this._chatRichTextBox.Name = "_chatRichTextBox";
            this._chatRichTextBox.ReadOnly = true;
            this._chatRichTextBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this._chatRichTextBox.Size = new System.Drawing.Size(444, 380);
            this._chatRichTextBox.TabIndex = 3;
            this._chatRichTextBox.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.Location = new System.Drawing.Point(0, 367);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "# chatters: 0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label2.Location = new System.Drawing.Point(0, 354);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 7;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(12, 27);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this._chatRichTextBox);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this._chattersListBox);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.label1);
            this.splitContainer1.Size = new System.Drawing.Size(600, 380);
            this.splitContainer1.SplitterDistance = 444;
            this.splitContainer1.TabIndex = 8;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 444);
            this.Controls.Add(this._sayButton);
            this.Controls.Add(this._messageTextBox);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this._menuStrip);
            this.MainMenuStrip = this._menuStrip;
            this.Name = "MainForm";
            this.Text = "Test Chat Service Client";
            this.Load += new System.EventHandler(this.ChatForm_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ChatForm_FormClosed);
            this._menuStrip.ResumeLayout(false);
            this._menuStrip.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox _chattersListBox;
        private System.Windows.Forms.MenuStrip _menuStrip;
        private System.Windows.Forms.ToolStripMenuItem _chatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _connectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem _disconnectToolStripMenuItem;
        private System.Windows.Forms.TextBox _messageTextBox;
        private System.Windows.Forms.Button _sayButton;
        private System.Windows.Forms.RichTextBox _chatRichTextBox;
        private System.Windows.Forms.ToolStripSeparator _toolStripMenuItemSeparator;
        private System.Windows.Forms.ToolStripMenuItem _exitToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.SplitContainer splitContainer1;
    }
}

