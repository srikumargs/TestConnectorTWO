﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using Sage.CRE.HostingFramework.Interfaces;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single, ConfigurationName = "HostSupervisor")]
    public sealed class HostSupervisor : IHostSupervisor
    {
        #region IHostSupervisor Members

        public void RegisterService(ServiceInfo serviceInfo)
        {
            lock (_syncRoot)
            {
                if (!_serviceDescriptions.ContainsKey(serviceInfo.ConfigurationName))
                {
                    _serviceDescriptions.Add(serviceInfo.ConfigurationName, serviceInfo);
                }
            }
        }

        public void UnregisterService(String name)
        {
            lock (_syncRoot)
            {
                if (_serviceDescriptions.ContainsKey(name))
                {
                    _serviceDescriptions.Remove(name);
                }
            }
        }

        public void UpdateServiceStatus(String name, CommunicationState communicationState)
        {
            lock (_syncRoot)
            {
                _serviceDescriptions[name].CommunicationState = communicationState;
            }
        }

        public IEnumerable<ServiceInfo> GetServiceInfo()
        {
            ServiceInfo[] result = null;
            lock (_syncRoot)
            {
                result = new ServiceInfo[_serviceDescriptions.Count];
                _serviceDescriptions.Values.CopyTo(result, 0);
            }
            return result;
        }

        #endregion

        private readonly Object _syncRoot = new Object();
        private Dictionary<String, ServiceInfo> _serviceDescriptions = new Dictionary<String, ServiceInfo>();
    }
}
