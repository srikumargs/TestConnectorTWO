﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using Sage.ExtensionMethods;
using Sage.Configuration;
using System.Collections.ObjectModel;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    internal sealed class ServiceConfig : MarshalByRefObject
    {
        /// <summary>
        /// Override and return null to specify infinite lifetime for the singleton.
        /// </summary>
        public override object InitializeLifetimeService()
        {
            return null;
        }

        public ServiceConfig(Dictionary<String, ServiceActivationInfo> services)
        {
            _services = services;
        }

        public ServiceConfig(String configFile)
        {
            _configFile = configFile;

            XmlDocument document = new XmlDocument();
            document.Load(_configFile);
            XPathNavigator navigator = document.CreateNavigator();

            _appDomainId = Path.GetFileNameWithoutExtension(configFile);

            XPathNavigator appSettingsNavigator = navigator.SelectSingleNode("//appSettings/add[@key='PortAssignmentPriority']");
            if (appSettingsNavigator != null)
            {
                _portAssignmentPriority = Convert.ToInt32(appSettingsNavigator.GetAttribute("value", String.Empty), CultureInfo.InvariantCulture);
            }

            appSettingsNavigator = navigator.SelectSingleNode("//appSettings/add[@key='DependsOn']");
            if (appSettingsNavigator != null)
            {
                _dependsOn.AddRange(appSettingsNavigator.GetAttribute("value", String.Empty).Split(';'));
            }


            XPathNodeIterator servicesIterator = navigator.Select("//system.serviceModel/services/service");
            while (servicesIterator.MoveNext())
            {
                String serviceName;
                String serviceTypeName;
                String serviceAssemblyName;

                serviceName = servicesIterator.Current.GetAttribute("name", String.Empty);

                appSettingsNavigator = navigator.SelectSingleNode(String.Format("//appSettings/add[@key='{0}_FullyQualifiedTypeName']", serviceName));
                String fullyQualifiedTypeName = String.Empty;
                if (appSettingsNavigator != null)
                {
                    fullyQualifiedTypeName = appSettingsNavigator.GetAttribute("value", String.Empty);
                }

                appSettingsNavigator = navigator.SelectSingleNode(String.Format("//appSettings/add[@key='{0}_Description']", serviceName));
                String description = String.Empty;
                if (appSettingsNavigator != null)
                {
                    description = appSettingsNavigator.GetAttribute("value", String.Empty);
                }

                serviceTypeName = fullyQualifiedTypeName.Substring(0, fullyQualifiedTypeName.IndexOf(',')).Trim();
                serviceAssemblyName = PathRegistrar.ResolveUrl(fullyQualifiedTypeName.Substring(fullyQualifiedTypeName.IndexOf(',') + 1).Trim());
                _services.Add(serviceName, new ServiceActivationInfo(serviceTypeName, description, serviceAssemblyName));
            }
        }

        public String ConfigFile
        { get { return _configFile; } }

        public String ConfigFileNameOnly
        { get { return Path.GetFileNameWithoutExtension(_configFile); } }

        public String AppDomainId
        { get { return _appDomainId; } }

        public Dictionary<String, ServiceActivationInfo> Services
        { get { return _services; } }

        public Int32 PortAssignmentPriority
        { get { return _portAssignmentPriority; } }

        public Uri[] BaseAddresses
        {
            get { return _baseAddresses; }
            set
            {
                _baseAddresses = value;
                _services.Values.ForEach(delegate(ServiceActivationInfo serviceActivationInfo) { serviceActivationInfo.BaseAddresses = _baseAddresses; });
            }
        }

        public ReadOnlyCollection<String> DependsOn
        { get { return _dependsOn.AsReadOnly(); } }

        private readonly String _configFile;
        private readonly String _appDomainId;
        private readonly Dictionary<String, ServiceActivationInfo> _services = new Dictionary<String, ServiceActivationInfo>();
        private readonly List<String> _dependsOn = new List<String>();
        private Uri[] _baseAddresses;
        private Int32 _portAssignmentPriority = 99999;
    }
}
