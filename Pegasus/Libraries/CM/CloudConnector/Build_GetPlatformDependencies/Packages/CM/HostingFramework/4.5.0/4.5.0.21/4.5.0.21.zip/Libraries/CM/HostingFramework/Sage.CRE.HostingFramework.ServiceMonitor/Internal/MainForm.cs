﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.ServiceModel;
using System.Threading;
using System.Windows.Forms;
using Sage.ExtensionMethods;
using Sage.CRE.HostingFramework.Interfaces;
using Sage.CRE.HostingFramework.Proxy;
using Sage.CRE.HostingFramework.Proxy.Advanced;
using System.IO;
using System.Reflection;
using Sage.CRE.HostingFramework.LinkedSource;
using Sage.CRE.HostingFramework.ServiceMonitor.Internal;
using Sage.ServiceModel;

namespace Sage.CRE.HostingFramework.ServiceMonitor
{
    internal partial class MainForm : Form
    {
        private String _machineName;
        private Int32 _portNumber;
        public MainForm()
        {
            InitializeComponent();
            this._refreshToolStripSplitButton.Image = Sage.CRE.Resources.ServiceMonitor.Refresh;

            UpdateIcon(Sage.CRE.Resources.ServiceMonitor.ServiceOffline);

            String hostingFrameworkServiceExeFilePath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "Sage.CRE.HostingFramework.Service.exe");
            if (File.Exists(hostingFrameworkServiceExeFilePath))
            {
                ServiceConstants serviceConstants = ServiceConstantsFactory.GetConstants(hostingFrameworkServiceExeFilePath);
                _machineName = "localhost";
                _portNumber = serviceConstants.CatalogServicePortNumber;

                UpdateMachineName(_machineName);
                UpdatePortNumber(_portNumber);

                StartWorkerThread();
            }
            else
            {
                _settingsToolStripMenuItem_Click(null, null);
            }
        }

        private void StartWorkerThread()
        {
            _terminateWorkerThreadEvent = new ManualResetEvent(false);
            _pulseWorkerThreadEvent = new AutoResetEvent(false);
            _thread = new Thread(new ThreadStart(WorkerThreadFunction));
            _thread.Start();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            Visible = false;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _notifyIcon.Visible = false;
            _exiting = true;
            {
                TerminateWorkerThread();
                Close();
                Application.Exit();
            }
        }

        private void TerminateWorkerThread()
        {
            _terminateWorkerThreadEvent.Set();
            _pulseWorkerThreadEvent.Set();
            _thread.Join();
        }

        private void AbortWorkerThread()
        {
            if (_thread != null)
            {
                _thread.Abort();
            }
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
            {
                Hide();
            }
        }

        private void _notifyIcon_DoubleClick(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }

        private void UpdateIcon(Icon icon)
        {
            _notifyIcon.Icon = icon;
            this.Icon = icon;
        }

        private void ShowBalloonTip(String title, String text, ToolTipIcon icon)
        {
            _notifyIcon.ShowBalloonTip(10000, title, text, icon);
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_exiting)
            {
                e.Cancel = true;
                this.Hide();
            }
        }

        private void _monitorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
        }

        private void _settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SettingsForm form = new SettingsForm();
            form.MachineName = _machineName;
            form.PortNumber = _portNumber;
            if (form.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                AbortWorkerThread();

                _machineName = form.MachineName;
                _portNumber = form.PortNumber;

                UpdateMachineName(_machineName);
                UpdatePortNumber(_portNumber);
                _generalListView.Items[(Int32)GeneralListViewItemIndex.Server].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = "Unknown";
                _generalListView.Items[(Int32)GeneralListViewItemIndex.Status].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = "Unknown";
                _generalListView.Items[(Int32)GeneralListViewItemIndex.Uptime].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = "Unknown";
                _generalListView.Items[(Int32)GeneralListViewItemIndex.Version].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = "Unknown";
                _generalListView.Columns[(Int32)GeneralListViewColumnIndex.Value].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);

                StartWorkerThread();
            }
        }

        private void WorkerThreadFunction()
        {
            UpdateStatusStripText("Refreshing data...");

            do
            {
                RefreshMonitorData();
            } while (0 != WaitHandle.WaitAny(new WaitHandle[] { _terminateWorkerThreadEvent, _pulseWorkerThreadEvent }, AutoRefreshInterval));
        }

        private Int32 AutoRefreshInterval
        {
            get
            {
                Int32 result = 0;

                lock (_syncRoot)
                {
                    result = _autoRefreshInterval;
                }

                return result;
            }

            set
            {
                lock (_syncRoot)
                {
                    _autoRefreshInterval = value;
                }
            }
        }

        private DateTime LastRefreshDateTime
        {
            get
            {
                DateTime result = DateTime.MinValue;

                lock (_syncRoot)
                {
                    result = _lastRefreshDateTime;
                }

                return result;
            }

            set
            {
                lock (_syncRoot)
                {
                    _lastRefreshDateTime = value;
                }
            }
        }

        private void RefreshMonitorData()
        {
            MonitorServiceProxy monitorServiceProxy = null;
            CatalogServiceProxy catalogServiceProxy = null;
            try
            {
                LastRefreshDateTime = _lastRefreshDateTime = DateTime.Now;

                UpdateStatusStripImage(Sage.CRE.Resources.ServiceMonitor.Network.ToBitmap());

                catalogServiceProxy = CatalogServiceProxyFactory.CreateFromCatalog(_machineName, _portNumber);
                UpdateServiceInfo(catalogServiceProxy.GetServiceInfo());
                catalogServiceProxy.Close();
                catalogServiceProxy = null;

                monitorServiceProxy = MonitorServiceProxyFactory.CreateFromCatalog(_machineName, _portNumber);
                UpdateMachineName(_machineName);
                UpdatePortNumber(_portNumber);
                UpdateStatus(monitorServiceProxy.GetStatus());
                UpdateVersion(monitorServiceProxy.GetVersion());
                UpdateUpSinceDateTime(monitorServiceProxy.GetUpSinceDateTime());
                UpdateServer(monitorServiceProxy.GetServer());
                monitorServiceProxy.Close();
                monitorServiceProxy = null;
            }
            catch (Exception)
            { }
            finally
            {
                if (monitorServiceProxy != null || catalogServiceProxy != null)
                {
                    if (monitorServiceProxy != null)
                    {
                        monitorServiceProxy.Abort();
                        monitorServiceProxy = null;
                    }

                    if (catalogServiceProxy != null)
                    {
                        catalogServiceProxy.Abort();
                        catalogServiceProxy = null;
                    }

                    UpdateStatusStripText("Error refreshing data");
                    UpdateStatusStripImage(Sage.CRE.Resources.ServiceMonitor.Error);
                }
                else
                {
                    UpdateStatusStripText(String.Format("Data last refreshed {0}", LastRefreshDateTime.ToString("F", CultureInfo.CurrentCulture)));
                    UpdateStatusStripImage(null);
                }
            }
        }

        private void UpdateStatus(Status status)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateStatus(status); });
            }
            else
            {
                if (_generalListView.Items[(Int32)GeneralListViewItemIndex.Status].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text != status.ToString())
                {
                    _generalListView.Items[(Int32)GeneralListViewItemIndex.Status].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = status.ToString();
                    _generalListView.Columns[(Int32)GeneralListViewColumnIndex.Value].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);

                    UpdateNotifyIconForStatus(status);
                }
            }
        }


        private void UpdateMachineName(String machineName)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateMachineName(machineName); });
            }
            else
            {
                if (_generalListView.Items[(Int32)GeneralListViewItemIndex.MachineName].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text != machineName)
                {
                    _generalListView.Items[(Int32)GeneralListViewItemIndex.MachineName].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = machineName;
                    _generalListView.Columns[(Int32)GeneralListViewColumnIndex.Value].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
                }
            }
        }

        private void UpdatePortNumber(Int32 portNumber)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdatePortNumber(portNumber); });
            }
            else
            {
                String portNumberAsString = Convert.ToString(portNumber, CultureInfo.InvariantCulture);
                if (_generalListView.Items[(Int32)GeneralListViewItemIndex.PortNumber].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text != portNumberAsString)
                {
                    _generalListView.Items[(Int32)GeneralListViewItemIndex.PortNumber].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = portNumberAsString;
                    _generalListView.Columns[(Int32)GeneralListViewColumnIndex.Value].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
                }
            }
        }

        private void UpdateVersion(Version version)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateVersion(version); });
            }
            else
            {
                if (_generalListView.Items[(Int32)GeneralListViewItemIndex.Version].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text != version.ToString())
                {
                    _generalListView.Items[(Int32)GeneralListViewItemIndex.Version].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = version.ToString();
                    _generalListView.Columns[(Int32)GeneralListViewColumnIndex.Value].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
                }
            }
        }

        private void UpdateUpSinceDateTime(DateTime upSince)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateUpSinceDateTime(upSince); });
            }
            else
            {
                TimeSpan uptime = DateTime.Now - upSince;
                _generalListView.Items[(Int32)GeneralListViewItemIndex.Uptime].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = String.Format("{0} day(s), {1} hour(s), {2} minute(s), {3} second(s) (since {4})", uptime.Days, uptime.Hours, uptime.Minutes, uptime.Seconds, upSince.ToString("F", CultureInfo.CurrentCulture)); ;
                _generalListView.Columns[(Int32)GeneralListViewColumnIndex.Value].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
            }
        }

        private void UpdateNotifyIconForStatus(Status status)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateNotifyIconForStatus(status); });
            }
            else
            {
                Icon icon = Sage.CRE.Resources.ServiceMonitor.ServiceOffline;
                switch (status)
                {
                    case Status.Ready:
                        icon = Sage.CRE.Resources.ServiceMonitor.ServiceNormal;
                        break;

                    case Status.Recycling:
                    case Status.SevicingRequest:
                        icon = Sage.CRE.Resources.ServiceMonitor.ServiceBusy;
                        break;
                }
                UpdateIcon(icon);
            }
        }

        private void UpdateServer(String server)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateServer(server); });
            }
            else
            {
                if (_generalListView.Items[(Int32)GeneralListViewItemIndex.Server].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text != server)
                {
                    _generalListView.Items[(Int32)GeneralListViewItemIndex.Server].SubItems[(Int32)GeneralListViewColumnIndex.Value].Text = server;
                    _generalListView.Columns[(Int32)GeneralListViewColumnIndex.Value].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
                }
            }
        }

        private void UpdateStatusStripText(String text)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateStatusStripText(text); });
            }
            else
            {
                if (_toolStripStatusLabel.Text != text)
                {
                    _toolStripStatusLabel.Text = text;
                }
            }
        }

        private void UpdateStatusStripImage(Image image)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateStatusStripImage(image); });
            }
            else
            {
                if (toolStripStatusLabel1.Image != image)
                {
                    toolStripStatusLabel1.Image = image;
                }
            }
        }

        private void UpdateServiceInfo(IEnumerable<ServiceInfo> serviceInfo)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateServiceInfo(serviceInfo); });
            }
            else
            {
                List<String> serviceInfoNames = new List<String>();
                serviceInfo.ForEach(delegate(ServiceInfo serviceInfoParam){serviceInfoNames.Add(serviceInfoParam.ConfigurationName);});

                List<String> listViewNames = new List<String>();
                CollectionExtensions.ForEach(_servicesListView.Items.Cast<ListViewItem>(), delegate(ListViewItem listViewItem) { listViewNames.Add(listViewItem.Text); });

                IEnumerable<String> itemsToUpdate = serviceInfoNames.Intersect(listViewNames);
                IEnumerable<String> itemsToAdd = serviceInfoNames.Complement(listViewNames);
                IEnumerable<String> itemToRemove = listViewNames.Complement(serviceInfoNames);

                Boolean resize = false;
                CollectionExtensions.ForEach(serviceInfo, delegate(ServiceInfo serviceInfoParam) 
                    {
                        if (itemsToAdd.Contains(serviceInfoParam.ConfigurationName))
                        {
                            AddServiceInfoToList(serviceInfoParam);
                            resize |= true;
                        }
                        else if(itemsToUpdate.Contains(serviceInfoParam.ConfigurationName))
                        {
                            resize |= UpdateServiceInfo(serviceInfoParam);
                        }
                    });
                itemToRemove.ForEach(delegate(String serviceName) { _servicesListView.Items.RemoveByKey(serviceName); });

                if (resize)
                {
                    CollectionExtensions.ForEach(_servicesListView.Columns.Cast<ColumnHeader>(), delegate(ColumnHeader columnHeader) { columnHeader.AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent); });
                }
            }
        }

        private void AddServiceInfoToList(ServiceInfo serviceInfo)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { AddServiceInfoToList(serviceInfo); });
            }
            else
            {
                ListViewItem listViewItem = new ListViewItem(new String[] { serviceInfo.ConfigurationName, serviceInfo.Description, serviceInfo.CommunicationState.ToString(), serviceInfo.AppDomainId });
                listViewItem.Name = serviceInfo.ConfigurationName;
                _servicesListView.Items.Add(listViewItem);

                UpdateServiceInfoUris(listViewItem, serviceInfo.Uris);
            }
        }

        private Boolean UpdateServiceInfo(ServiceInfo serviceInfo)
        {
            Debug.Assert(!this.InvokeRequired); // this method not designed to be called from worker thread

            ListViewItem listViewItem = _servicesListView.Items[serviceInfo.ConfigurationName];
            Boolean result = false;
            result |= UpdateListViewItem(listViewItem, (Int32)ServicesListViewColumnIndex.Description, serviceInfo.Description);
            result |= UpdateListViewItem(listViewItem, (Int32)ServicesListViewColumnIndex.Status, serviceInfo.CommunicationState.ToString());
            result |= UpdateListViewItem(listViewItem, (Int32)ServicesListViewColumnIndex.AppDomainId, serviceInfo.AppDomainId);

            UpdateServiceInfoUris(listViewItem, serviceInfo.Uris);

            return result;
        }

        private Boolean UpdateListViewItem(ListViewItem listViewItem, Int32 columnIndex, String newValue)
        {
            Boolean result = false;
            if (listViewItem.SubItems[columnIndex].Text != newValue)
            {
                listViewItem.SubItems[columnIndex].Text = newValue;
                result = true;
            }
            return result;
        }

        private void UpdateServiceInfoUris(ListViewItem listViewItem, IEnumerable<Uri> uris)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { UpdateServiceInfoUris(listViewItem, uris); });
            }
            else
            {
                if (!listViewItem.Selected)
                {
                    listViewItem.Tag = uris;
                }
                else
                {
                    List<String> uriNames = new List<String>();
                    uris.ForEach(delegate(Uri serviceInfoParam) { uriNames.Add(serviceInfoParam.AbsoluteUri); });

                    List<String> listViewNames = new List<String>();
                    CollectionExtensions.ForEach(_urisListView.Items.Cast<ListViewItem>(), delegate(ListViewItem listViewItemParam) { listViewNames.Add(listViewItemParam.Text); });

                    IEnumerable<String> itemsToUpdate = uriNames.Intersect(listViewNames);
                    IEnumerable<String> itemsToAdd = uriNames.Complement(listViewNames);
                    IEnumerable<String> itemToRemove = listViewNames.Complement(uriNames);

                    Boolean resize = false;
                    CollectionExtensions.ForEach(uris, delegate(Uri uri)
                    {
                        if (itemsToAdd.Contains(uri.AbsoluteUri))
                        {
                            AddUriToList(uri);
                            resize |= true;
                        }
                        else if (itemsToUpdate.Contains(uri.AbsoluteUri))
                        {
                            resize |= UpdateUri(uri);
                        }
                    });
                    itemToRemove.ForEach(delegate(String uri) { _urisListView.Items.RemoveByKey(uri); });

                    if (resize)
                    {
                        CollectionExtensions.ForEach(_urisListView.Columns.Cast<ColumnHeader>(), delegate(ColumnHeader columnHeader) { columnHeader.AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent); });
                    }
                }
            }
        }

        private void AddUriToList(Uri uri)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke((MethodInvoker)delegate() { AddUriToList(uri); });
            }
            else
            {
                ListViewItem listViewItem = new ListViewItem(new String[] { uri.AbsoluteUri});
                listViewItem.Name = uri.AbsoluteUri;
                _urisListView.Items.Add(listViewItem);
            }
        }

        private Boolean UpdateUri(Uri uri)
        {
            Debug.Assert(!this.InvokeRequired); // this method not designed to be called from worker thread

            ListViewItem listViewItem = _urisListView.Items[uri.AbsoluteUri];
            Boolean result = false;
            result |= UpdateListViewItem(listViewItem, (Int32)UrisListViewColumnIndex.Uri, uri.AbsoluteUri);
            //result |= UpdateListViewItem(listViewItem, (Int32)ServicesListViewColumnIndex.Status, serviceInfo.Status);
            //result |= UpdateListViewItem(listViewItem, (Int32)ServicesListViewColumnIndex.AppDomainId, serviceInfo.AppDomainId);

            return result;
        }

        private enum GeneralListViewItemIndex
        {
            MachineName,
            PortNumber,
            Status,
            Uptime,
            Version,
            Server
        }

        private enum GeneralListViewColumnIndex
        {
            Label,
            Value
        }

        private enum ServicesListViewColumnIndex
        {
            Name,
            Description,
            Status,
            AppDomainId
        }

        private enum UrisListViewColumnIndex
        {
            Uri
        }

        private void UncheckAllRefreshItems()
        {
            _fiveSecondsToolStripMenuItem.Checked = false;
            _tenSecondsToolStripMenuItem.Checked = false;
            _thirtySecondsToolStripMenuItem.Checked = false;
            _sixtySecondsToolStripMenuItem.Checked = false;
            _twoMinutesToolStripMenuItem.Checked = false;
            _fiveMinutesToolStripMenuItem.Checked = false;
            _tenMinutesToolStripMenuItem.Checked = false;
        }

        private void _fiveSecondsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UncheckAllRefreshItems();
            (sender as ToolStripMenuItem).Checked = true;
            AutoRefreshInterval = 5000;
            _pulseWorkerThreadEvent.Set();
        }

        private void _tenSecondsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UncheckAllRefreshItems();
            (sender as ToolStripMenuItem).Checked = true;
            AutoRefreshInterval = 10000;
            _pulseWorkerThreadEvent.Set();
        }

        private void _thirtySecondsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UncheckAllRefreshItems();
            (sender as ToolStripMenuItem).Checked = true;
            AutoRefreshInterval = 30000;
            _pulseWorkerThreadEvent.Set();
        }

        private void _sixtySecondsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UncheckAllRefreshItems();
            (sender as ToolStripMenuItem).Checked = true;
            AutoRefreshInterval = 60000;
            _pulseWorkerThreadEvent.Set();
        }

        private void _twoMinutesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UncheckAllRefreshItems();
            (sender as ToolStripMenuItem).Checked = true;
            AutoRefreshInterval = 120000;
            _pulseWorkerThreadEvent.Set();
        }

        private void _fiveMinutesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UncheckAllRefreshItems();
            (sender as ToolStripMenuItem).Checked = true;
            AutoRefreshInterval = 300000;
            _pulseWorkerThreadEvent.Set();
        }

        private void _tenMinutesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UncheckAllRefreshItems();
            (sender as ToolStripMenuItem).Checked = true;
            AutoRefreshInterval = 600000;
            _pulseWorkerThreadEvent.Set();
        }

        private void _noneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UncheckAllRefreshItems();
            AutoRefreshInterval = -1;
            _pulseWorkerThreadEvent.Set();
        }

        private void _nowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _pulseWorkerThreadEvent.Set();
        }

        private void _refreshToolStripSplitButton_ButtonClick(object sender, EventArgs e)
        {
            _pulseWorkerThreadEvent.Set();
        }

        private void _servicesListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            _urisListView.Items.Clear();
            if (_servicesListView.SelectedItems.Count == 1)
            {
                foreach (Uri uri in (_servicesListView.SelectedItems[0].Tag as IEnumerable<Uri>))
                {
                    AddUriToList(uri);
                }

                CollectionExtensions.ForEach(_urisListView.Columns.Cast<ColumnHeader>(), delegate(ColumnHeader columnHeader) { columnHeader.AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent); });
            }
        }

        private Thread _thread;
        private readonly Object _syncRoot = new Object();
        private Boolean _exiting;
        private Int32 _autoRefreshInterval = -1;
        private DateTime _lastRefreshDateTime;
        private ManualResetEvent _terminateWorkerThreadEvent;
        private AutoResetEvent _pulseWorkerThreadEvent;

        private void _settingsToolStripButton_Click(object sender, EventArgs e)
        {
            _settingsToolStripMenuItem_Click(null, null);
        }
    }
}
