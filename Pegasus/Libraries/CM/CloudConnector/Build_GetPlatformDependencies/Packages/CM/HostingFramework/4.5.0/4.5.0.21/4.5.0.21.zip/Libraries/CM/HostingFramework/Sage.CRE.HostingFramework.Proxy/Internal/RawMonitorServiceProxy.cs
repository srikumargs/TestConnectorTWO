﻿using System;
using System.ServiceModel;
using Sage.CRE.HostingFramework.Interfaces;

namespace Sage.CRE.HostingFramework.Proxy.Internal
{
    /// <summary>
    /// The most basic proxy for IMonitorService.
    /// </summary>
    /// <remarks>
    /// Provides no logic, no error handling, no fault tolerance. Clients should usually consider using the more robust,
    /// non-raw, public RetryClientBase-derived proxy instead of this one.
    /// </remarks>
    internal sealed class RawMonitorServiceProxy : ClientBase<IMonitorService>, IMonitorService
    {
        /// <summary>
        /// 
        /// </summary>
        public RawMonitorServiceProxy()
            : base()
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        public RawMonitorServiceProxy(String endpointConfigurationName)
            : base(endpointConfigurationName)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public RawMonitorServiceProxy(String endpointConfigurationName, String remoteAddress)
            : base(endpointConfigurationName, remoteAddress)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public RawMonitorServiceProxy(String endpointConfigurationName, EndpointAddress remoteAddress)
            : base(endpointConfigurationName, remoteAddress)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="binding"></param>
        /// <param name="remoteAddress"></param>
        public RawMonitorServiceProxy(System.ServiceModel.Channels.Binding binding, EndpointAddress remoteAddress)
            : base(binding, remoteAddress)
        { }

        #region IMonitorService Members

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Version GetVersion()
        { return base.Channel.GetVersion(); }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DateTime GetUpSinceDateTime()
        { return base.Channel.GetUpSinceDateTime(); }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Status GetStatus()
        { return base.Channel.GetStatus(); }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public String GetServer()
        { return base.Channel.GetServer(); }

        #endregion
    }
}
