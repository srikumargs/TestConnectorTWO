﻿using System;
using System.ServiceModel;

namespace Sage.CRE.HostingFramework.TestChatServiceProxy.Internal
{
    /// <summary>
    /// The most basic proxy for IChatAsync.
    /// </summary>
    /// <remarks>
    /// Provides no logic, no error handling, no fault tolerance. Clients should usually consider using the more robust,
    /// non-raw, public RetryClientBase-derived proxy instead of this one.
    /// </remarks>
    internal sealed class RawChatServiceProxy : ClientBase<IChatAsync>, IChatAsync
    {
        /// <summary>
        /// 
        /// </summary>
        public RawChatServiceProxy()
            : base()
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        public RawChatServiceProxy(string endpointConfigurationName)
            : base(endpointConfigurationName)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public RawChatServiceProxy(string endpointConfigurationName, string remoteAddress)
            : base(endpointConfigurationName, remoteAddress)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public RawChatServiceProxy(string endpointConfigurationName, EndpointAddress remoteAddress)
            : base(endpointConfigurationName, remoteAddress)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="binding"></param>
        /// <param name="remoteAddress"></param>
        public RawChatServiceProxy(System.ServiceModel.Channels.Binding binding, EndpointAddress remoteAddress)
            : base(binding, remoteAddress)
        { }

        #region IChat Members

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="callback"></param>
        /// <param name="asyncState"></param>
        /// <returns></returns>
        public System.IAsyncResult BeginJoin(String name, AsyncCallback callback, Object asyncState)
        { return base.Channel.BeginJoin(name, callback, asyncState); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="asyncResult"></param>
        /// <returns></returns>
        public String[] EndJoin(IAsyncResult asyncResult)
        { return base.Channel.EndJoin(asyncResult); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public string[] Join(String name)
        { return base.Channel.Join(name); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="msg"></param>
        public void Say(String name, String msg)
        { base.Channel.Say(name, msg); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        public void Leave(String name)
        { base.Channel.Leave(name); }

        #endregion
    }
}
