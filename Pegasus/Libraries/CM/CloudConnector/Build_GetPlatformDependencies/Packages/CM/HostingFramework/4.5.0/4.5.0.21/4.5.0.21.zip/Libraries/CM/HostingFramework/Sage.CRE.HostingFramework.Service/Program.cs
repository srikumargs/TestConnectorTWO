﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using Sage.CRE.HostingFramework.Service.Internal;
using Sage.Diagnostics;
using System.Threading;
using System.Security.AccessControl;
using Sage.CRE.HostingFramework.Interfaces;

namespace Sage.CRE.HostingFramework.Service
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            try
            {
                if (ConfigCommand != ConfigCommand.None)
                {
                    try
                    {
                        if (!Silent)
                        {
                            // Attach to the parent process via AttachConsole SDK call
                            InitConsoleHandles();
                            ConsoleWriteLine("");
                            ConsoleWriteLine("ConfigCommand={0}", ConfigCommand.ToString());
                        }

                        if (!IsAdmin && !ConsoleRun)
                        {
                            Process process = LaunchAsAdmin(Environment.GetCommandLineArgs());
                            process.WaitForExit();
                            System.Environment.ExitCode = process.ExitCode;
                        }
                        else
                        {
                            ExitCode exitCode;
                            Configure(ConfigCommand, out exitCode);
                            Environment.ExitCode = (Int32) exitCode;
                        }
                    }
                    finally
                    {
                        if (_consoleAttached)
                        {
                            ConsoleWriteLine("ConfigCommand={0}, exitCode={1}", ConfigCommand.ToString(), Environment.ExitCode);
                            if (!ConsoleRun)
                            {
                                ConsoleWriteLine("");
                                ConsoleWriteLine("Console output completed, press any key to continue...");
                            }
                            _consoleAttached = false;
                        }
                    }
                }
                else
                {
                    ServiceBase[] servicesToRun = new ServiceBase[] { new Sage.CRE.HostingFramework.Service.Internal.Service() };
                    ServiceBase.Run(servicesToRun);
                }
            }
            catch (Exception ex)
            {
                WriteEventLogEntry(ex.ToString(), MessageType.Error);
            }
        }

        private static Boolean IsWindowsServiceInstalled(String serviceName)
        {
            Boolean result = false;
            try
            {
                using (System.ServiceProcess.ServiceController serviceController = new System.ServiceProcess.ServiceController(serviceName))
                {
                    // access a property to determine if the service is installed
                    String displayName = serviceController.DisplayName;
                    result = true;
                }
            }
            catch (Exception)
            {
                // turn exception-oriented result into a boolean
            }

            return result;
        }

        /// <summary>
        /// Build the config args list for the specific config command
        /// Default return is an empty list
        /// </summary>
        /// <param name="configOption"></param>
        /// <returns></returns>
        private static List<String> BuildConfigArgs(ConfigCommand configOption)
        {
            var result = new List<string>();

            // Get the full collection of command line args
            string[] args = Environment.GetCommandLineArgs();

            switch (configOption)
            {
                case ConfigCommand.Install:
                    // Add all command line args minus the main config command
                    result.AddRange(args.Where(arg => 
                        !arg.Equals("/install", StringComparison.InvariantCultureIgnoreCase)));
                    break;

                case ConfigCommand.Start:
                    // Add all command line args minus the main config command
                    result.AddRange(args.Where(arg =>
                        !arg.Equals("/start", StringComparison.InvariantCultureIgnoreCase)));
                    break; 

                case ConfigCommand.Restart:
                    // Add all command line args minus the main config command
                    result.AddRange(args.Where(arg =>
                        !arg.Equals("/restart", StringComparison.InvariantCultureIgnoreCase)));
                    break;

                default:
                    break;
            }

            return result;
        } 

        private static void Configure(ConfigCommand configOptions, out ExitCode exitCode)
        {
            exitCode = ExitCode.Fail;
            try
            {
                switch (configOptions)
                {
                    case ConfigCommand.Install:
                        exitCode = InstallService();
                        break;

                    case ConfigCommand.Uninstall:
                        {
                            if (IsWindowsServiceInstalled(InternalConfig.ServiceName))
                            {
                                List<String> args = new List<String>();//= BuildConfigArgs(configOptions);

                                String tempFileName = Path.GetTempFileName();
                                args.Add(String.Format("/LogFile={0}", tempFileName));
                                try
                                {
                                    Sage.CRE.LinkedSource.IsolatedAppDomainHelper.InvokeDelegate(new RemoteInstallDelegate(UninstallService), new Object[] { args.ToArray() });
                                    exitCode = ExitCode.Success;
                                }
                                finally
                                {
                                    WriteEventLogEntry(File.ReadAllText(tempFileName, Encoding.UTF8), MessageType.Information);
                                    File.Delete(tempFileName);
                                }
                            }
                            else
                            {
                                ConsoleWriteLine("{0} does not exist as a Windows service; nothing to do.", InternalConfig.ServiceName);
                                exitCode = ExitCode.Success;
                            }
                        }
                        break;

                    case ConfigCommand.Start:
                        exitCode = StartService(configOptions);
                        return;

                    case ConfigCommand.Stop:
                        try
                        {
                            StopService();
                            exitCode = ExitCode.Success;
                        }
                        catch (Exception ex)
                        {
                            WriteEventLogEntry(ex.ToString(), MessageType.Error);
                        }
                        return;

                    case ConfigCommand.Restart:
                        try
                        {
                            StopService();
                        }
                        catch (Exception ex)
                        {
                            WriteEventLogEntry(ex.ToString(), MessageType.Error);
                        }

                        exitCode = StartService(configOptions);
                        break;

                    case ConfigCommand.ConsoleRun:

                        var service = new Sage.CRE.HostingFramework.Service.Internal.Service();

                        service.ConsoleStart();

                        WaitForServiceReadyMutex(_waitForServiceTimeout, 1000);

                        ConsoleWriteLine("");
                        ConsoleWriteLine("HostingFx has been started using /consoleRun mode. In order to shut down this instance you can either:");
                        ConsoleWriteLine("- run the EXE with '/consoleStop'");
                        ConsoleWriteLine("- kill process ID {0}", System.Diagnostics.Process.GetCurrentProcess().Id);
                        ConsoleWriteLine("");
                        ConsoleWriteLine("Console output completed, service running as a background process, press any key to continue...");
                        
                        Boolean terminate = false;
                        do
                        {
                            using (var subKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(InternalConfig.ServiceDataRegistrySubKey, false))
                            {
                                if (subKey != null && subKey.GetValue(CONSOLE_STOP_VALUE_NAME) != null && (subKey.GetValue(CONSOLE_STOP_VALUE_NAME) as String) == "1")
                                {
                                    terminate = true;
                                }
                            }
                            System.Threading.Thread.Sleep(1000);
                        } while (!terminate);

                        service.ConsoleStop();

                        return;

                    case ConfigCommand.ConsoleStop:
                        using (var subKey = Microsoft.Win32.Registry.LocalMachine.CreateSubKey(InternalConfig.ServiceDataRegistrySubKey))
                        {
                            subKey.SetValue(CONSOLE_STOP_VALUE_NAME, "1", Microsoft.Win32.RegistryValueKind.String);

                            WaitForServiceProcessNotRunningMutex(_waitForServiceTimeout, 1000);

                            subKey.DeleteValue(CONSOLE_STOP_VALUE_NAME);
                        }

                        return;
                }
            }
            catch (Exception ex)
            {
                WriteEventLogEntry(ex.ToString(), MessageType.Error);
            }
        }

        private readonly static String CONSOLE_STOP_VALUE_NAME = "ConsoleStop";

        private delegate void RemoteInstallDelegate(String[] args);

        /// <summary>
        /// Coordinate service install and provide the correct exit code
        /// </summary>
        /// <returns></returns>
        private static ExitCode InstallService()
        {
            // Default to failed
            ExitCode exitCode = ExitCode.Fail;

            try
            {
                if (!IsWindowsServiceInstalled(InternalConfig.ServiceName))
                {
                    List<String> args = BuildConfigArgs(ConfigCommand.Install);

                    String tempFileName = Path.GetTempFileName();
                    args.Add(String.Format("/LogFile={0}", tempFileName));
                    try
                    {
                        Sage.CRE.LinkedSource.IsolatedAppDomainHelper.InvokeDelegate(
                            new RemoteInstallDelegate(InstallServiceImpl), new Object[] {args.ToArray()});
                        exitCode = ExitCode.Success;
                    }
                    finally
                    {
                        WriteEventLogEntry(File.ReadAllText(tempFileName, Encoding.UTF8), MessageType.Information);
                        File.Delete(tempFileName);
                    }
                }
                else
                {
                    ConsoleWriteLine("{0} is already installed as a Windows service; nothing to do.",
                                     InternalConfig.ServiceName);
                    exitCode = ExitCode.Success;
                }
            }
            catch (Exception ex)
            {
                WriteEventLogEntry(ex.ToString(), MessageType.Error);

                // Check for a win 32 exception
                var winEx = GetException<Win32Exception>(ex);

                // Special exit codes for account name errors
                if (winEx != null && (
                        winEx.NativeErrorCode == (Int32)UnderstoodNativeErrorCodes.ERROR_INVALID_SERVICE_ACCOUNT ||
                        winEx.NativeErrorCode == (Int32)UnderstoodNativeErrorCodes.ERROR_NONE_MAPPED ||
                        winEx.NativeErrorCode == (Int32)UnderstoodNativeErrorCodes.ERROR_TRUSTED_DOMAIN_FAILURE))
                {
                    exitCode = ExitCode.FailAccountNameInvalid;
                }
            }

            return exitCode;
        }

        /// <summary>
        /// Recursively dig into a generic exception to find a matching exception of a specific type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ex"></param>
        /// <returns></returns>
        private static T GetException<T>(Exception ex)
            where T:class
        {
            if (ex != null)
            {
                if (ex is T)
                {
                    return ex as T;
                }
                else
                {
                    return GetException<T>(ex.InnerException);
                }
            }

            return null;
        }

        private static void InstallServiceImpl(String[] args)
        {
            AssemblyInstaller assemblyInstaller = new AssemblyInstaller(System.Reflection.Assembly.GetExecutingAssembly().Location, args);
            assemblyInstaller.UseNewContext = true;
            Hashtable savedState = new Hashtable();
            assemblyInstaller.Install(savedState);
            assemblyInstaller.Commit(savedState);
        }

        private static void UninstallService(String[] args)
        {
            AssemblyInstaller assemblyInstaller = new AssemblyInstaller(System.Reflection.Assembly.GetExecutingAssembly().Location, args);
            assemblyInstaller.UseNewContext = true;
            assemblyInstaller.Uninstall(null);
        }

        private static ExitCode StartService(ConfigCommand configOption)
        {
            ExitCode exitCode = ExitCode.Fail;

            try
            {
                // Get any command line arguments
                List<string> args = BuildConfigArgs(configOption);

                // Parse out any arguments that we care about
                string waitForServiceStartNumRetriesString = InternalUtils.GetConfigValue("/startretries", args);
                UInt32 waitForServiceStartNumRetries;
                if (!UInt32.TryParse(waitForServiceStartNumRetriesString, out waitForServiceStartNumRetries))
                {
                    // Explicit default of zero, i.e. no retries
                    waitForServiceStartNumRetries = 0;
                }
                

                using (var serviceController = new ServiceController(InternalConfig.ServiceName))
                {
                    if (System.ServiceProcess.ServiceControllerStatus.Running != serviceController.Status)
                    {
                        bool waitForRunning = false;
                        switch (serviceController.Status)
                        {
                            case System.ServiceProcess.ServiceControllerStatus.StartPending:
                            case System.ServiceProcess.ServiceControllerStatus.ContinuePending:
                                serviceController.WaitForStatus(
                                    System.ServiceProcess.ServiceControllerStatus.Running,
                                    new TimeSpan(_waitForServiceStatusTimeoutAsTicks));
                                break;

                            case System.ServiceProcess.ServiceControllerStatus.PausePending:
                                serviceController.WaitForStatus(
                                    System.ServiceProcess.ServiceControllerStatus.Paused,
                                    new TimeSpan(_waitForServiceStatusTimeoutAsTicks));
                                serviceController.Continue();
                                waitForRunning = true;
                                break;

                            case System.ServiceProcess.ServiceControllerStatus.StopPending:
                                serviceController.WaitForStatus(
                                    System.ServiceProcess.ServiceControllerStatus.Stopped,
                                    new TimeSpan(_waitForServiceStatusTimeoutAsTicks));
                                serviceController.Start();
                                waitForRunning = true;
                                break;

                            case System.ServiceProcess.ServiceControllerStatus.Paused:
                                serviceController.Continue();
                                waitForRunning = true;
                                break;

                            case System.ServiceProcess.ServiceControllerStatus.Stopped:
                                serviceController.Start();
                                waitForRunning = true;
                                break;

                            case System.ServiceProcess.ServiceControllerStatus.Running:
                                break;
                        }

                        if (waitForRunning)
                        {
                            serviceController.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Running,
                                                            new TimeSpan(_waitForServiceStatusTimeoutAsTicks));

                            // Wait for the service to be "ready"
                            // In a retry loop controlled by the start or restart command line parameter
                            // Dictating the number of retries that should be attempted for this action
                            UInt32 waitForReadyAttempt = 0;
                            Boolean operationComplete = false;
                            while (!operationComplete && waitForReadyAttempt <= waitForServiceStartNumRetries)
                            {
                                try
                                {
                                    WaitForServiceReadyMutex(_waitForServiceTimeout, 1000);
                                    operationComplete = true;
                                }
                                catch (LinkedSource.WaitForServiceException)
                                {
                                    if (++waitForReadyAttempt > waitForServiceStartNumRetries)
                                    {
                                        // Exceeded retry count, rethrow
                                        throw;
                                    }
                                    else
                                    {
                                        // Log the fact that we're retrying
                                        WriteEventLogEntry(
                                            String.Format("Wait for service '{0}' retry attempt {1}", 
                                                InternalConfig.ServiceName,
                                                waitForReadyAttempt),
                                            MessageType.Warning);
                                    }
                                }
                            }
                        }
                    }
                }

                exitCode = ExitCode.Success;
            }
            catch (Exception ex)
            {
                WriteEventLogEntry(ex.ToString(), MessageType.Error);

                // Check for a wait for service exception
                if (ex is LinkedSource.WaitForServiceException)
                {
                    exitCode = ExitCode.FailWaitForServiceReady;
                }

                else
                {
                    // Check for a win 32 exception
                    var winEx = GetException<Win32Exception>(ex);

                    // Check for invalid login error
                    if (winEx != null && winEx.NativeErrorCode == (int)UnderstoodNativeErrorCodes.ERROR_SERVICE_LOGON_FAILED)
                    {
                        exitCode = ExitCode.FailInvalidLogin;
                    }

                    else
                    {
                        // Also check if we could not start because
                        // Of a file access error, recorded in a common location
                        if (InternalUtils.StartupAccessErrorOccurred())
                        {
                            // Service account user did not have access rights to the app data folder
                            exitCode = ExitCode.FailAccountFolderAccess;
                        }
                    }
                }
            }

            return exitCode;
        }

        private static void StopService()
        {
            using (System.ServiceProcess.ServiceController serviceController = new System.ServiceProcess.ServiceController(InternalConfig.ServiceName))
            {
                if (System.ServiceProcess.ServiceControllerStatus.Stopped != serviceController.Status)
                {
                    bool waitForStopped = false;
                    switch (serviceController.Status)
                    {
                        case System.ServiceProcess.ServiceControllerStatus.StartPending:
                        case System.ServiceProcess.ServiceControllerStatus.ContinuePending:
                            serviceController.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Running, new TimeSpan(_waitForServiceStatusTimeoutAsTicks));
                            serviceController.Stop();
                            waitForStopped = true;
                            break;

                        case System.ServiceProcess.ServiceControllerStatus.PausePending:
                            serviceController.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Paused, new TimeSpan(_waitForServiceStatusTimeoutAsTicks));
                            serviceController.Stop();
                            waitForStopped = true;
                            break;

                        case System.ServiceProcess.ServiceControllerStatus.StopPending:
                            serviceController.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Stopped, new TimeSpan(_waitForServiceStatusTimeoutAsTicks));
                            break;

                        case System.ServiceProcess.ServiceControllerStatus.Paused:
                            serviceController.Stop();
                            waitForStopped = true;
                            break;

                        case System.ServiceProcess.ServiceControllerStatus.Stopped:
                            break;

                        case System.ServiceProcess.ServiceControllerStatus.Running:
                            serviceController.Stop();
                            waitForStopped = true;
                            break;
                    }

                    if (waitForStopped)
                    {
                        WaitForServiceProcessNotRunningMutex(_waitForServiceTimeout, 1000);
                        serviceController.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Stopped, new TimeSpan(_waitForServiceStatusTimeoutAsTicks));
                    }
                }
            }
        }

        private static void WaitForServiceReadyMutex(Int32 timeoutInMS, Int32 sleepIntervalInMS)
        {
            Sage.CRE.HostingFramework.LinkedSource.ServiceUtils.WaitForServiceMutexToBeSet(
                InternalConfig.ServiceReadyMutexName,
                timeoutInMS,
                sleepIntervalInMS,
                ConsoleWrite);
        }

        private static void WaitForServiceProcessNotRunningMutex(Int32 timeoutInMS, Int32 sleepIntervalInMS)
        {
            Sage.CRE.HostingFramework.LinkedSource.ServiceUtils.WaitForServiceMutexToBeReleased(
                InternalConfig.ServiceProcessRunningMutexName,
                timeoutInMS,
                sleepIntervalInMS,
                ConsoleWrite);
        }

        private static MutexSecurity AllowEveryoneMutexSecurity
        {
            get
            {
                MutexSecurity result = new MutexSecurity();
                result.AddAccessRule(new MutexAccessRule(new SecurityIdentifier(WellKnownSidType.WorldSid, null), MutexRights.Synchronize | MutexRights.Modify, AccessControlType.Allow));
                return result;
            }
        }

        private static Boolean IsAdmin
        {
            get
            {
                WindowsIdentity windowsIdentity = WindowsIdentity.GetCurrent();
                WindowsPrincipal windowsPrincipal = new WindowsPrincipal(windowsIdentity);
                return windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
            }
        }

        private static Process LaunchAsAdmin(String[] arguments)
        {
            StringBuilder argumentsStringBuilder = new StringBuilder();
            foreach (String argument in arguments)
            {
                argumentsStringBuilder.AppendFormat("{0} ", (argument));
            }
            ProcessStartInfo processStartInfo = new ProcessStartInfo(Assembly.GetExecutingAssembly().Location, argumentsStringBuilder.ToString());
            processStartInfo.WorkingDirectory = System.Environment.CurrentDirectory;
            processStartInfo.UseShellExecute = true;
            processStartInfo.Verb = "runas";
            return Process.Start(processStartInfo);
        }

        private static Boolean Install
        { get { return (Array.FindIndex(System.Environment.GetCommandLineArgs(), delegate(String argument) { return argument.Equals("/install", StringComparison.InvariantCultureIgnoreCase); }) != -1); } }

        private static Boolean Uninstall
        { get { return (Array.FindIndex(System.Environment.GetCommandLineArgs(), delegate(String argument) { return argument.Equals("/uninstall", StringComparison.InvariantCultureIgnoreCase); }) != -1); } }

        private static Boolean Start
        { get { return (Array.FindIndex(System.Environment.GetCommandLineArgs(), delegate(String argument) { return argument.Equals("/start", StringComparison.InvariantCultureIgnoreCase); }) != -1); } }

        private static Boolean Stop
        { get { return (Array.FindIndex(System.Environment.GetCommandLineArgs(), delegate(String argument) { return argument.Equals("/stop", StringComparison.InvariantCultureIgnoreCase); }) != -1); } }

        private static Boolean Restart
        { get { return (Array.FindIndex(System.Environment.GetCommandLineArgs(), delegate(String argument) { return argument.Equals("/restart", StringComparison.InvariantCultureIgnoreCase); }) != -1); } }

        private static Boolean ConsoleRun
        { get { return (Array.FindIndex(System.Environment.GetCommandLineArgs(), delegate(String argument) { return argument.Equals("/consolerun", StringComparison.InvariantCultureIgnoreCase); }) != -1); } }

        private static Boolean ConsoleStop
        { get { return (Array.FindIndex(System.Environment.GetCommandLineArgs(), delegate(String argument) { return argument.Equals("/consolestop", StringComparison.InvariantCultureIgnoreCase); }) != -1); } }

        private static Boolean Silent
        { get { return (Array.FindIndex(System.Environment.GetCommandLineArgs(), delegate(String argument) { return argument.Equals("/silent", StringComparison.InvariantCultureIgnoreCase); }) != -1); } }

        private static ConfigCommand ConfigCommand
        {
            get
            {
                if (!_configOptions.HasValue)
                {
                    _configOptions = ConfigCommand.None;

                    if (Install)
                    {
                        _configOptions = ConfigCommand.Install;
                    }
                    else if (Uninstall)
                    {
                        _configOptions = ConfigCommand.Uninstall;
                    }
                    else if (Start)
                    {
                        _configOptions = ConfigCommand.Start;
                    }
                    else if (Stop)
                    {
                        _configOptions = ConfigCommand.Stop;
                    }
                    else if (Restart)
                    {
                        _configOptions = ConfigCommand.Restart;
                    }
                    else if (ConsoleRun)
                    {
                        _configOptions = ConfigCommand.ConsoleRun;
                    }
                    else if (ConsoleStop)
                    {
                        _configOptions = ConfigCommand.ConsoleStop;
                    }
                }

                return _configOptions.Value;
            }
        }

        /// <summary>
        /// Writes a message to the Sage event log
        /// </summary>
        /// <param name="message">The message text</param>
        /// <param name="messageType">The type of the message</param>
        internal static void WriteEventLogEntry(String message, MessageType messageType)
        {
            try
            {
                _eventLogger.WriteMessage(InternalConfig.ServiceDisplayName, message, messageType);
            }
            catch (Exception ex)
            {
                _eventLogger.WriteMessage("HostingFrameworkService", ex.ToString(), MessageType.Error);
                ConsoleWriteLine(ex.ToString());

                _eventLogger.WriteMessage("HostingFrameworkService", message, messageType);
            }
            ConsoleWriteLine(message);
        }

        internal static void VerboseTraceWriteLine(object caller, string messageToFormat, params object[] list)
        {
            Trace.WriteLine(String.Format(messageToFormat, list));
            ConsoleWriteLine(messageToFormat, list);
        }

        private static void ConsoleWriteLine(string messageToFormat, params object[] list)
        {
            if (_consoleAttached)
            {
                Console.WriteLine(String.Format(messageToFormat, list));
            }
        }

        private static void ConsoleWrite(String message)
        {
            if (_consoleAttached)
            {
                Console.Write(message);
            }
        }

        private static Boolean _consoleAttached = false;
        private static IEventLogger _eventLogger = new EventLogger() as IEventLogger;
        private static ConfigCommand? _configOptions; // = null; (automatically initialized by runtime)
        private const Int32 _waitForServiceTimeout = 60*1000;
        private const Int32 _waitForServiceStatusTimeoutAsTicks = _waitForServiceTimeout * 10000; // there are 10000 "ticks" (i.e., 100-ns intervals) per 1-ms

        [DllImport("kernel32.dll")]
        static extern bool AttachConsole(UInt32 dwProcessId);

        private const UInt32 ATTACH_PARENT_PROCESS = 0xFFFFFFFF;

        private static void InitConsoleHandles()
        {
            // Attach to console window – this may modify the standard handles
            AttachConsole(ATTACH_PARENT_PROCESS);
            _consoleAttached = true;
        }
    }
}
