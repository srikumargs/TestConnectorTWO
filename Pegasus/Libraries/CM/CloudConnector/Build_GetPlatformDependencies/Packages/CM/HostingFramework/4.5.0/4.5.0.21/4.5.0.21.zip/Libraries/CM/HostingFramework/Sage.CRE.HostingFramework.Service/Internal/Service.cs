﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Net;
using System.ServiceProcess;
using System.Threading;
using Sage.CRE.LinkedSource;
using Sage.Threading;
using System.Linq;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    public partial class Service : ServiceBase
    {
        public Service()
        {
            InitializeComponent();

            AutoLog = false;
            CanHandlePowerEvent = false;
            CanPauseAndContinue = true;
            CanShutdown = true;
            CanStop = true;

            _notifyHostReadyTimeout = InternalConfig.NotifyHostReadyTimeout;

            ServiceName = InternalConfig.ServiceName;
        }

        protected override void OnStart(String[] args)
        {
            // Throw an exception if the current user does not have
            // The directory access expected to start the service
            InternalUtils.ThrowIfUserAccessNotSet();

            lock (_syncRoot)
            {
                // In order to prevent the SCM from giving up on trying to start this service, delegate the real work
                // to a background thread.  The service status will now be running, but it won't be ready to truly 
                // service any real client requests until the "host ready" event has been signalled.
                ThreadPool.QueueUserWorkItem(new WaitCallback(OnStartThreadProc), args);
            }
        }

        public void ConsoleStart()
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(OnStartThreadProc), null);
        }

        public void ConsoleStop()
        {
            OnStop();
        }

        /// <summary>
        /// Executes when a Pause command is sent to the service by the Service Control Manager (SCM). Specifies actions to take when a service pauses.
        /// </summary>
        protected override void OnPause()
        {
            lock (_syncRoot)
            {
                try
                {
                    StopServicesAndNotifyNotReady();

                    _serviceInPausedState = true;

                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ServicePausedFormat, InternalConfig.ServiceDisplayName), Sage.Diagnostics.MessageType.Information);
                }
                catch (Exception ex)
                {
                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ErrorPausingServiceFormat, InternalConfig.ServiceDisplayName, ex.Message, ex.ToString()), Sage.Diagnostics.MessageType.Error);
                    throw;
                }
            }
        }

        /// <summary>
        /// Runs when a Continue command is sent to the service by the Service Control Manager (SCM). Specifies actions to take when a service resumes normal functioning after being paused.
        /// </summary>
        protected override void OnContinue()
        {
            // Throw an exception if the current user does not have
            // The directory access expected to start the service
            InternalUtils.ThrowIfUserAccessNotSet();

            lock (_syncRoot)
            {
                try
                {
                    _serviceInPausedState = false;

                    StartServicesAndNotifyReady();

                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ServiceContinuedFormat, InternalConfig.ServiceDisplayName), Sage.Diagnostics.MessageType.Information);
                }
                catch (Exception ex)
                {
                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ErrorContinuingServiceFormat, InternalConfig.ServiceDisplayName, ex.Message, ex.ToString()), Sage.Diagnostics.MessageType.Error);
                    throw;
                }
            }
        }

        /// <summary>
        /// Executes when a Stop command is sent to the service by the Service Control Manager (SCM). Specifies actions to take when a service stops running.
        /// </summary>
        protected override void OnStop()
        {
            lock (_syncRoot)
            {
                try
                {
                    TearDownAppDomainsAndNotifyExit();

                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ServiceStoppedFormat, InternalConfig.ServiceDisplayName), Sage.Diagnostics.MessageType.Information);
                }
                catch (Exception ex)
                {
                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ErrorStoppingServiceFormat, InternalConfig.ServiceDisplayName, ex.Message, ex.ToString()), Sage.Diagnostics.MessageType.Error);
                    throw;
                }
            }
        }

        /// <summary>
        /// Executes when the system is shutting down. Specifies what should happen immediately prior to the system shutting down.
        /// </summary>
        protected override void OnShutdown()
        {
            lock (_syncRoot)
            {
                try
                {
                    TearDownAppDomainsAndNotifyExit();

                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ServiceShutdownFormat, InternalConfig.ServiceDisplayName), Sage.Diagnostics.MessageType.Information);
                }
                catch (Exception ex)
                {
                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ErrorShuttingDownServiceFormat, InternalConfig.ServiceDisplayName, ex.Message, ex.ToString()), Sage.Diagnostics.MessageType.Error);
                    throw;
                }
            }
        }

        private void OnStartThreadProc(Object args)
        {
            lock (_syncRoot)
            {
                try
                {
                    NotifyServiceProcessRunning();

                    // The default working directory for services appears to be System32.  Change it to be something
                    // more sensical (e.g., the directory the service EXE is installed to).
                    Environment.CurrentDirectory = AppDomain.CurrentDomain.BaseDirectory;

                    // setup the HostSupervisor service first, merely an in-proc service that maintains the
                    // state information for others like the CatalogService and MonitorService
                    _hostSupervisorAppDomainHelper = new IsolatedAppDomainHelper("HostSupervisor");
                    _hostSupervisorServiceHost = (RemoteServiceHostContainer)_hostSupervisorAppDomainHelper.CreateInstanceAndUnwrap(typeof(RemoteServiceHostContainer));
                    Dictionary<String, ServiceActivationInfo> services = new Dictionary<string, ServiceActivationInfo>();
                    services.Add("HostSupervisor", new ServiceActivationInfo(typeof(HostSupervisor).FullName, String.Empty, typeof(HostSupervisor).Assembly.FullName));
                    ServiceConfig hostSupervisorServiceConfig = new ServiceConfig(services);
                    hostSupervisorServiceConfig.BaseAddresses = new Uri[] { new Uri(String.Format(Constants.HostSupervisorAddressFormat, InternalConfig.ServiceName)) };
                    _hostSupervisorAppDomainHelper.InvokeMethod(_hostSupervisorServiceHost, typeof(RemoteServiceHostContainer), "Initialize", new object[] { hostSupervisorServiceConfig });

                    // next, setup the plugin services
                    if (Directory.Exists(InternalConfig.HostingFrameworkServicesFolder))
                    {
                        // read and create ServiceConfig for each file
                        String[] files = Directory.GetFiles(InternalConfig.HostingFrameworkServicesFolder, "*.xml");
                        foreach (String file in files)
                        {
                            _serviceConfig.Add(new ServiceConfig(file));
                        }

                        // sort the ServiceConfig by PortAssignmentPriority
                        _serviceConfig.Sort(delegate(ServiceConfig x, ServiceConfig y) { return (x.PortAssignmentPriority - y.PortAssignmentPriority); });

                        // sort the ServiceConfig by DependsOn
                        List<String> serviceConfigFilesByDependsOnOrder = GetServiceConfigFilesByDependsOnOrder();
                        _serviceConfig.Sort(delegate(ServiceConfig x, ServiceConfig y) { return (serviceConfigFilesByDependsOnOrder.IndexOf(x.ConfigFileNameOnly) - serviceConfigFilesByDependsOnOrder.IndexOf(y.ConfigFileNameOnly)); });

                        // assign base addresses to ServiceConfig in PortAssignmentPriority order
                        for (Int32 i = 0; i < _serviceConfig.Count; i++)
                        {
                            List<Uri> baseAddresses = new List<Uri>();
                            foreach (KeyValuePair<String, String> pair in InternalConfig.BaseAddressTemplates)
                            {
                                String uriAsString = String.Empty;
                                if (!String.IsNullOrEmpty(InternalConfig.BaseAddressTemplatePorts[pair.Key]))
                                {
                                    Int32 basePort = Convert.ToInt32(InternalConfig.BaseAddressTemplatePorts[pair.Key], CultureInfo.InvariantCulture);
                                    uriAsString = String.Format(pair.Value, basePort + i);
                                }
                                else
                                {
                                    uriAsString = pair.Value;
                                }
                                baseAddresses.Add(new Uri(uriAsString.Replace("localhost", Dns.GetHostEntry(Dns.GetHostName()).HostName)));
                            }

                            _serviceConfig[i].BaseAddresses = baseAddresses.ToArray();
                        }
                    }

                    foreach (ServiceConfig serviceConfig in _serviceConfig)
                    {
                        IsolatedAppDomainHelper appDomainHelper = new IsolatedAppDomainHelper(serviceConfig.AppDomainId, serviceConfig.ConfigFile);
                        Object appDomainIsolatedServiceHost = appDomainHelper.CreateInstanceAndUnwrap(typeof(RemoteServiceHostContainer));
                        appDomainHelper.InvokeMethod(appDomainIsolatedServiceHost, typeof(RemoteServiceHostContainer), "Initialize", new object[] { serviceConfig });
                        _serviceHosts.Add(new Tuple<Object, IsolatedAppDomainHelper>(appDomainIsolatedServiceHost, appDomainHelper));
                    }

                    StartServicesAndNotifyReady();

                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ServiceStartedFormat, InternalConfig.ServiceDisplayName), Sage.Diagnostics.MessageType.Information);
                }
                catch (Exception ex)
                {
                    Program.WriteEventLogEntry(String.Format(CultureInfo.CurrentCulture, StringsCustomerFacing.ErrorStartingServiceFormat, InternalConfig.ServiceDisplayName, ex.Message, ex.ToString()), Sage.Diagnostics.MessageType.Error);

                    //throw;
                    //
                    // Normally, we would simply throw here which would cause and unhandled exception in the main thread 
                    // which would cause the process to terminate.  However, the process startup has been delegated to a worker
                    // thread (in order to prevent the SCM giving up on this service).  So instead, we need to explicitly
                    // kill this process.
                    System.Diagnostics.Process.GetCurrentProcess().Kill();
                }
            }
        }

        private List<String> GetServiceConfigFilesByDependsOnOrder()
        {
            List<String> result = new List<String>();

            // load all ServiceConfig; read all explicit dependencies mentioned in each config
            var allConfigFileNames = _serviceConfig.Select(x => x.ConfigFileNameOnly);

            Program.VerboseTraceWriteLine(this, "{0} files found.", allConfigFileNames.Count());
            Dictionary<String, ServiceConfig> serviceConfigByFileName = new Dictionary<String, ServiceConfig>();
            Dictionary<String, List<String>> explicitReferencesByFileName = new Dictionary<String, List<String>>();
            foreach (var serviceConfig in _serviceConfig)
            {
                Program.VerboseTraceWriteLine(this, "Reading explicit references in '{0}'...", serviceConfig);
                serviceConfigByFileName.Add(serviceConfig.ConfigFileNameOnly, serviceConfig);
                explicitReferencesByFileName.Add(serviceConfig.ConfigFileNameOnly, serviceConfig.DependsOn.ToList());
            }

            // infer all effective dependencies by starting at the bottom of the dependency graph (those configs dependent on nothing) and
            // working upward to those that are effectively dependent on the most stuff
            Dictionary<String, List<String>> allDependenciesByFileName = new Dictionary<String, List<String>>();
            List<IEnumerable<String>> buildPasses = new List<IEnumerable<String>>();
            Int32 pass = 0;
            while (explicitReferencesByFileName.Count > 0)
            {
                // a config is considered "fully analyzed" once all of its dependencies are found in the allDependenciesByLibraryUniqueName container
                List<String> fullyAnalyzedConfig = explicitReferencesByFileName.Where(x => (x.Value.Intersect(allDependenciesByFileName.Keys).Count() == x.Value.Count())).Select(x => x.Key).ToList();
                Program.VerboseTraceWriteLine(this, "Pass {0}:", pass++);
                fullyAnalyzedConfig.ForEach(x => Program.VerboseTraceWriteLine(this, x));
                buildPasses.Add(fullyAnalyzedConfig);

                if (fullyAnalyzedConfig.Count() == 0)
                {
                    // no new fully-analyzed config; this means the problem is unsolvable ... incorrect DependsOn are a likely culprit
                    Program.VerboseTraceWriteLine(this, "Unable to evaluate end-to-end service config dependencies; verify that all DependsOn elements are accurate and that no circular references exist.");
                    Program.VerboseTraceWriteLine(this, "Following are the details of the remaining analysis unable to be completed:");
                    foreach (String key in explicitReferencesByFileName.Keys)
                    {
                        Program.VerboseTraceWriteLine(this, key);
                        foreach (String reference in explicitReferencesByFileName[key].Where(x => !allDependenciesByFileName.ContainsKey(x)))
                        {
                            if (!serviceConfigByFileName.ContainsKey(reference))
                            {
                                Program.VerboseTraceWriteLine(this, String.Format("{0} (ERROR! reference to unknown config)", reference));
                            }
                            else
                            {
                                Program.VerboseTraceWriteLine(this, reference);
                            }
                        }
                    }
                    return null;
                }
                else
                {
                    // for all of the new config now in the "fully analyzed" state, move the new config to the
                    // allDependenciesByFileName container; also fully expand out all dependencies by using the
                    // "finished" dependencies that are found in that allDependenciesByFileName container
                    foreach (String fullyAnalyzedLibrary in fullyAnalyzedConfig)
                    {
                        // read every explicit dependency of the fully-analyzed library
                        List<String> dependencies = new List<String>();
                        foreach (String libraryUniqueName in explicitReferencesByFileName[fullyAnalyzedLibrary])
                        {
                            // for each explicit dependency; build up a list of effective dependencies by consulting the allDependenciesByFileName container
                            dependencies = allDependenciesByFileName[libraryUniqueName].Union(dependencies).ToList();

                            // don't forget to add the explicit dependency too!
                            if (!dependencies.Contains(libraryUniqueName))
                            {
                                dependencies.Add(libraryUniqueName);
                            }
                        }

                        // now that all effective dependencies for this library have been computed; add its results to the allDependenciesByFileName container
                        allDependenciesByFileName.Add(fullyAnalyzedLibrary, dependencies);

                        // remove this library from the explicitReferencesByLibraryUniqueName container; its information is now in the "fully analyzed" container 
                        explicitReferencesByFileName.Remove(fullyAnalyzedLibrary);
                    }
                }
            }

            // the allDependenciesByLibraryUniqueName keys should be in appropriate dependency order since we added them that way
            return allDependenciesByFileName.Keys.ToList();
        }

        /// <summary>
        /// Bring plugin services online, perform handshake with server, and notify the ready state
        /// </summary>
        private void StartServicesAndNotifyReady()
        {
            lock (_syncRoot)
            {
                _hostSupervisorAppDomainHelper.InvokeMethod(_hostSupervisorServiceHost, typeof(RemoteServiceHostContainer), "Start", new object[] { });

                foreach (var tuple in _serviceHosts)
                {
                    Object appDomainIsolatedServiceHost = tuple.Item1;
                    IsolatedAppDomainHelper appDomainHelper = tuple.Item2;
                    appDomainHelper.InvokeMethod(appDomainIsolatedServiceHost, typeof(RemoteServiceHostContainer), "Start", new object[] { });
                }

                NotifyHostReady();
            }
        }

        /// <summary>
        /// Notify the not-ready state, perform handshake with server, take plugin services offline
        /// </summary>
        private void StopServicesAndNotifyNotReady()
        {
            lock (_syncRoot)
            {
                NotifyHostNotReady();

                var serviceHostsInReverse = new List<Tuple<Object, IsolatedAppDomainHelper>>();
                serviceHostsInReverse.AddRange(_serviceHosts);
                serviceHostsInReverse.Reverse();
                foreach (var tuple in serviceHostsInReverse)
                {
                    Object appDomainIsolatedServiceHost = tuple.Item1;
                    IsolatedAppDomainHelper appDomainHelper = tuple.Item2;
                    appDomainHelper.InvokeMethod(appDomainIsolatedServiceHost, typeof(RemoteServiceHostContainer), "Stop", new object[] { });
                }
                serviceHostsInReverse.Clear();

                _hostSupervisorAppDomainHelper.InvokeMethod(_hostSupervisorServiceHost, typeof(RemoteServiceHostContainer), "Stop", new object[] { });
            }
        }

        /// <summary>
        /// Prepares for shut down of the service by sending "goodbye" to workstations, unconfiguring remoting, and notifying
        /// clients that our process is no longer in the ready state.
        /// </summary>
        private void TearDownAppDomainsAndNotifyExit()
        {
            lock (_syncRoot)
            {
                // If we are currently already paused, then there is no need to tear down the host ... it happened
                // previously when we processed the pause command.
                if (!_serviceInPausedState)
                {
                    StopServicesAndNotifyNotReady();
                }

                var serviceHostsInReverse = new List<Tuple<Object, IsolatedAppDomainHelper>>();
                serviceHostsInReverse.AddRange(_serviceHosts);
                serviceHostsInReverse.Reverse();
                foreach (var tuple in serviceHostsInReverse)
                {
                    IsolatedAppDomainHelper appDomainHelper = tuple.Item2;
                    appDomainHelper.Dispose();
                }
                serviceHostsInReverse.Clear();
                _serviceHosts.Clear();

                _hostSupervisorServiceHost = null;
                _hostSupervisorAppDomainHelper.Dispose();
                _hostSupervisorAppDomainHelper = null;

                NotifyServiceProcessNotRunning();
            }
        }

        /// <summary>
        /// Notify clients that our remote objects are ready to be served up
        /// </summary>
        private void NotifyHostReady()
        {
            lock (_syncRoot)
            {
                if (!_hostReadyEvent.Set(InternalConfig.ServiceReadyMutexName, _notifyHostReadyTimeout))
                {
                    throw new System.ServiceProcess.TimeoutException(string.Format(CultureInfo.InvariantCulture, "Failed to set {0} event", InternalConfig.ServiceReadyMutexName));
                }
            }
        }

        /// <summary>
        /// Notify clients that our host process is no longer available
        /// </summary>
        private void NotifyHostNotReady()
        {
            lock (_syncRoot)
            {
                _hostReadyEvent.Reset();
            }
        }


        /// <summary>
        /// Notify clients that our remote objects are ready to be served up
        /// </summary>
        private void NotifyServiceProcessRunning()
        {
            lock (_syncRoot)
            {
                if (!_serviceProcessRunningEvent.Set(InternalConfig.ServiceProcessRunningMutexName, _notifyHostReadyTimeout))
                {
                    throw new System.ServiceProcess.TimeoutException(string.Format(CultureInfo.InvariantCulture, "Failed to set {0} event", InternalConfig.ServiceProcessRunningMutexName));
                }
            }
        }

        /// <summary>
        /// Notify clients that our host process is no longer available
        /// </summary>
        private void NotifyServiceProcessNotRunning()
        {
            lock (_syncRoot)
            {
                _serviceProcessRunningEvent.Reset();
            }
        }



        private readonly Object _syncRoot = new Object();
        private readonly List<ServiceConfig> _serviceConfig = new List<ServiceConfig>();
        private readonly List<Tuple<Object, IsolatedAppDomainHelper>> _serviceHosts = new List<Tuple<Object, IsolatedAppDomainHelper>>();
        private readonly Int32 _notifyHostReadyTimeout; // = 0; (automatically initialized by runtime)
        private readonly InterProcessEvent _hostReadyEvent = new InterProcessEvent();
        private readonly InterProcessEvent _serviceProcessRunningEvent = new InterProcessEvent();
        private Boolean _serviceInPausedState; // = false; (automatically initialized by runtime)
        private IsolatedAppDomainHelper _hostSupervisorAppDomainHelper;
        private RemoteServiceHostContainer _hostSupervisorServiceHost;
    }
}
