﻿using System;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    internal sealed class ServiceActivationInfo : MarshalByRefObject
    {
        /// <summary>
        /// Override and return null to specify infinite lifetime for the singleton.
        /// </summary>
        public override object InitializeLifetimeService()
        {
            return null;
        }

        public ServiceActivationInfo(String typeName, String description, String assemblyName)
        {
            _typeName = typeName;
            _description = description;
            _assemblyName = assemblyName;
        }

        public String TypeName
        { get { return _typeName; } }

        public String Description
        { get { return _description; } }

        public String AssemblyName
        { get { return _assemblyName; } }

        public Uri[] BaseAddresses
        { 
            get { return _baseAddresses; }
            set { _baseAddresses = value; }
        }

        private readonly String _typeName;
        private readonly String _description;
        private readonly String _assemblyName;
        private Uri[] _baseAddresses;
    }
}
