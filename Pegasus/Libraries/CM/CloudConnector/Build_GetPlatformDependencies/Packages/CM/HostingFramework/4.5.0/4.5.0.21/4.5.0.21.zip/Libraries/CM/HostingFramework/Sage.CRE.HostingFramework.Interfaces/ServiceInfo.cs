﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using Sage.Diagnostics;

namespace Sage.CRE.HostingFramework.Interfaces
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract(Namespace = Constants.SERVICE_NAMESPACE)]
    public sealed class ServiceInfo
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="configurationName"></param>
        /// <param name="description"></param>
        /// <param name="appDomainId"></param>
        /// <param name="uris"></param>
        public ServiceInfo(String configurationName, String description, String appDomainId, IEnumerable<Uri> uris)
        {
            ArgumentValidator.ValidateNonNullReference(configurationName, "configurationName", String.Format("{0}.ctor()", typeof(ServiceInfo).Name));
            ArgumentValidator.ValidateNonNullReference(description, "description", String.Format("{0}.ctor()", typeof(ServiceInfo).Name));
            ArgumentValidator.ValidateNonNullReference(appDomainId, "appDomainId", String.Format("{0}.ctor()", typeof(ServiceInfo).Name));
            ArgumentValidator.ValidateNonNullReference(uris, "uris", String.Format("{0}.ctor()", typeof(ServiceInfo).Name));

            _configurationName = configurationName;
            _description = description;
            _appDomainId = appDomainId;
            _uris = uris;
        }

        /// <summary>
        /// 
        /// </summary>
        public String ConfigurationName
        { get { return _configurationName; } }

        /// <summary>
        /// 
        /// </summary>
        public String Description
        { get { return _description; } }

        /// <summary>
        /// 
        /// </summary>
        public String AppDomainId
        { get { return _appDomainId; } }

        /// <summary>
        /// 
        /// </summary>
        public IEnumerable<Uri> Uris
        { get { return _uris; } }

        /// <summary>
        /// 
        /// </summary>
        public CommunicationState CommunicationState
        {
            get { return _communicationState; }
            set { _communicationState = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override String ToString()
        {
            if (String.IsNullOrEmpty(_stringRepresentation))
            {
                _stringRepresentation = String.Format("[{0}]", _configurationName, _uris);
            }
            return _stringRepresentation;
        }

        private String _stringRepresentation;

        [DataMember]
        private readonly String _configurationName;  //= null; (automaticaly initialized by runtime)

        [DataMember]
        private readonly String _description;  //= null; (automaticaly initialized by runtime)

        [DataMember]
        private readonly String _appDomainId;  //= null; (automaticaly initialized by runtime)

        [DataMember]
        private readonly IEnumerable<Uri> _uris;  //= null; (automaticaly initialized by runtime)

        [DataMember]
        private CommunicationState _communicationState;
    }
}
