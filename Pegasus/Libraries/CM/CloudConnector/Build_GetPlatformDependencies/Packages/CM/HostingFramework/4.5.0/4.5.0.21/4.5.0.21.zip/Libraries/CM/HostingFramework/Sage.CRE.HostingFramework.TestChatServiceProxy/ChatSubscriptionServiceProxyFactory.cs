﻿using System;
using System.ServiceModel;
using Sage.CRE.HostingFramework.Proxy.Advanced;

namespace Sage.CRE.HostingFramework.TestChatServiceProxy
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class ChatSubscriptionServiceProxyFactoryParams : ICatalogedServiceProxyFactoryParams<ChatSubscriptionServiceProxy>
    {
        /// <summary>
        /// The name of the service as it appears in the catalog
        /// </summary>
        public String ServiceName
        { get { return "ChatSubscriptionService"; } }

        /// <summary>
        /// Create the service proxy at the specified endpoint address
        /// </summary>
        /// <param name="endpointAddress">The endpoint for the service</param>
        /// <param name="instanceContext">An optional parameter used to supply an instance context for callback interfaces (can be null)</param>
        /// <returns></returns>
        public ChatSubscriptionServiceProxy Create(EndpointAddress endpointAddress, InstanceContext instanceContext)
        {
            NetTcpBinding binding = new NetTcpBinding(SecurityMode.Transport, true);
            binding.Security.Transport.ProtectionLevel = System.Net.Security.ProtectionLevel.EncryptAndSign;
            binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Windows;
            return new ChatSubscriptionServiceProxy(instanceContext, binding, endpointAddress);
        }
    }

    /// <summary>
    /// A client convenience factory intended to facilitate creation of an appropriately-configured ChatSubscriptionServiceProxy.
    /// </summary>
    public sealed class ChatSubscriptionServiceProxyFactory : CatalogedServiceProxyFactory<ChatSubscriptionServiceProxy, ChatSubscriptionServiceProxyFactoryParams>
    { }
}
