﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Text;
using System.ServiceModel;

namespace Sage.CRE.HostingFramework.TestChatServiceInterfaces
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceContract(SessionMode = SessionMode.Allowed, Namespace = "http://Sage.CRE.HostingFramework.com", ProtectionLevel = ProtectionLevel.EncryptAndSign)]
    public interface ISingletonWorkerService
    {
        /// <summary>
        /// Dummy method to prevent ContractDescription.EnsureInvariants from throwing an InvalidOperationException
        /// due to having no OperationContract methods
        /// </summary>
        [OperationContract]
        void DoNothing();
    }
}
