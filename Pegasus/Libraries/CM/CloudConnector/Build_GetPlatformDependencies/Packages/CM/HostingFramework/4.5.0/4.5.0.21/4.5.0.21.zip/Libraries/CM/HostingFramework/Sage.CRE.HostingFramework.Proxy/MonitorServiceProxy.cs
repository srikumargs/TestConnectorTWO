﻿using System;
using Sage.CRE.HostingFramework.Interfaces;
using Sage.ServiceModel;

namespace Sage.CRE.HostingFramework.Proxy
{
        /// <summary>
    /// 
    /// </summary>
    public sealed class MonitorServiceProxy : RetryClientBase<IMonitorService>, IMonitorService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="rawProxyCreationFunction"></param>
        public MonitorServiceProxy(RetryClientBase<IMonitorService>.CreationFunction rawProxyCreationFunction)
            : base(rawProxyCreationFunction)
        { }

        #region IMonitorService Members

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Version GetVersion()
        { return (Version)RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.GetVersion(); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DateTime GetUpSinceDateTime()
        { return (DateTime)RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.GetUpSinceDateTime(); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Status GetStatus()
        { return (Status)RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.GetStatus(); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public String GetServer()
        { return (String)RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.GetServer(); }); }

        #endregion
    }
}
