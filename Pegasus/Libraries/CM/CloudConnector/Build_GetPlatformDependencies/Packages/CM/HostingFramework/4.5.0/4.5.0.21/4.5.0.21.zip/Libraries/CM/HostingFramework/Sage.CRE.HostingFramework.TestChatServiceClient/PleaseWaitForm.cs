using System;
using System.Windows.Forms;
using System.Threading;

namespace Sage.CRE.HostingFramework.TestChatServiceClient
{
    public partial class PleaseWaitForm : Form
    {
        public PleaseWaitForm()
        {
            InitializeComponent();
        }

        public void ShowError(string errMessage)
        {
            _errorMessageLabel.Text = errMessage;
            _errorPanel.BringToFront();
            Text = "Connection error";
            _connectingPanel.Visible = false;
            _errorPanel.Visible = true;
        }

        public ManualResetEvent ShowingEvent
        { get; set; }

        private void _okButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void PleaseWaitForm_Load(object sender, EventArgs e)
        {
            ShowingEvent.Set();
        }
    }
}