namespace Sage.CRE.HostingFramework.TestChatServiceClient
{
    partial class PleaseWaitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._progressBar = new System.Windows.Forms.ProgressBar();
            this._label = new System.Windows.Forms.Label();
            this._connectingPanel = new System.Windows.Forms.Panel();
            this._errorPanel = new System.Windows.Forms.Panel();
            this._okButton = new System.Windows.Forms.Button();
            this._errorMessageLabel = new System.Windows.Forms.Label();
            this._connectingPanel.SuspendLayout();
            this._errorPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // _progressBar
            // 
            this._progressBar.Location = new System.Drawing.Point(30, 41);
            this._progressBar.Name = "_progressBar";
            this._progressBar.Size = new System.Drawing.Size(198, 20);
            this._progressBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this._progressBar.TabIndex = 0;
            // 
            // _label
            // 
            this._label.AutoSize = true;
            this._label.Location = new System.Drawing.Point(27, 12);
            this._label.Name = "_label";
            this._label.Size = new System.Drawing.Size(198, 13);
            this._label.TabIndex = 1;
            this._label.Text = "Connecting to chat server... Please wait.";
            // 
            // _connectingPanel
            // 
            this._connectingPanel.Controls.Add(this._label);
            this._connectingPanel.Controls.Add(this._progressBar);
            this._connectingPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._connectingPanel.Location = new System.Drawing.Point(0, 0);
            this._connectingPanel.Name = "_connectingPanel";
            this._connectingPanel.Size = new System.Drawing.Size(259, 96);
            this._connectingPanel.TabIndex = 3;
            // 
            // _errorPanel
            // 
            this._errorPanel.Controls.Add(this._connectingPanel);
            this._errorPanel.Controls.Add(this._okButton);
            this._errorPanel.Controls.Add(this._errorMessageLabel);
            this._errorPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._errorPanel.Location = new System.Drawing.Point(0, 0);
            this._errorPanel.Name = "_errorPanel";
            this._errorPanel.Size = new System.Drawing.Size(259, 96);
            this._errorPanel.TabIndex = 4;
            // 
            // _okButton
            // 
            this._okButton.Location = new System.Drawing.Point(178, 58);
            this._okButton.Name = "_okButton";
            this._okButton.Size = new System.Drawing.Size(75, 23);
            this._okButton.TabIndex = 1;
            this._okButton.Text = "OK";
            this._okButton.UseVisualStyleBackColor = true;
            this._okButton.Click += new System.EventHandler(this._okButton_Click);
            // 
            // _errorMessageLabel
            // 
            this._errorMessageLabel.AutoSize = true;
            this._errorMessageLabel.Location = new System.Drawing.Point(27, 14);
            this._errorMessageLabel.Name = "_errorMessageLabel";
            this._errorMessageLabel.Size = new System.Drawing.Size(150, 13);
            this._errorMessageLabel.TabIndex = 0;
            this._errorMessageLabel.Text = "Error: Cannot connect to chat!";
            // 
            // PleaseWaitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(259, 96);
            this.ControlBox = false;
            this.Controls.Add(this._errorPanel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PleaseWaitForm";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Connecting...";
            this.Load += new System.EventHandler(this.PleaseWaitForm_Load);
            this._connectingPanel.ResumeLayout(false);
            this._connectingPanel.PerformLayout();
            this._errorPanel.ResumeLayout(false);
            this._errorPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ProgressBar _progressBar;
        private System.Windows.Forms.Label _label;
        private System.Windows.Forms.Panel _connectingPanel;
        private System.Windows.Forms.Panel _errorPanel;
        private System.Windows.Forms.Button _okButton;
        private System.Windows.Forms.Label _errorMessageLabel;
    }
}