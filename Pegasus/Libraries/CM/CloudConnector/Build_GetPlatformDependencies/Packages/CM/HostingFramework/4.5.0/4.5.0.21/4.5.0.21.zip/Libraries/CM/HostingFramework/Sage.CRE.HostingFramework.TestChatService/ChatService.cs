﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel;
using Sage.Diagnostics;
using Sage.CRE.HostingFramework.TestChatServiceInterfaces;
using Sage.ServiceModel;

namespace Sage.CRE.HostingFramework.TestChatService
{
    /// <summary>
    /// Basic chat server which fires asynchronous events using a publish/subscribe framework
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Multiple, ConfigurationName = "ChatService")]
    public sealed class ChatService : PublishService<IChatCallback>, IChat
    {
        /// <summary>
        /// Join the chat room
        /// </summary>
        /// <param name="name">The user name to join as</param>
        /// <returns>List of user names of those already in the room</returns>
        public String[] Join(String name)
        {
            ArgumentValidator.ValidateNonEmptyString(name, "name", String.Format("{0}.{1}", typeof(ChatService).FullName, MethodInfo.GetCurrentMethod().Name));

            String[] result = null;
            Boolean userAdded = false;
            lock (_syncRoot)
            {
                if (!_names.Contains(name))
                {
                    _names.Add(name);
                    userAdded = true;
                }
            }

            if (userAdded)
            {
                PublishService<IChatCallback>.FireEvent("UserEnter", name);

                result = new String[_names.Count];
                lock (_syncRoot)
                {
                    _names.CopyTo(result, 0);
                }
            }

            return result;
        }

        /// <summary>
        /// Say something to the room
        /// </summary>
        /// <param name="name">The user name of the person saying something</param>
        /// <param name="message"></param>
        public void Say(String name, String message)
        {
            ArgumentValidator.ValidateNonEmptyString(name, "name", String.Format("{0}.{1}", typeof(ChatService).FullName, MethodInfo.GetCurrentMethod().Name));

            PublishService<IChatCallback>.FireEvent("Receive", name, message);
        }

        /// <summary>
        /// Leave the chat room
        /// </summary>
        /// <param name="name">The user name of the person leaving</param>
        public void Leave(String name)
        {
            ArgumentValidator.ValidateNonEmptyString(name, "name", String.Format("{0}.{1}", typeof(ChatService).FullName, MethodInfo.GetCurrentMethod().Name));

            lock (_syncRoot)
            {
                _names.Remove(name);
            }

            PublishService<IChatCallback>.FireEvent("UserLeave", name);
        }

        private static readonly Object _syncRoot = new Object();
        private static List<String> _names = new List<String>();
    }
}
