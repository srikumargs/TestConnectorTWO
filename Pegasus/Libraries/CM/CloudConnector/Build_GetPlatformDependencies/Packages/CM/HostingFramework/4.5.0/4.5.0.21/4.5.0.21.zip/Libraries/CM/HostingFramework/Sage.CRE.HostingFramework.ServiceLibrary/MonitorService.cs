﻿using System;
using System.Net;
using System.Reflection;
using System.ServiceModel;
using Sage.CRE.HostingFramework.Interfaces;

namespace Sage.CRE.HostingFramework.ServiceLibrary
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Multiple, ConfigurationName = "MonitorService")]
    public sealed class MonitorService : IMonitorService
    {
        #region IMonitorService Members

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Version GetVersion()
        { return _version; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DateTime GetUpSinceDateTime()
        { return _upSinceDateTime; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Status GetStatus()
        { return _status; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public String GetServer()
        { return _server; }

        #endregion

        private static readonly Object _syncRoot = new Object();
        private static readonly DateTime _upSinceDateTime = DateTime.Now;
        private static readonly Version _version = Assembly.GetExecutingAssembly().GetName().Version;
        private static readonly Status _status = Status.Ready;
        private static readonly String _server = Dns.GetHostEntry(Dns.GetHostName()).HostName;
    }
}
