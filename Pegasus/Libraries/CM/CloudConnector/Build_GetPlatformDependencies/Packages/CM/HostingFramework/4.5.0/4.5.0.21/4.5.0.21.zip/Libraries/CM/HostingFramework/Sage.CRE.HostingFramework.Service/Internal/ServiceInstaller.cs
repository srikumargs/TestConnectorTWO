﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using System.Globalization;
using System.Reflection;
using System.ServiceProcess;
using Sage.CRE.LinkedSource;
using System.Security;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    [RunInstaller(true)]
    public partial class ServiceInstaller : Installer
    {
        public ServiceInstaller()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Performs the installation.
        /// </summary>
        /// <remarks>
        /// Uses AppDomainIsolationInstallMethodHelper to delegate the core of the custom Install code to a separate AppDomain.
        /// </remarks>
        /// <param name="stateSaver">An IDictionary used to save information needed to perform a commit, rollback, or uninstall operation.</param>
        public override void Install(IDictionary stateSaver)
        {
            base.Context.LogMessage(String.Format(CultureInfo.InvariantCulture, "({0}): Begin {1}.Install() (CodeBase={2})", DateTime.Now.ToString("yyyy-MM-dd@HH.mm.ss", CultureInfo.InvariantCulture), _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            try
            {
                AdjustInstallersForConfig();

                // prevent referenced assemblies from being loaded in the default AppDomain so that there are no conflicts
                // with what might bee currently loaded by the installer
                IsolatedAppDomainInstallMethodHelper.ExecuteInstallerMethod(base.Context, stateSaver, typeof(ServiceInstallerImpl), "BeforeInstall", null, new IsolatedAppDomainInstallMethodHelper.InstallerMethodCallback(base.Install));
            }
            catch (Exception ex)
            {
                base.Context.LogMessage(String.Format(CultureInfo.InvariantCulture, "An exception occurred during installation:\n\n{0}", ex.ToString()));
                throw;
            }
            finally
            {
                base.Context.LogMessage(String.Format(CultureInfo.InvariantCulture, "({0}): End {1}.Install() (CodeBase={2})", DateTime.Now.ToString("yyyy-MM-dd@HH.mm.ss", CultureInfo.InvariantCulture), _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            }
        }

        /// <summary>
        /// Completes the install transaction.
        /// </summary>
        /// <remarks>
        /// Uses AppDomainIsolationInstallMethodHelper to delegate the core of the custom Commit code to a separate AppDomain.
        /// </remarks>
        /// <param name="savedState">An IDictionary that contains the state of the computer after all the installers in the collection have run. </param>
        public override void Commit(IDictionary savedState)
        {
            base.Context.LogMessage(String.Format(CultureInfo.InvariantCulture, "({0}): Begin {1}.Commit() (CodeBase={2})", DateTime.Now.ToString("yyyy-MM-dd@HH.mm.ss", CultureInfo.InvariantCulture), _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            try
            {
                //AdjustInstallersForConfig();

                // prevent referenced assemblies from being loaded in the default AppDomain so that there are no conflicts
                // with what might bee currently loaded by the installer
                IsolatedAppDomainInstallMethodHelper.ExecuteInstallerMethod(base.Context, savedState, typeof(ServiceInstallerImpl), null, "AfterCommit", new IsolatedAppDomainInstallMethodHelper.InstallerMethodCallback(base.Commit));
            }
            catch (Exception ex)
            {
                base.Context.LogMessage(String.Format(CultureInfo.InvariantCulture, "An exception occurred during installation:\n\n{0}", ex.ToString()));
                throw;
            }
            finally
            {
                base.Context.LogMessage(String.Format(CultureInfo.InvariantCulture, "({0}): End {1}.Commit() (CodeBase={2})", DateTime.Now.ToString("yyyy-MM-dd@HH.mm.ss", CultureInfo.InvariantCulture), _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            }
        }

        /// <summary>
        /// Removes an installation.
        /// </summary>
        /// <remarks>
        /// Uses AppDomainIsolationInstallMethodHelper to delegate the core of the custom Uninstall code to a separate AppDomain.
        /// </remarks>
        /// <param name="savedState">An IDictionary that contains the post-installation state of the computer.</param>
        public override void Uninstall(IDictionary savedState)
        {
            base.Context.LogMessage(String.Format(CultureInfo.InvariantCulture, "({0}): Begin {1}.Uninstall() (CodeBase={2})", DateTime.Now.ToString("yyyy-MM-dd@HH.mm.ss", CultureInfo.InvariantCulture), _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            try
            {
                //AdjustInstallersForConfig();

                // prevent referenced assemblies from being loaded in the default AppDomain so that there are no conflicts
                // with what might bee currently loaded by the installer
                IsolatedAppDomainInstallMethodHelper.ExecuteInstallerMethod(base.Context, savedState, typeof(ServiceInstallerImpl), null, "AfterUninstall", new IsolatedAppDomainInstallMethodHelper.InstallerMethodCallback(base.Uninstall));
            }
            catch (Exception ex)
            {
                base.Context.LogMessage(String.Format(CultureInfo.InvariantCulture, "An exception occurred during installation:\n\n{0}", ex.ToString()));
                throw;
            }
            finally
            {
                base.Context.LogMessage(String.Format(CultureInfo.InvariantCulture, "({0}): End {1}.Uninstall() (CodeBase={2})", DateTime.Now.ToString("yyyy-MM-dd@HH.mm.ss", CultureInfo.InvariantCulture), _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            }
        }

        private static String _myTypeName = typeof(ServiceInstaller).FullName;

        /// <summary>
        /// Adjust installers based on context
        /// </summary>
        private void AdjustInstallersForConfig()
        {
            // Get the service account
            string user = InternalUtils.GetConfigValue(ConfigParamType.ServiceAccountUser, Context.Parameters);
            _serviceProcessInstaller.Account = InternalUtils.GetServiceAccountFromString(user);

            // If this is a user account, need to get the username and password
            if (_serviceProcessInstaller.Account == ServiceAccount.User)
            {
                // User is just the value provided
                _serviceProcessInstaller.Username = user;

                // Password is in another param
                string pwd = InternalUtils.GetConfigValue(ConfigParamType.ServiceAccountPassword, Context.Parameters);
                if (!string.IsNullOrEmpty(pwd))
                {
                    _serviceProcessInstaller.Password = pwd;
                }
            }

            // Log the type of account we're using
            Context.LogMessage(
                String.Format("Using service account type '{0}'",
                    Enum.GetName(typeof(ServiceAccount), _serviceProcessInstaller.Account)));

            // Change the start mode based on any supplied value
            string startType = InternalUtils.GetConfigValue(ConfigParamType.ServiceStartType, Context.Parameters);
            _serviceInstaller.StartType = InternalUtils.GetServiceStartModeFromString(startType);

            if (_serviceInstaller.StartType == ServiceStartMode.Automatic && CanChangeDelayedStart())
            {
                // Change the delayed start flag based on OS and value
                bool delayedStart = false;
                Boolean.TryParse(
                    InternalUtils.GetConfigValue(ConfigParamType.ServiceDelayedStart, Context.Parameters),
                    out delayedStart);
                _serviceInstaller.DelayedAutoStart = delayedStart;
            }

            // Log the start mode we're using
            Context.LogMessage(
                String.Format("Using service start mode '{0}'",
                    Enum.GetName(typeof(ServiceStartMode), _serviceInstaller.StartType)));
        }

        /// <summary>
        /// Determine if we can change the delayed start value based on the current OS
        /// </summary>
        /// <returns></returns>
        private bool CanChangeDelayedStart()
        {
            bool result = false;

            // Can change for OS after Windows 2003
            OperatingSystem os = Environment.OSVersion;
            if (os != null &&
                os.Platform > PlatformID.Win32NT ||
                    (os.Platform == PlatformID.Win32NT &&
                        (os.Version.Major > 5 || (os.Version.Major == 5 && os.Version.Minor > 2))
                    )
                )
            {
                result = true;
            }

            return result;
        }
    }
}
