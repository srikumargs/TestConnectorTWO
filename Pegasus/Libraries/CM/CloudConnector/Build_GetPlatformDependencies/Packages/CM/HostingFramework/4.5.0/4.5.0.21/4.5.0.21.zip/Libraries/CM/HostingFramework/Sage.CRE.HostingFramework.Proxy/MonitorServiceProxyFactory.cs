﻿using System;
using System.ServiceModel;
using Sage.CRE.HostingFramework.Proxy.Advanced;
using Sage.CRE.HostingFramework.Proxy.Internal;

namespace Sage.CRE.HostingFramework.Proxy
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class MonitorServiceProxyFactoryParams : ICatalogedServiceProxyFactoryParams<MonitorServiceProxy>
    {
        /// <summary>
        /// The name of the service as it appears in the catalog
        /// </summary>
        public String ServiceName
        { get { return "MonitorService"; } }

        /// <summary>
        /// Create the service proxy at the specified endpoint address
        /// </summary>
        /// <param name="endpointAddress">The endpoint for the service</param>
        /// <param name="instanceContext">An optional parameter used to supply an instance context for callback interfaces (can be null)</param>
        /// <returns></returns>
        public MonitorServiceProxy Create(EndpointAddress endpointAddress, InstanceContext instanceContext)
        {
            NetTcpBinding binding = new NetTcpBinding(SecurityMode.Transport, true);
            binding.Security.Transport.ProtectionLevel = System.Net.Security.ProtectionLevel.EncryptAndSign;
            binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Windows;
            return new MonitorServiceProxy(delegate() { return new RawMonitorServiceProxy(binding, endpointAddress); });
        }
    }

    /// <summary>
    /// A client convenience factory intended to facilitate creation of an appropriately-configured MonitorServiceProxy.
    /// </summary>
    public sealed class MonitorServiceProxyFactory : CatalogedServiceProxyFactory<MonitorServiceProxy, MonitorServiceProxyFactoryParams>
    { }
}
