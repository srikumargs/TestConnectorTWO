﻿using System.ServiceProcess;
using System.Configuration.Install;
using System.Reflection;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    partial class ServiceInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.ServiceProcess.ServiceInstaller _serviceInstaller;          // = null; (automatically initialized by runtime)
        private ServiceProcessInstaller _serviceProcessInstaller;   // = null; (automatically initialized by runtime)

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();

            this._serviceProcessInstaller = new ServiceProcessInstaller();
            this._serviceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // _serviceProcessInstaller - default to Network Service account
            // 
            this._serviceProcessInstaller.Account = ServiceAccount.NetworkService;
            this._serviceProcessInstaller.Password = null;
            this._serviceProcessInstaller.Username = null;
            // 
            // _serviceInstaller
            // 
            this._serviceInstaller.DisplayName = InternalConfig.ServiceDisplayName;
            this._serviceInstaller.ServiceName = InternalConfig.ServiceName;
            //this._serviceInstaller.ServicesDependedOn = new string[] { "lanmanserver", "lanmanworkstation", "eventlog", "spooler" };
            this._serviceInstaller.StartType = ServiceStartMode.Automatic;
            // 
            // HostInstaller
            // 
            this.Installers.AddRange(new Installer[] { this._serviceProcessInstaller, this._serviceInstaller });
        }

        #endregion
    }
}