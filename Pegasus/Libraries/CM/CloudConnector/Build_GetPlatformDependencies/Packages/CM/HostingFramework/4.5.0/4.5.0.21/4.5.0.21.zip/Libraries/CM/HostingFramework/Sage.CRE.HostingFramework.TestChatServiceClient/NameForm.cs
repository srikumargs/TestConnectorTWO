using System;
using System.Windows.Forms;

namespace Sage.CRE.HostingFramework.TestChatServiceClient
{
    public partial class NameForm : Form
    {
        public NameForm()
        {
            InitializeComponent();
        }

        private void _nameTextBox_TextChanged(Object sender, EventArgs e)
        {
            _okButton.Enabled = _nameTextBox.Text.Length > 0 ? true : false;
        }

        private void NameForm_Load(object sender, EventArgs e)
        {
            _serverTextBox.Text = "localhost:48620";
        }
    }
}