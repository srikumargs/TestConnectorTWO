﻿using System.ServiceModel;
using Sage.CRE.HostingFramework.TestChatServiceInterfaces;
using Sage.ServiceModel;

namespace Sage.CRE.HostingFramework.TestChatService
{
    /// <summary>
    /// Subscription management service using the publish/subscribe framework for registering
    /// for IChatCallback events (fired by ChatService)
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Multiple, ConfigurationName = "ChatSubscriptionService")]
    public sealed class ChatSubscriptionService : SubscriptionManager<IChatCallback>, IChatSubscriptionService
    { }
}
