﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Sage.CRE.HostingFramework.TestChatServiceInterfaces;
using System.Threading;
using Sage.CRE.HostingFramework.Interfaces;

namespace Sage.CRE.HostingFramework.TestChatService
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single, ConfigurationName = "SingletonWorkerService")]
    [SingletonServiceControl(StartMethod = "Startup", StopMethod = "Shutdown")]
    public sealed class SingletonWorkerService : ISingletonWorkerService
    {
        /// <summary>
        /// 
        /// </summary>
        public SingletonWorkerService()
        {
            System.Diagnostics.Debug.WriteLine("Constructing SingletonWorkerService");
        }

        /// <summary>
        /// Dummy method to prevent ContractDescription.EnsureInvariants from throwing an InvalidOperationException
        /// due to having no OperationContract methods
        /// </summary>
        public void DoNothing()
        { }

        /// <summary>
        /// 
        /// </summary>
        public void Startup()
        {
            System.Diagnostics.Debug.WriteLine(">SingletonWorkerService.Startup");
            _thread = new Thread(new ParameterizedThreadStart(DoWork));
            _thread.Start();
            System.Diagnostics.Debug.WriteLine("<SingletonWorkerService.Startup");
        }

        /// <summary>
        /// 
        /// </summary>
        public void Shutdown()
        {
            System.Diagnostics.Debug.WriteLine(">SingletonWorkerService.Shutdown");
            _event.Set();
            _thread.Join();
            System.Diagnostics.Debug.WriteLine("<SingletonWorkerService.Shutdown");
        }

        private void DoWork(Object state)
        {
            System.Diagnostics.Debug.WriteLine(">SingletonWorkerService.DoWork");
            while (true)
            {
                System.Diagnostics.Debug.WriteLine("SingletonWorkerService.DoWork");

                if (_event.WaitOne(1000))
                {
                    System.Diagnostics.Debug.WriteLine("_event.WaitOne signalled; time to stop!");
                    break;
                }
            }
            System.Diagnostics.Debug.WriteLine("<SingletonWorkerService.DoWork");
        }


        private ManualResetEvent _event = new ManualResetEvent(false);
        private Thread _thread;
    }
}
