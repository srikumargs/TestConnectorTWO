using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace Sage.CRE.HostingFramework.TestChatServiceClient
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            String[] args = System.Environment.GetCommandLineArgs();
            if (args.Length == 4)
            {
                for (Int32 i = 0; i < Convert.ToInt32(args[3]); i++)
                {
                    Process process = new Process();
                    process.StartInfo.FileName = System.Reflection.Assembly.GetExecutingAssembly().Location;
                    process.StartInfo.Arguments = String.Format("{0} {1}-{2:D3}", args[1], args[2], i);
                    process.StartInfo.WorkingDirectory = System.Environment.CurrentDirectory;
                    process.StartInfo.UseShellExecute = false;
                    process.Start();
                }
            }
            else
            {
                String server = String.Empty;
                String name = String.Empty;
                if (args.Length == 3)
                {
                    server = args[1];
                    name = args[2];
                }
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm(server, name));
            }
        }
    }
}