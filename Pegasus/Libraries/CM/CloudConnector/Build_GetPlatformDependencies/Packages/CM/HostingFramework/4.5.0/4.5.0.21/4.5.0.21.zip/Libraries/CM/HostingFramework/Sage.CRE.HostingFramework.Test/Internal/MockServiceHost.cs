﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Collections.Generic;
//using Sage.CRE.HostingFramework.Interfaces;
//using Sage.CRE.HostingFramework.ServiceLibrary;

namespace Sage.CRE.HostingFramework.Test.Internal
{
    internal static class MockServiceHost
    {
        public static void StartService()
        {
            if (_serviceHost == null)
            {
                //_serviceHost = new ServiceHost(typeof(HostingFrameworkService), new[] { new Uri("http://localhost:8170") });
                //_serviceHost.AddServiceEndpoint(typeof(IHostingFrameworkService), new WSHttpBinding(), "HostingFramework_Test");
                _serviceHost.Open();
            }
        }

        public static void StopService()
        {
            if (_serviceHost != null)
            {
                _serviceHost.Close();
                _serviceHost = null;
            }
        }

        private static ServiceHost _serviceHost; //= null; (automatically initialized by runtime)
    }
}
