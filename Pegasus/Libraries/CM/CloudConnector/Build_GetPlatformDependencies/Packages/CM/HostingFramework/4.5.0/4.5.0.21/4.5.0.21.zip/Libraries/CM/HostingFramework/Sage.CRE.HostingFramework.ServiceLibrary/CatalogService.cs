﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using Sage.CRE.HostingFramework.Interfaces;
using Sage.CRE.HostingFramework.LinkedSource;
using System.IO;
using System.Reflection;

namespace Sage.CRE.HostingFramework.ServiceLibrary
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Multiple, ConfigurationName = "CatalogService")]
    public sealed class CatalogService : ICatalogService
    {
        #region ICatalogService Members

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ServiceInfo> GetServiceInfo()
        {
            IEnumerable<ServiceInfo> result = null;

            IHostSupervisor hostSupervisor = null;
            try
            {

                String hostingFrameworkServiceExeFilePath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "Sage.CRE.HostingFramework.Service.exe");
                ServiceConstants serviceConstants = ServiceConstantsFactory.GetConstants(hostingFrameworkServiceExeFilePath);
                hostSupervisor = ChannelFactory<IHostSupervisor>.CreateChannel(new NetNamedPipeBinding(), new EndpointAddress(String.Format("net.pipe://localhost/{0}_HostSupervisor", serviceConstants.Name)));
                result = hostSupervisor.GetServiceInfo();
                (hostSupervisor as ICommunicationObject).Close();
                hostSupervisor = null;

                // Project the ServiceInfo URI's (which presume use of the FQDN-name) back into using the host used by 
                // the client to reach us in the first place.  This is necessary in situations where the FQDN form of the
                // host name will not successfully DNS resolve on the client machine.
                Uri incomingMessageHeaderTo = System.ServiceModel.OperationContext.Current.IncomingMessageHeaders.To;
                List<ServiceInfo> fixedUpServiceInfo = new List<ServiceInfo>();
                foreach (var originalServiceInfo in result)
                {
                    fixedUpServiceInfo.Add(
                        new ServiceInfo(
                            originalServiceInfo.ConfigurationName,
                            originalServiceInfo.Description,
                            originalServiceInfo.AppDomainId,
                            originalServiceInfo.Uris.Select((x) =>
                            {
                                return (new UriBuilder(incomingMessageHeaderTo.Scheme, incomingMessageHeaderTo.Host, x.Port, x.PathAndQuery).Uri);
                            }).ToList()
                    ));
                }

                result = fixedUpServiceInfo;
            }
            catch (Exception)
            {
                if (hostSupervisor != null)
                {
                    (hostSupervisor as ICommunicationObject).Abort();
                }
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        public ServiceInfo GetServiceInfoByName(String serviceName)
        {
            IEnumerable<ServiceInfo> serviceInfos = GetServiceInfo();
            Dictionary<String, ServiceInfo> serviceInfoByName = serviceInfos.ToDictionary(delegate(ServiceInfo serviceInfoParam) { return serviceInfoParam.ConfigurationName; });
            return serviceInfoByName[serviceName];
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="scheme"></param>
        /// <returns></returns>
        public Uri GetServiceUri(String serviceName, String scheme)
        { return GetServiceWithAddressUri(serviceName, String.Empty, scheme); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="address"></param>
        /// <param name="scheme"></param>
        /// <returns></returns>
        public Uri GetServiceWithAddressUri(String serviceName, String address, String scheme)
        {
            ServiceInfo serviceInfo = GetServiceInfoByName(serviceName);

            IEnumerable<Uri> result = serviceInfo.Uris;
            if (!String.IsNullOrEmpty(address))
            {
                var addressEndingToMatch = String.Format("/{0}", address);
                result = result.Where(x => x.OriginalString.EndsWith(addressEndingToMatch));
            }

            return result.Where(x => x.Scheme == scheme).Single();
        }

        #endregion
    }
}
