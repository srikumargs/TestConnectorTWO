﻿using System;
using System.Collections.Generic;
using System.Net.Security;
using System.ServiceModel;

namespace Sage.CRE.HostingFramework.Interfaces
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceContract(SessionMode = SessionMode.Allowed, Namespace = Constants.SERVICE_NAMESPACE, ProtectionLevel = ProtectionLevel.EncryptAndSign)]
    public interface ICatalogService 
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        IEnumerable<ServiceInfo> GetServiceInfo();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        [OperationContract]
        ServiceInfo GetServiceInfoByName(String serviceName);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="scheme"></param>
        /// <returns></returns>
        [OperationContract]
        Uri GetServiceUri(String serviceName, String scheme);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceName"></param>
        /// <param name="address"></param>
        /// <param name="scheme"></param>
        /// <returns></returns>
        [OperationContract]
        Uri GetServiceWithAddressUri(String serviceName, String address, String scheme);
    }
}
