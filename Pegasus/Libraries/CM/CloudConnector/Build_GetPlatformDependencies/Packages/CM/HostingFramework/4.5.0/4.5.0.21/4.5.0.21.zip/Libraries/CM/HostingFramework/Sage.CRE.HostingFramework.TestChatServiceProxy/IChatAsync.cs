﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Security;
using System.ServiceModel;
using Sage.CRE.HostingFramework.TestChatServiceInterfaces;

namespace Sage.CRE.HostingFramework.TestChatServiceProxy
{
    /// <summary>
    /// Demonstrates how to turn a synchronous service contract method, implemented by the server, into an asynchronous method
    /// on the client side using the .NET asynchronous operation pattern. This pattern of inheriting from the "real" service 
    /// contract and adding asynchronous parallel methods to it is only needed if the client desires that capability. Otherwise
    /// they should simply utilize the "real" contract directly instead and completely forego even declaring this new contract.
    /// </summary>
    [ServiceContract(ProtectionLevel = ProtectionLevel.EncryptAndSign)]
    public interface IChatAsync : IChat
    {
        /// <summary>
        /// Join the chat room, asynchronously
        /// </summary>
        /// <param name="name">The user name to join as</param>
        /// <param name="callback"></param>
        /// <param name="asyncState"></param>
        /// <returns></returns>
        [OperationContractAttribute(AsyncPattern = true, Action = "http://Sage.CRE.HostingFramework.com/IChat/Join", ReplyAction = "http://Sage.CRE.HostingFramework.com/IChat/JoinResponse")]
        System.IAsyncResult BeginJoin(String name, System.AsyncCallback callback, Object asyncState);

        /// <summary>
        /// Complete the BeginJoin
        /// </summary>
        /// <param name="result"></param>
        /// <returns>List of user names of those already in the room</returns>
        String[] EndJoin(System.IAsyncResult result);
    }

}
