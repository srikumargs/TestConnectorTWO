﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Threading;
using Sage.CRE.HostingFramework.Interfaces;
using Sage.Diagnostics;
using Sage.ExtensionMethods;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    internal class RemoteServiceHostContainer : MarshalByRefObject
    {
        /// <summary>
        /// Override and return null to specify infinite lifetime for the singleton.
        /// </summary>
        public override object InitializeLifetimeService()
        {
            return null;
        }

        public virtual void Initialize(ServiceConfig serviceConfig)
        {
            Assertions.Assert(_serviceHosts == null);
            Assertions.Assert(!_started);

            _serviceConfig = serviceConfig;
        }

        public virtual void Start()
        {
            Assertions.Assert(_serviceHosts == null);
            Assertions.Assert(!_started);
            Assertions.Assert(_serviceConfig != null);

            if (_serviceHosts == null)
            {
                _serviceHosts = new Collection<ServiceHost>();
                foreach (ServiceActivationInfo serviceActivationInfo in _serviceConfig.Services.Values)
                {
                    Assembly serviceAssembly;
                    String serviceAssemblyName = serviceActivationInfo.AssemblyName;
                    String serviceActivationInfoTypeName = serviceActivationInfo.TypeName;
                    if (serviceAssemblyName.EndsWith(".DLL", StringComparison.InvariantCultureIgnoreCase) || serviceAssemblyName.EndsWith(".EXE", StringComparison.InvariantCultureIgnoreCase))
                    {
                        // assume that if the assembly name ends in a DLL, that we are using a file path ... not a local/GAC assembly
                        serviceAssembly = Assembly.LoadFrom(serviceAssemblyName);
                    }
                    else
                    {
                        // otherwise load using normal mechanism
                        serviceAssembly = Assembly.Load(serviceAssemblyName);
                    }

                    ServiceHost serviceHost;
                    Type serviceType = serviceAssembly.GetType(serviceActivationInfoTypeName);
                    if (serviceType.GetCustomAttributes(typeof(ServiceBehaviorAttribute), false).Cast<ServiceBehaviorAttribute>().Single().InstanceContextMode == InstanceContextMode.Single)
                    {
                        // Singleton services are constructed explicitly so that we can access the .SingletonInstance property to do start/stop control
                        Object service = serviceType.GetConstructor(new Type[] { }).Invoke(new Object[] { });
                        serviceHost = new ServiceHost(service, serviceActivationInfo.BaseAddresses);
                    }
                    else
                    {
                        serviceHost = new ServiceHost(serviceType, serviceActivationInfo.BaseAddresses);
                    }
                    CustomizeServiceHostEndpoints(serviceHost, 128);
                    serviceHost.CloseTimeout = new TimeSpan(0, 0, 5);
                    serviceHost.Faulted += new EventHandler(ServiceHostFaultedHandler);
                    serviceHost.UnknownMessageReceived += new EventHandler<UnknownMessageReceivedEventArgs>(ServiceHostUnknownMessageReceivedHandler);
                    if (serviceHost.Description.Endpoints.Count == 0)
                    {
                        // if no endpoints were defined, then assume this is an in-proc service only
                        // TODO: stop assuming the contract interface is IHostSupervisor!
                        serviceHost.AddServiceEndpoint(typeof(IHostSupervisor), new NetNamedPipeBinding(), serviceActivationInfo.BaseAddresses[0]);
                    }
                    _serviceHosts.Add(serviceHost);

                    UpdateSupervisor(serviceHost, CommunicationState.Created);
                }
            }

            if (!_started)
            {
                foreach (ServiceHost serviceHost in _serviceHosts)
                {
                    try
                    {
                        UpdateSupervisor(serviceHost, CommunicationState.Opening);

                        // Update static data to indicate that we are stopping
                        SetStaticData(AppDomainStaticDataKey.IsStopping, false);

                        Program.VerboseTraceWriteLine(this, "Opening '{0}' service plugin", serviceHost.Description.ConfigurationName);
                        serviceHost.Open();
                        Program.VerboseTraceWriteLine(this, "'{0}' service plugin opened", serviceHost.Description.ConfigurationName);

                        // Call explicit start method on singleton service if it has been specified using the SingletonServiceControl attribute
                        if (serviceHost.SingletonInstance != null)
                        {
                            Type serviceType = serviceHost.SingletonInstance.GetType();
                            var a = serviceType.GetCustomAttributes(typeof(SingletonServiceControlAttribute), false).Cast<SingletonServiceControlAttribute>().SingleOrDefault();
                            if (a != null && !String.IsNullOrEmpty(a.StartMethod))
                            {
                                MethodInfo methodInfo = serviceType.GetMethod(a.StartMethod, BindingFlags.Instance | BindingFlags.Public);
                                if (methodInfo != null)
                                {
                                    Program.VerboseTraceWriteLine(this, "Invoking start method '{0}' on '{1}' service plugin ", a.StartMethod, serviceHost.Description.ConfigurationName);
                                    methodInfo.Invoke(serviceHost.SingletonInstance, new Object[] { });
                                }
                            }
                        }


                        UpdateSupervisor(serviceHost, CommunicationState.Opened);
                    }
                    catch (Exception ex)
                    {
                        // TODO:  blacklist the service if it threw an exception; set system tray state
                        Program.WriteEventLogEntry(String.Format(CultureInfo.InvariantCulture, "Exception encountered opening service plugin '{0}'.\n\n{1}", serviceHost.Description.ConfigurationName, ex.ToString()), MessageType.Error);
                    }
                }

                _started = true;
            }
        }

        private static void CustomizeServiceHostEndpoints(ServiceHost serviceHost, Int32 maxPendingChannels)
        {
            foreach (ServiceEndpoint endpoint in serviceHost.Description.Endpoints)
            {
                BindingElementCollection bindingElements = endpoint.Binding.CreateBindingElements();

                ReliableSessionBindingElement reliableSessionElement = bindingElements.Find<ReliableSessionBindingElement>();
                if (reliableSessionElement != null)
                {
                    reliableSessionElement.MaxPendingChannels = maxPendingChannels;
                    CustomBinding customBinding = new CustomBinding(bindingElements);
                    // need to copy properties from existing binding to the new binding

                    // all other properties (e.g. security,encoder,transport) should be preserved and do not need to be copied
                    customBinding.CloseTimeout = endpoint.Binding.CloseTimeout;
                    customBinding.OpenTimeout = endpoint.Binding.OpenTimeout;
                    customBinding.ReceiveTimeout = endpoint.Binding.ReceiveTimeout;
                    customBinding.SendTimeout = endpoint.Binding.SendTimeout;
                    customBinding.Name = endpoint.Binding.Name;
                    customBinding.Namespace = endpoint.Binding.Namespace;
                    endpoint.Binding = customBinding;
                }
            }
        }

        public virtual void Stop()
        {
            Assertions.Assert(_serviceHosts != null);
            Assertions.Assert(_started);

            if (_started)
            {
                _closeCompleteEvents = new ManualResetEvent[_serviceHosts.Count];
                for (Int32 i = 0; i < _serviceHosts.Count; i++)
                {
                    ServiceHost serviceHost = _serviceHosts[i];
                    try
                    {
                        _closeCompleteEvents[i] = new ManualResetEvent(false);
                        if (serviceHost.State != CommunicationState.Faulted)
                        {
                            UpdateSupervisor(serviceHost, CommunicationState.Closing);

                            // Update static data to indicate that we are stopping
                            SetStaticData(AppDomainStaticDataKey.IsStopping, true);

                            // Call explicit stop method on singleton service if it has been specified using the SingletonServiceControl attribute
                            if (serviceHost.SingletonInstance != null)
                            {
                                Type serviceType = serviceHost.SingletonInstance.GetType();
                                var a = serviceType.GetCustomAttributes(typeof(SingletonServiceControlAttribute), false).Cast<SingletonServiceControlAttribute>().SingleOrDefault();
                                if (a != null && !String.IsNullOrEmpty(a.StopMethod))
                                {
                                    MethodInfo methodInfo = serviceType.GetMethod(a.StopMethod, BindingFlags.Instance | BindingFlags.Public);
                                    if (methodInfo != null)
                                    {
                                        Program.VerboseTraceWriteLine(this, "Invoking stop method '{0}' on '{1}' service plugin ", a.StopMethod, serviceHost.Description.ConfigurationName);
                                        methodInfo.Invoke(serviceHost.SingletonInstance, new Object[] { });
                                    }
                                }
                            }

                            Program.VerboseTraceWriteLine(this, "Closing '{0}' service plugin ", serviceHost.Description.ConfigurationName);
                            serviceHost.BeginClose(new TimeSpan(0, 0, 10), new AsyncCallback(OnEndClose), i);
                        }
                        else
                        {
                            Program.VerboseTraceWriteLine(this, "Aborting faulted '{0}' service plugin ", serviceHost.Description.ConfigurationName);
                            serviceHost.Abort();

                            UpdateSupervisor(serviceHost, CommunicationState.Closed);
                            _closeCompleteEvents[i].Set();
                        }
                    }
                    catch (Exception ex)
                    {
                        // TODO:  blacklist the service if it threw an exception; set system tray state
                        Program.WriteEventLogEntry(String.Format(CultureInfo.InvariantCulture, "Exception encountered closing service plugin '{0}'.\n\n{1}", serviceHost.Description.ConfigurationName, ex.ToString()), MessageType.Error);
                    }
                }

                WaitHandle.WaitAll(_closeCompleteEvents, new TimeSpan(0, 0, 10));

                _serviceHosts.Clear();
                _serviceHosts = null;

                _started = false;
            }
        }
        private void OnEndClose(IAsyncResult asyncResult)
        {
            try
            {
                Int32 index = (Int32)asyncResult.AsyncState;
                ServiceHost serviceHost = _serviceHosts[index];
                if (!asyncResult.IsCompleted)
                {
                    Program.VerboseTraceWriteLine(this, "'{0}' service plugin not closed; aborting", serviceHost.Description.ConfigurationName);
                    serviceHost.Abort();
                    Program.VerboseTraceWriteLine(this, "'{0}' service plugin aborted", serviceHost.Description.ConfigurationName);
                }

                UpdateSupervisor(serviceHost, CommunicationState.Closed);

                _closeCompleteEvents[index].Set();

                Program.VerboseTraceWriteLine(this, "'{0}' service plugin closed", serviceHost.Description.ConfigurationName);
            }
            catch (Exception ex)
            {
                Program.WriteEventLogEntry(String.Format(CultureInfo.InvariantCulture, "Exception encountered closing service plugin.\n\n{0}", ex.ToString()), MessageType.Error);
            }
        }

        private void UpdateSupervisor(ServiceHost serviceHost, CommunicationState serviceStatus)
        {
            if (serviceHost.Description.ServiceType != typeof(HostSupervisor))
            {
                IHostSupervisor hostSupervisor = null;
                try
                {
                    hostSupervisor = ChannelFactory<IHostSupervisor>.CreateChannel(new NetNamedPipeBinding(), new EndpointAddress(String.Format(Constants.HostSupervisorAddressFormat, InternalConfig.ServiceName)));

                    if (serviceStatus == CommunicationState.Created)
                    {
                        List<Uri> uris = new List<Uri>();
                        CollectionExtensions.ForEach(serviceHost.Description.Endpoints, delegate(ServiceEndpoint serviceEndpoint) { uris.Add(serviceEndpoint.Address.Uri); });
                        hostSupervisor.RegisterService(new ServiceInfo(serviceHost.Description.ConfigurationName, _serviceConfig.Services[serviceHost.Description.ConfigurationName].Description, _serviceConfig.AppDomainId, uris.AsReadOnly()));
                    }

                    hostSupervisor.UpdateServiceStatus(serviceHost.Description.ConfigurationName, serviceStatus);

                    if (serviceStatus == CommunicationState.Closed || serviceStatus == CommunicationState.Faulted)
                    {
                        hostSupervisor.UnregisterService(serviceHost.Description.ConfigurationName);
                    }

                    (hostSupervisor as ICommunicationObject).Close();
                    hostSupervisor = null;
                }
                catch (Exception ex)
                {
                    Program.WriteEventLogEntry(String.Format(CultureInfo.InvariantCulture, "Exception encountered updating host supervisor.\n\n{0}", ex.ToString()), MessageType.Error);

                    if (hostSupervisor != null)
                    {
                        (hostSupervisor as ICommunicationObject).Abort();
                    }
                }
            }
        }

        private void ServiceHostUnknownMessageReceivedHandler(Object sender, UnknownMessageReceivedEventArgs e)
        {
            Program.WriteEventLogEntry(String.Format(CultureInfo.InvariantCulture, "ServiceHostUnknownMessageReceivedHandler: sender={0}, e={1}", sender.ToString(), e.ToString()), MessageType.Error);
        }

        private void ServiceHostFaultedHandler(Object sender, EventArgs e)
        {
            Program.WriteEventLogEntry(String.Format(CultureInfo.InvariantCulture, "ServiceHostFaultedHandler: sender={0}, e={1}", sender.ToString(), e.ToString()), MessageType.Error);
            //TODO: recreate service host
        }

        private void SetStaticData(AppDomainStaticDataKey key, bool value)
        {
            SetStaticData(key, value.ToString(CultureInfo.InvariantCulture));
        }

        private void SetStaticData(AppDomainStaticDataKey key, string value)
        {
            AppDomainStaticData.Dictionary[key] = value;
        }

        #region Private fields
        private Boolean _started; // = false; (automatically initialized by runtime)
        private ServiceConfig _serviceConfig;
        private Collection<ServiceHost> _serviceHosts;
        private ManualResetEvent[] _closeCompleteEvents;
        #endregion
    }
}
