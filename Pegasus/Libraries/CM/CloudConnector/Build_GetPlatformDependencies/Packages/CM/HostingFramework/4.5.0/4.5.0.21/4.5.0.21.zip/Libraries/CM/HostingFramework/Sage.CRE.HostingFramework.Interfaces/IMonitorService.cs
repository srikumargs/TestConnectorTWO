﻿using System;
using System.Net.Security;
using System.ServiceModel;

namespace Sage.CRE.HostingFramework.Interfaces
{
    /// <summary>
    /// Provides information to the monitor
    /// </summary>
    [ServiceContract(SessionMode = SessionMode.Allowed, Namespace = Constants.SERVICE_NAMESPACE, ProtectionLevel = ProtectionLevel.EncryptAndSign)]
    public interface IMonitorService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [OperationContract(IsOneWay = false)]
        Version GetVersion();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>=
        [OperationContract(IsOneWay = false)]
        DateTime GetUpSinceDateTime();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [OperationContract(IsOneWay = false)]
        Status GetStatus();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [OperationContract(IsOneWay = false)]
        String GetServer();
    }
}
