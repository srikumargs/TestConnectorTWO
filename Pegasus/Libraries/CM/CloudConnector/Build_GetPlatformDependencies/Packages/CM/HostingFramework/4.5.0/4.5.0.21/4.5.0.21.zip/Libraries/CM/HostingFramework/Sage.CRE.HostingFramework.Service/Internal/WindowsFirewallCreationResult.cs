﻿namespace Sage.CRE.HostingFramework.Service.Internal
{
    public enum WindowsFirewallCreationResult
    {
        None = 0,

        Success,

        FirewallServiceNotRunning,

        ComponentActivationFailure
    }
}
