﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceProcess;
using System.Collections.Specialized;
using System.Collections;
using System.Security.Principal;
using System.Security.AccessControl;
using System.IO;
using Microsoft.Win32;
using System.Globalization;
using Sage.Diagnostics;
using Sage.CRE.HostingFramework.Interfaces;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    /// <summary>
    /// MSFT native error codes that we want to have explicit handling around
    /// </summary>
    internal enum UnderstoodNativeErrorCodes
    {
        /// <summary>
        /// Service account error
        /// </summary>
        ERROR_INVALID_SERVICE_ACCOUNT = 1057,

        /// <summary>
        /// Mapping of account error
        /// </summary>
        ERROR_NONE_MAPPED = 1332,

        /// <summary>
        /// Another possible service account error
        /// </summary>
        ERROR_TRUSTED_DOMAIN_FAILURE = 1332,

        /// <summary>
        /// Invalid login, likely a password issue
        /// </summary>
        ERROR_SERVICE_LOGON_FAILED = 1069
    }

    /// <summary>
    /// Type of config param we're interested in
    /// </summary>
    internal enum ConfigParamType
    {
        /// <summary>
        /// Default initializer value
        /// </summary>
        None = 0,
        
        /// <summary>
        /// Service account user 
        /// </summary>
        ServiceAccountUser,

        /// <summary>
        /// Service account password
        /// </summary>
        ServiceAccountPassword,

        /// <summary>
        /// Service start type
        /// </summary>
        ServiceStartType,

        /// <summary>
        /// Action to take on the service's first failure
        /// </summary>
        ServiceFirstFailureAction,

        /// <summary>
        /// Action to take on the service's second failure
        /// </summary>
        ServiceSecondFailureAction,

        /// <summary>
        /// Action to take on the service's subsequent failures
        /// After the first and second
        /// </summary>
        ServiceSubsequentFailureAction,

        /// <summary>
        /// Whether or not to delay an auto start for the service
        /// When option (OS-permitting) is available
        /// </summary>
        ServiceDelayedStart
    }

    /// <summary>
    /// Enumerate rules for the failure actions
    /// </summary>
    internal enum FailureActionRuleType
    {
        /// <summary>
        /// First failure
        /// </summary>
        First=0,

        /// <summary>
        /// Second failure
        /// </summary>
        Second,

        /// <summary>
        /// All subsequent failures
        /// </summary>
        Subsequent
    }


    /// <summary>
    /// Class for internal helper methods
    /// </summary>
    internal static class InternalUtils
    {
        #region Param Names

        /// <summary>
        /// Command line arg name for service account user
        /// </summary>
        public static readonly string ServiceAccountUserParam = "user";

        /// <summary>
        /// Command line arg name for service account password
        /// </summary>
        public static readonly string ServiceAccountPasswordParam = "password";

        /// <summary>
        /// Command line arg name for service start type
        /// </summary>
        public static readonly string ServiceStartTypeParam = "starttype";

        /// <summary>
        /// Command line arg name for first failure action
        /// </summary>
        public static readonly string ServiceFirstFailureActionParam = "firstfailure";

        /// <summary>
        /// Command line arg name for second failure action
        /// </summary>
        public static readonly string ServiceSecondFailureActionParam = "secondfailure";

        /// <summary>
        /// Command line arg name for subsequent failure action
        /// </summary>
        public static readonly string ServiceSubsequentFailureActionParam = "subsequentfailure";

        /// <summary>
        /// Command line arg name for delaying start for auto start services
        /// </summary>
        public static readonly string ServiceDelayedStartParam = "delayedstart";

        #endregion


        #region Conversion

        /// <summary>
        /// Given the string name for a service account, get the ServiceAccount enum
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static ServiceAccount GetServiceAccountFromString(string name)
        {
            if (!string.IsNullOrEmpty(name))
            {
                if (name.Equals("NetworkService", StringComparison.InvariantCultureIgnoreCase))
                {
                    // Use network service
                    return ServiceAccount.NetworkService;
                }

                if (name.Equals("LocalService", StringComparison.InvariantCultureIgnoreCase))
                {
                    // Use local service
                    return ServiceAccount.LocalService;
                }

                if (name.Equals("LocalSystem", StringComparison.InvariantCultureIgnoreCase))
                {
                    // Use local system
                    return ServiceAccount.LocalSystem;
                }

                // Use user account
                return ServiceAccount.User;
            }

            // Nothing specified: default to network service
            return ServiceAccount.NetworkService;
        }

        /// <summary>
        /// Given the string value for the service restart mode, get the ServiceStartMode enum
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static ServiceStartMode GetServiceStartModeFromString(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                if (value.Equals("automatic", StringComparison.InvariantCultureIgnoreCase))
                {
                    return ServiceStartMode.Automatic;
                }

                if (value.Equals("manual", StringComparison.InvariantCultureIgnoreCase))
                {
                    return ServiceStartMode.Manual;
                }

                if (value.Equals("disabled", StringComparison.InvariantCultureIgnoreCase))
                {
                    return ServiceStartMode.Disabled;
                }
            }

            // Nothing specified: default to automatic
            return ServiceStartMode.Automatic;
        }

        /// <summary>
        /// Given the string value for the failure action and they failure rule, get the SC_ACTION_TYPE enum
        /// </summary>
        /// <param name="failureActionRuleType"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static SC_ACTION_TYPE GetFailureActionTypeFromString(
            FailureActionRuleType failureActionRuleType, string value)
        {
            // Now interpret any passed in failure action
            if (!string.IsNullOrEmpty(value))
            {
                if (value.Equals("none", StringComparison.InvariantCultureIgnoreCase))
                {
                    return SC_ACTION_TYPE.SC_ACTION_NONE;
                }
                if (value.Equals("restart", StringComparison.InvariantCultureIgnoreCase))
                {
                    return SC_ACTION_TYPE.SC_ACTION_RESTART;
                }
                if (value.Equals("reboot", StringComparison.InvariantCultureIgnoreCase))
                {
                    return SC_ACTION_TYPE.SC_ACTION_REBOOT;
                }
            }

            // Nothing specified, return the default based on the rule type
            switch (failureActionRuleType)
            {
                case FailureActionRuleType.First:
                case FailureActionRuleType.Second:
                    return SC_ACTION_TYPE.SC_ACTION_RESTART;
                case FailureActionRuleType.Subsequent:
                    return SC_ACTION_TYPE.SC_ACTION_NONE;
                default:
                    // Unrecognized type
                    throw new ArgumentException(
                        "GetFailureActionTypeFromString: Unrecognized failure action rule type '{0}",
                        Enum.GetName(typeof(FailureActionRuleType), failureActionRuleType));
            }
        }

        /// <summary>
        /// Get the user name to use for directory security givent the service account user
        /// String provided in the paramters
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetUserNameFromServiceAccountUserString(string value)
        {
            string userName;
            switch (InternalUtils.GetServiceAccountFromString(value))
            {
                case ServiceAccount.LocalService:
                    userName = @"LOCAL SERVICE";
                    break;
                case ServiceAccount.LocalSystem:
                    userName = @"SYSTEM";
                    break;
                case ServiceAccount.User:
                    userName = value;
                    break;
                default:
                    userName = @"NETWORK SERVICE";
                    break;
            }

            return userName;
        }

        #endregion


        #region Directory Access

        /// <summary>
        /// Throw an exception if the current user does not have the expected
        /// Directory access
        /// </summary>
        /// <returns></returns>
        public static void ThrowIfUserAccessNotSet()
        {
            // The path we're interested in for app data access rights
            string path = InternalConfig.InstanceApplicationDataFolder;

            // The error file path
            string errorFilePath = InternalConfig.ServiceStartErrorResultFilePath;

            // Check if the current user has rights
            var rights = new Sage.IO.UserFileAccessRights(path);
            bool userHasRights =
                rights.canRead() &&
                rights.canWrite() &&
                rights.canCreateFiles() &&
                rights.canDelete() &&
                rights.canSynchronize() &&
                rights.canDeleteSubdirectoriesAndFiles() &&
                rights.canTraverse() &&
                rights.canExecuteFile();

            if (userHasRights)
            {
                // Delete the start error file if one exists
                if (File.Exists(errorFilePath))
                {
                    File.Delete(errorFilePath);
                }
            }
            else
            {
                // Write to event log
                Program.WriteEventLogEntry(
                    String.Format(
                        StringsCustomerFacing.ErrorServiceAccountUserDoesNotHaveFileAccessFormat,
                        path),
                    MessageType.Error);

                // Create the start error file if one does not exist
                if (!File.Exists(errorFilePath))
                {
                    File.WriteAllText(errorFilePath, "error");
                }

                // Throw an exception
                throw new Exception("Current user does not have proper file access rights");
            }
        }

        /// <summary>
        /// Determine if a startup error ocurred
        /// </summary>
        /// <returns></returns>
        public static Boolean StartupAccessErrorOccurred()
        {
            // Check for the presence of the startup error file
            bool errorOccurred = File.Exists(InternalConfig.ServiceStartErrorResultFilePath);

            return errorOccurred;
        }

        /// <summary>
        /// Setup directory access rights
        /// </summary>
        /// <param name="installContextLogWriter"></param>
        /// <param name="path"></param>
        /// <param name="removeUsersPermissionToAppData"></param>
        /// <param name="installContextParameters">Parameters used when calling install</param>
        /// <returns></returns>
        public static Boolean EnableAccountAccessToDirectory(
            TextWriter installContextLogWriter,
            String path,
            Boolean removeUsersPermissionToAppData,
            IDictionary installContextParameters)
        {
            Boolean result = false;

            DirectorySecurity ds = new DirectorySecurity();
            ds.SetAccessRuleProtection(true, false);

            String userName = String.Empty;
            if (!removeUsersPermissionToAppData)
            {
                userName = String.Format(@"Users", Environment.MachineName);
                try
                {
                    // Administrators
                    ds.AddAccessRule(new FileSystemAccessRule(userName,
                        FileSystemRights.ReadAndExecute | FileSystemRights.ListDirectory | FileSystemRights.Read,
                        InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit,
                        PropagationFlags.None,
                        AccessControlType.Allow));
                }
                catch (IdentityNotMappedException ex)
                {
                    installContextLogWriter.WriteLine(String.Format("Failed to AddAccessRule('{0}'); ex = {1}", userName, ex.ToString()));
                }
            }

            userName = String.Format(@"Administrators", Environment.MachineName);
            try
            {
                // Administrators
                ds.AddAccessRule(new FileSystemAccessRule(userName,
                    FileSystemRights.FullControl,
                    InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit,
                    PropagationFlags.None,
                    AccessControlType.Allow));
            }
            catch (IdentityNotMappedException ex)
            {
                installContextLogWriter.WriteLine(String.Format("Failed to AddAccessRule('{0}'); ex = {1}", userName, ex.ToString()));
            }

            // NOTE:  this should match whatever account is used for _serviceProcessInstaller.Account
            var user = InternalUtils.GetConfigValue(ConfigParamType.ServiceAccountUser, installContextParameters);
            userName = InternalUtils.GetUserNameFromServiceAccountUserString(user);

            try
            {
                ds.AddAccessRule(new FileSystemAccessRule(userName,
                    InternalConfig.ServiceAccountUserFileSystemRights,
                    InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit,
                    PropagationFlags.None,
                    AccessControlType.Allow));

                result = true;
            }
            catch (IdentityNotMappedException ex)
            {
                installContextLogWriter.WriteLine(String.Format("Failed to AddAccessRule('{0}'); ex = {1}", userName, ex.ToString()));
            }

            Directory.SetAccessControl(path, ds);

            if (removeUsersPermissionToAppData)
            {
                try
                {
                    DirectorySecurity sec = Directory.GetAccessControl(path);
                    SecurityIdentifier sid = new SecurityIdentifier(WellKnownSidType.BuiltinUsersSid, null);
                    sec.PurgeAccessRules(sid);
                    Directory.SetAccessControl(path, sec);
                }
                catch (IdentityNotMappedException ex)
                {
                    installContextLogWriter.WriteLine(String.Format("Failed to PurgeAccessRules('{0}'); ex = {1}", WellKnownSidType.BuiltinUsersSid, ex.ToString()));
                }
            }


            return result;
        }

        #endregion


        #region Public Config Param Methods

        /// <summary>
        /// Generic getter for a config value
        /// Either from the command line args, or failing that from the config XML
        /// </summary>
        /// <param name="configParamType"></param>
        /// <param name="stringDictionary"></param>
        /// <returns></returns>
        public static String GetConfigValue(ConfigParamType configParamType, StringDictionary stringDictionary)
        {
            // Get the config param name for this type
            string configParamName = GetConfigParamName(configParamType);

            // Get the command line param value, if any
            string commandLineValue = null;

            // Need to loop to do an ignore case comparison
            foreach (string key in stringDictionary.Keys)
            {
                if (key.Equals(configParamName, StringComparison.InvariantCultureIgnoreCase))
                {
                    commandLineValue = stringDictionary[key];
                    break;
                }
            }

            // Send to the common logic
            return GetConfigValueImpl(configParamType, commandLineValue);
        }

        /// <summary>
        /// Generic getter for a config value
        /// Either from the command line args, or failing that from the config XML
        /// </summary>
        /// <param name="configParamType"></param>
        /// <param name="dictionary"></param>
        /// <returns></returns>
        public static String GetConfigValue(ConfigParamType configParamType, IDictionary dictionary)
        {
            // Get the config param name for this type
            string configParamName = GetConfigParamName(configParamType);

            // Get the command line param value, if any
            string commandLineValue = null;
            try
            {
                // Need to loop to do an ignore case comparison
                foreach (string key in dictionary.Keys)
                {
                    if (key.Equals(configParamName, StringComparison.InvariantCultureIgnoreCase))
                    {
                        commandLineValue = (string) dictionary[key];
                        break;
                    }
                }
            }
            catch
            {
                // Catch any casting issues
            }

            // Send to the common logic
            return GetConfigValueImpl(configParamType, commandLineValue);
        }

        /// <summary>
        /// Generic getter for a config value
        /// This version is used by config options other than install
        /// It only checks the arg list for the provided list for the requested argument
        /// And does NOT check the instance config file if there is no provided command line value.
        /// String requested should be of the format "/param"
        /// </summary>
        /// <param name="commandLineArgName"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public static String GetConfigValue(string commandLineArgName, List<string> args)
        {
            string result = null;
            if (args != null)
            {
                foreach (string arg in args)
                {
                    if (arg.StartsWith(commandLineArgName))
                    {
                        try
                        {
                            // Parse out the value
                            result = arg.Substring(arg.IndexOf('=') + 1);

                            // Remove quotes
                            result = result.Trim('"');

                            // Done
                            break;
                        }
                        catch
                        {
                            // Any format error is ignored   
                        }
                    }
                }
            }

            return result;
        }

        #endregion


        #region Private Config Param Methods

        /// <summary>
        /// Common logic for selecting the service account password
        /// </summary>
        /// <param name="configParamType"></param>
        /// <param name="commandLineValue"></param>
        /// <returns></returns>
        private static String GetConfigValueImpl(ConfigParamType configParamType, String commandLineValue)
        {
            // Default: null and let the programmatic default be used
            string finalValue = null;

            if (!string.IsNullOrEmpty(commandLineValue))
            {
                // Use the command line value if provided
                finalValue = commandLineValue;
            }

            else
            {
                string instanceConfigValue = GetInstanceConfigValue(configParamType);
                if (!string.IsNullOrEmpty(instanceConfigValue))
                {
                    // Use the instance config value if provided
                    finalValue = instanceConfigValue;
                }
            }

            if (configParamType == ConfigParamType.ServiceAccountUser)
            {
                // Adjust potentially bad login string format
                finalValue = ReplaceDotSlashWithMachineName(finalValue);
            }

            return finalValue;
        }

        /// <summary>
        /// Format login
        /// </summary>
        /// <param name="login"></param>
        /// <returns></returns>
        private static String ReplaceDotSlashWithMachineName(string login)
        {
            string result = login;

            if (!string.IsNullOrEmpty(login))
            {
                // Special case logic for the service account user config param:
                // Install does not work with ".\X", must convert params of that form to "MachineName\X"
                if (login.StartsWith(@".\"))
                {
                    // Replace the . with the machine name
                    result = login.Remove(0, 1).Insert(0, Environment.MachineName);
                }
            }

            return result;
        }

        /// <summary>
        /// Get the param name for the given config param type
        /// </summary>
        /// <param name="configParamType"></param>
        /// <returns></returns>
        private static String GetConfigParamName(ConfigParamType configParamType)
        {
            switch (configParamType)
            {
                case ConfigParamType.ServiceAccountUser:
                    return ServiceAccountUserParam;
                case ConfigParamType.ServiceAccountPassword:
                    return ServiceAccountPasswordParam;
                case ConfigParamType.ServiceStartType:
                    return ServiceStartTypeParam;
                case ConfigParamType.ServiceFirstFailureAction:
                    return ServiceFirstFailureActionParam;
                case ConfigParamType.ServiceSecondFailureAction:
                    return ServiceSecondFailureActionParam;
                case ConfigParamType.ServiceSubsequentFailureAction:
                    return ServiceSubsequentFailureActionParam;
                case ConfigParamType.ServiceDelayedStart:
                    return ServiceDelayedStartParam;
                default:
                    // Unrecognized type
                    throw new ArgumentException(
                        "GetConfigParamName: Unrecognized config param type '{0}",
                        Enum.GetName(typeof(ConfigParamType), configParamType));
            }
        }

        /// <summary>
        /// Get the instance config value for the given config param type
        /// </summary>
        /// <param name="configParamType"></param>
        /// <returns></returns>
        private static String GetInstanceConfigValue(ConfigParamType configParamType)
        {
            switch (configParamType)
            {
                case ConfigParamType.ServiceAccountUser:
                    return InternalConfig.ServiceAccountUser;
                case ConfigParamType.ServiceAccountPassword:
                    return InternalConfig.ServiceAccountPassword;
                case ConfigParamType.ServiceStartType:
                    return InternalConfig.ServiceStartType;
                case ConfigParamType.ServiceFirstFailureAction:
                    return InternalConfig.ServiceFirstFailureAction;
                case ConfigParamType.ServiceSecondFailureAction:
                    return InternalConfig.ServiceSecondFailureAction;
                case ConfigParamType.ServiceSubsequentFailureAction:
                    return InternalConfig.ServiceSubsequentFailureAction;
                case ConfigParamType.ServiceDelayedStart:
                    return InternalConfig.ServiceDelayedStart;
                default:
                    // Unrecognized type
                    throw new ArgumentException(
                        "GetInstanceConfigValue: Unrecognized config param type '{0}",
                        Enum.GetName(typeof(ConfigParamType), configParamType));
            }
        }

        #endregion
    }
}
