﻿namespace Sage.CRE.HostingFramework.Service.Internal
{
    internal enum ConfigCommand
    {
        None = 0,
        Install,
        Uninstall,
        Start,
        Stop, 
        Restart,

        /// <summary>
        /// Run the hosting framework as a console app (rather than as a service)
        /// </summary>
        ConsoleRun,

        /// <summary>
        /// Signal the running console app to stop
        /// </summary>
        ConsoleStop
    }
}
