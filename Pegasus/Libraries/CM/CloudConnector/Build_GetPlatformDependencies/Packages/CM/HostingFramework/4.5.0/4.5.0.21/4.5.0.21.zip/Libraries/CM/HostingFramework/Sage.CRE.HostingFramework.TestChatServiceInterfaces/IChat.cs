﻿using System;
using System.Net.Security;
using System.ServiceModel;

namespace Sage.CRE.HostingFramework.TestChatServiceInterfaces
{
    /// <summary>
    /// Interface for defining operations of the ChatService. Clients interested in
    /// receiving events should register with the ChatSubscriptionService.
    /// </summary>
    [ServiceContract(SessionMode = SessionMode.Allowed, Namespace = "http://Sage.CRE.HostingFramework.com", ProtectionLevel = ProtectionLevel.EncryptAndSign)]
    public interface IChat
    {
        /// <summary>
        /// Join the chat room
        /// </summary>
        /// <param name="name">The user name to join as</param>
        /// <returns>List of user names of those already in the room</returns>
        [OperationContract(IsOneWay = false)]
        String[] Join(String name);

        /// <summary>
        /// Say something to the room
        /// </summary>
        /// <param name="name">The user name of the person saying something</param>
        /// <param name="message"></param>
        [OperationContract(IsOneWay = true)]
        void Say(String name, String message);

        /// <summary>
        /// Leave the chat room
        /// </summary>
        /// <param name="name">The user name of the person leaving</param>
        [OperationContract(IsOneWay = true)]
        void Leave(String name);
    }
}
