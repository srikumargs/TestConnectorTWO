﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage.CRE.HostingFramework.Interfaces
{
    /// <summary>
    /// Types of results we can get from running install, start, etc.
    /// </summary>
    public enum ExitCode
    {
        /// <summary>
        /// Started successfully
        /// </summary>
        Success = 0,

        /// <summary>
        /// Failed, generic case
        /// </summary>
        Fail,

        /// <summary>
        /// Failed due to an invalid login
        /// </summary>
        FailInvalidLogin,

        /// <summary>
        /// Either the account name does not exist, or it is invalid for our purposes
        /// </summary>
        FailAccountNameInvalid,

        /// <summary>
        /// The account the service is running as does not have the expected
        /// Access to the app data folder created on install
        /// </summary>
        FailAccountFolderAccess,

        /// <summary>
        /// On a call to start or restart, we failed to get the "ready" status from
        /// The service in the prescribed amount of time, and after the requested
        /// Number of retry attempts
        /// </summary>
        FailWaitForServiceReady,

        /// <summary>
        /// Provide an unknown value
        /// Do not set this one to zero as normal for "none" enum
        /// Since a zero exit code is associated with success
        /// </summary>
        Unknown = 99
    }
}
