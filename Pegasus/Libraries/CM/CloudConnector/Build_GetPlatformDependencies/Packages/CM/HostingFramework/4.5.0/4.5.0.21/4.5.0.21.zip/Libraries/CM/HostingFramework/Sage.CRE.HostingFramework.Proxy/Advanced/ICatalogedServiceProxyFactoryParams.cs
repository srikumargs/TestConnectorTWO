﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Sage.CRE.HostingFramework.Proxy.Advanced
{
    /// <summary>
    /// Parameters class that is used by the CatalogedServiceProxyFactory generic class
    /// </summary>
    /// <typeparam name="TServiceProxy"></typeparam>
    public interface ICatalogedServiceProxyFactoryParams<TServiceProxy>
    {
        /// <summary>
        /// The name of the service as it appears in the catalog
        /// </summary>
        String ServiceName
        { get; }

        /// <summary>
        /// Create the service proxy at the specified endpoint address
        /// </summary>
        /// <param name="endpointAddress">The endpoint for the service</param>
        /// <param name="instanceContext">An optional parameter used to supply an instance context for callback interfaces (can be null)</param>
        /// <returns></returns>
        TServiceProxy Create(EndpointAddress endpointAddress, InstanceContext instanceContext);
    }
}
