﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    internal enum SC_ACTION_TYPE : uint
    {
        /// <summary>
        /// No action
        /// </summary>
        SC_ACTION_NONE = 0x00000000,

        /// <summary>
        /// Restart the service
        /// </summary>
        SC_ACTION_RESTART = 0x00000001,

        /// <summary>
        /// Reboot the computer
        /// </summary>
        SC_ACTION_REBOOT = 0x00000002,

        /// <summary>
        /// Run a command
        /// </summary>
        SC_ACTION_RUN_COMMAND = 0x00000003
    }

    /// <summary>
    /// Class to represent a failure action which consists of a recovery
    /// action type and an action delay
    /// </summary>
    internal sealed class FailureAction
    {
        #region Constructors
        public FailureAction(SC_ACTION_TYPE actionType, UInt32 actionDelay)
        {
            _type = actionType;
            _delay = actionDelay;
        }
        #endregion

        #region Public properties
        public SC_ACTION_TYPE Type
        { get { return _type; } }

        public UInt32 Delay
        { get { return _delay; } }
        #endregion

        #region Private fields
        private SC_ACTION_TYPE _type = SC_ACTION_TYPE.SC_ACTION_NONE;
        private UInt32 _delay = 0;
        #endregion
    }

    internal static class ServiceControlManager
    {
        static public void UpdateServiceConfig(TextWriter installContextLogWriter, String serviceName, String serviceDescription, ReadOnlyCollection<FailureAction> failureActions)
        {
            installContextLogWriter.WriteLine("Begin UpdateServiceConfig");

            IntPtr serviceControlManagerHandle = IntPtr.Zero;
            IntPtr serviceDatabaseLockHandle = IntPtr.Zero;
            IntPtr serviceHandle = IntPtr.Zero;
            IntPtr serviceFailureActionsPtr = IntPtr.Zero;
            IntPtr actionPtr = IntPtr.Zero;
            IntPtr serviceDescriptionPtr = IntPtr.Zero;

            try
            {
                // Open the service control manager
                serviceControlManagerHandle = OpenSCManager(null, null, ServiceControlAccessRights.SC_MANAGER_CONNECT | ServiceControlAccessRights.SC_MANAGER_LOCK);
                if (serviceControlManagerHandle == IntPtr.Zero)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Failed to OpenSCManager");
                }

                // Lock the Service Database
                serviceDatabaseLockHandle = LockServiceDatabase(serviceControlManagerHandle);
                if (serviceDatabaseLockHandle == IntPtr.Zero)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Failed to LockServiceDatabase");
                }

                // Open the service
                serviceHandle = OpenService(serviceControlManagerHandle, serviceName, ServiceAccessRights.SERVICE_CHANGE_CONFIG | ServiceAccessRights.SERVICE_START);
                if (serviceHandle == IntPtr.Zero)
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Failed to OpenService");
                }

                // Do we need to set service failure actions? Note that the API lets us set as many as
                // we want, yet the Service Control Manager GUI only lets us see the first 3.
                if (failureActions != null && failureActions.Count > 0)
                {
                    // Allocate memory for the individual actions
                    actionPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(SC_ACTION)) * failureActions.Count);

                    Boolean needShutdownPrivilege = false;
                    for (Int32 index = 0; index < failureActions.Count; index++)
                    {
                        SC_ACTION action = new SC_ACTION();
                        action.Type = failureActions[index].Type;
                        action.Delay = failureActions[index].Delay;
                        Marshal.StructureToPtr(action, (IntPtr)((Int64)actionPtr + (index * Marshal.SizeOf(typeof(SC_ACTION)))), false);

                        // Record whether or not any actions are of type "reboot".  If so, then this process
                        // needs to request the SeShutdownPrivilege before trying to configure the service
                        // with the failure actions via ChangeServiceConfig2.
                        if (action.Type == SC_ACTION_TYPE.SC_ACTION_REBOOT)
                        {
                            needShutdownPrivilege = true;
                        }
                    }

                    // If we need shutdown privilege, then grant it to this process
                    if (needShutdownPrivilege)
                    {
                        PrivilegeManager.GrantShutdownPrivilege(installContextLogWriter);
                    }

                    // Setup the failure actions
                    SERVICE_FAILURE_ACTIONS serviceFailureActions = new SERVICE_FAILURE_ACTIONS();
                    serviceFailureActions.dwResetPeriod = 0;
                    serviceFailureActions.lpRebootMsg = "";
                    serviceFailureActions.lpCommand = "";
                    serviceFailureActions.cActions = Convert.ToUInt32(failureActions.Count);
                    serviceFailureActions.lpsaActions = actionPtr;

                    serviceFailureActionsPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(SERVICE_FAILURE_ACTIONS)));
                    Marshal.StructureToPtr(serviceFailureActions, serviceFailureActionsPtr, false);

                    // Change the failure actions
                    Int32 changeResult = ChangeServiceConfig2(serviceHandle, ServiceConfig2InfoLevel.SERVICE_CONFIG_FAILURE_ACTIONS, serviceFailureActionsPtr);
                    if (changeResult == 0)
                    {
                        throw new Win32Exception(Marshal.GetLastWin32Error(), "Failed to ChangeServiceConfig2(SERVICE_CONFIG_FAILURE_ACTIONS)");
                    }

                    installContextLogWriter.WriteLine("ChangeServiceConfig2(SERVICE_CONFIG_FAILURE_ACTIONS) completed successfully for failure actions");
                }

                // Do we need to set the description field?
                if (!String.IsNullOrEmpty(serviceDescription))
                {
                    SERVICE_DESCRIPTION serviceDescriptionAsStruct = new SERVICE_DESCRIPTION();
                    serviceDescriptionAsStruct.lpDescription = serviceDescription;

                    serviceDescriptionPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(SERVICE_DESCRIPTION)));
                    Marshal.StructureToPtr(serviceDescriptionAsStruct, serviceDescriptionPtr, false);

                    // Change the service description
                    int changeResult = ChangeServiceConfig2(serviceHandle, ServiceConfig2InfoLevel.SERVICE_CONFIG_DESCRIPTION, serviceDescriptionPtr);
                    if (changeResult == 0)
                    {
                        throw new Win32Exception(Marshal.GetLastWin32Error(), "Failed to ChangeServiceConfig2(SERVICE_CONFIG_DESCRIPTION)");
                    }

                    installContextLogWriter.WriteLine("ChangeServiceConfig2(SERVICE_CONFIG_DESCRIPTION) completed successfully for service description");
                }

                installContextLogWriter.WriteLine("UpdateServiceConfig completed successfully");
            }
            finally
            {
                if (serviceFailureActionsPtr != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(serviceFailureActionsPtr);
                    serviceFailureActionsPtr = IntPtr.Zero;
                }

                if (actionPtr != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(actionPtr);
                    actionPtr = IntPtr.Zero;
                }

                if (serviceDescriptionPtr != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(serviceDescriptionPtr);
                    serviceDescriptionPtr = IntPtr.Zero;
                }

                if (serviceControlManagerHandle != IntPtr.Zero)
                {
                    if (serviceDatabaseLockHandle != IntPtr.Zero)
                    {
                        UnlockServiceDatabase(serviceDatabaseLockHandle);
                        serviceDatabaseLockHandle = IntPtr.Zero;
                    }

                    CloseServiceHandle(serviceControlManagerHandle);
                    serviceControlManagerHandle = IntPtr.Zero;
                }

                // Close the service handle
                if (serviceHandle != IntPtr.Zero)
                {
                    CloseServiceHandle(serviceHandle);
                    serviceHandle = IntPtr.Zero;
                }
            }
        }

        #region Private P/Invoke signatures & types
        // Don't reference other Sage assemblies (e.g., Sage.PInvoke) in code that runs during install

        private const String ADVAPI32 = "advapi32.dll";

        [StructLayout(LayoutKind.Sequential)]
        private struct SERVICE_DESCRIPTION
        {
            public String lpDescription;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SC_ACTION
        {
            [MarshalAs(UnmanagedType.U4)]
            public SC_ACTION_TYPE Type;
            [MarshalAs(UnmanagedType.U4)]
            public UInt32 Delay;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SERVICE_FAILURE_ACTIONS
        {
            [MarshalAs(UnmanagedType.U4)]
            public UInt32 dwResetPeriod;
            [MarshalAs(UnmanagedType.LPStr)]
            public String lpRebootMsg;
            [MarshalAs(UnmanagedType.LPStr)]
            public String lpCommand;
            [MarshalAs(UnmanagedType.U4)]
            public UInt32 cActions;
            public IntPtr lpsaActions;
        }

        [Flags]
        private enum ServiceControlAccessRights : int
        {
            /// <summary>
            /// Required to connect to the service control manager.  
            /// </summary>
            SC_MANAGER_CONNECT = 0x0001,

            /// <summary>
            /// Required to call the CreateService function to create a service object and add it to the database. 
            /// </summary>
            SC_MANAGER_CREATE_SERVICE = 0x0002,

            /// <summary>
            /// Required to call the EnumServicesStatusEx function to list the services that are in the database. 
            /// </summary>
            SC_MANAGER_ENUMERATE_SERVICE = 0x0004,

            /// <summary>
            /// Required to call the LockServiceDatabase function to acquire a lock on the database. 
            /// </summary>
            SC_MANAGER_LOCK = 0x0008,

            /// <summary>
            /// Required to call the QueryServiceLockStatus function to retrieve the lock status information for the database.
            /// </summary>
            SC_MANAGER_QUERY_LOCK_STATUS = 0x0010,

            /// <summary>
            /// Required to call the NotifyBootConfigStatus function. 
            /// </summary>
            SC_MANAGER_MODIFY_BOOT_CONFIG = 0x0020,

            /// <summary>
            /// Includes STANDARD_RIGHTS_REQUIRED, in addition to all access rights in this table. 
            /// </summary>
            SC_MANAGER_ALL_ACCESS = 0xF003F
        }

        [Flags]
        private enum ServiceAccessRights : int
        {
            /// <summary>
            /// Required to call the QueryServiceConfig and QueryServiceConfig2 functions to query the service configuration. 
            /// </summary>
            SERVICE_QUERY_CONFIG = 0x0001,

            /// <summary>
            /// Required to call the ChangeServiceConfig or ChangeServiceConfig2 function to change the service configuration. Because this grants the caller the right to change the executable file that the system runs, it should be granted only to administrators. 
            /// </summary>
            SERVICE_CHANGE_CONFIG = 0x0002,

            /// <summary>
            /// Required to call the QueryServiceStatusEx function to ask the service control manager about the status of the service. 
            /// </summary>
            SERVICE_QUERY_STATUS = 0x0004,

            /// <summary>
            /// Required to call the EnumDependentServices function to enumerate all the services dependent on the service. 
            /// </summary>
            SERVICE_ENUMERATE_DEPENDENTS = 0x0008,

            /// <summary>
            /// Required to call the StartService function to start the service. 
            /// </summary>
            SERVICE_START = 0x0010,

            /// <summary>
            /// Required to call the ControlService function to stop the service. 
            /// </summary>
            SERVICE_STOP = 0x0020,

            /// <summary>
            /// Required to call the ControlService function to pause or continue the service. 
            /// </summary>
            SERVICE_PAUSE_CONTINUE = 0x0040,

            /// <summary>
            /// Required to call the ControlService function to ask the service to report its status immediately. 
            /// </summary>
            SERVICE_INTERROGATE = 0x0080,

            /// <summary>
            /// Required to call the ControlService function to specify a user-defined control code.
            /// </summary>
            SERVICE_USER_DEFINED_CONTROL = 0x0100,

            /// <summary>
            /// Includes STANDARD_RIGHTS_REQUIRED in addition to all access rights in this table. 
            /// </summary>
            SERVICE_ALL_ACCESS = 0xF01FF
        }

        private enum ServiceConfig2InfoLevel : int
        {
            /// <summary>
            /// The lpBuffer parameter is a pointer to a SERVICE_DESCRIPTION structure.
            /// </summary>
            SERVICE_CONFIG_DESCRIPTION = 0x00000001,

            /// <summary>
            /// The lpBuffer parameter is a pointer to a SERVICE_FAILURE_ACTIONS structure.
            /// </summary>
            SERVICE_CONFIG_FAILURE_ACTIONS = 0x00000002
        }

        [DllImport(ADVAPI32, SetLastError = true)]
        private static extern IntPtr OpenSCManager(String lpMachineName, String lpDatabaseName, ServiceControlAccessRights desiredAccess);

        [DllImport(ADVAPI32, SetLastError = true)]
        private static extern IntPtr OpenService(IntPtr hSCManager, String lpServiceName, ServiceAccessRights desiredAccess);

        [DllImport(ADVAPI32, SetLastError = true)]
        private static extern int ChangeServiceConfig2(IntPtr hService, ServiceConfig2InfoLevel dwInfoLevel, IntPtr lpInfo);

        [DllImport(ADVAPI32, SetLastError = true)]
        private static extern bool CloseServiceHandle(IntPtr hSCObject);

        [DllImport(ADVAPI32, SetLastError = true)]
        private static extern IntPtr LockServiceDatabase(IntPtr hSCManager);

        [DllImport(ADVAPI32, SetLastError = true)]
        private static extern bool UnlockServiceDatabase(IntPtr hSCManager);
        #endregion
    }
}
