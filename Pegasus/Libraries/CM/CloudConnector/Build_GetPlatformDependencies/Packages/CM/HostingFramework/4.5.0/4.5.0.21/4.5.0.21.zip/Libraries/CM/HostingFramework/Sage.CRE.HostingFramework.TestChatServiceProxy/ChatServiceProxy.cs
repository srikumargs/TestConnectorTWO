﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sage.ServiceModel;

namespace Sage.CRE.HostingFramework.TestChatServiceProxy
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class ChatServiceProxy : RetryClientBase<IChatAsync>, IChatAsync
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="rawProxyCreationFunction"></param>
        public ChatServiceProxy(RetryClientBase<IChatAsync>.CreationFunction rawProxyCreationFunction)
            : base(rawProxyCreationFunction)
        { }

        #region IChatAsync Members

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="callback"></param>
        /// <param name="asyncState"></param>
        /// <returns></returns>
        public IAsyncResult BeginJoin(String name, AsyncCallback callback, object asyncState)
        { return (IAsyncResult)RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.BeginJoin(name, callback, asyncState); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <returns></returns>
        public String[] EndJoin(IAsyncResult result)
        { return (String[])RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.EndJoin(result); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public String[] Join(String name)
        { return (String[])RetvalCallRawProxy((RetvalMethodInvoker)delegate() { return RawProxy.Join(name); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="msg"></param>
        public void Say(String name, String msg)
        { VoidCallRawProxy((VoidMethodInvoker)delegate() { RawProxy.Say(name, msg); }); }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        public void Leave(String name)
        { VoidCallRawProxy((VoidMethodInvoker)delegate() { RawProxy.Leave(name); }); }

        #endregion
    }
}
