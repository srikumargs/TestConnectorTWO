﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage.CRE.HostingFramework.Interfaces
{
    /// <summary>
    /// Used on singleton WCF services (i.e., those with InstanceContextMode.Single) to describe 
    /// which methods should be invoked when the service starts or stops.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class SingletonServiceControlAttribute : Attribute
    {
        /// <summary>
        /// 
        /// </summary>
        public SingletonServiceControlAttribute()
        { }

        /// <summary>
        /// The name of the public instance method that should be called on service startup
        /// </summary>
        public String StartMethod
        { get; set; }

        /// <summary>
        /// The name of the public instance method that should be called on service shutdown
        /// </summary>
        public String StopMethod
        { get; set; }
    }
}
