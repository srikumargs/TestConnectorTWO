﻿using System;
using System.Runtime.Serialization;

namespace Sage.CRE.HostingFramework.Interfaces
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    [Flags]
    public enum Status
    {
        /// <summary>
        /// 
        /// </summary>
        [EnumMember]
        Ready = 0x1,

        /// <summary>
        /// 
        /// </summary>
        [EnumMember]
        SevicingRequest = 0x2,

        /// <summary>
        /// 
        /// </summary>
        [EnumMember]
        Recycling = 0x4
    }
}
