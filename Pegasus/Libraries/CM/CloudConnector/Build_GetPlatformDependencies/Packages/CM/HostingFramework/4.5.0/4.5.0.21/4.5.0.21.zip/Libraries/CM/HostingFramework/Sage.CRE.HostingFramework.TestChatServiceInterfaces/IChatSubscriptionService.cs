﻿using System.ServiceModel;
using System.Net.Security;
using Sage.SystemModel;

namespace Sage.CRE.HostingFramework.TestChatServiceInterfaces
{
    /// <summary>
    /// Interface for subscribing to the IChatCallback events triggered by the ChatService.
    /// </summary>
    /// <remarks>
    /// Although this interface defines no methods, it is needed so that the appropriate CallbackContract
    /// can be identified.
    /// </remarks>
    [ServiceContract(SessionMode = SessionMode.Required, CallbackContract = typeof(IChatCallback), Namespace = "http://Sage.CRE.HostingFramework.com", ProtectionLevel = ProtectionLevel.EncryptAndSign)]
    public interface IChatSubscriptionService : ISubscriptionService
    { }
}
