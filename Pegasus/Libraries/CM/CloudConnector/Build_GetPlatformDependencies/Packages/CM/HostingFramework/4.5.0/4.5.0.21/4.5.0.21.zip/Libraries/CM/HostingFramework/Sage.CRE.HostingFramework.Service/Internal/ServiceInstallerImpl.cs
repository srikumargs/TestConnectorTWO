﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using Microsoft.Win32;
using NetFw;
using Sage.Diagnostics;

namespace Sage.CRE.HostingFramework.Service.Internal
{
    internal sealed class ServiceInstallerImpl : MarshalByRefObject
    {
        #region Constructors
        /// <summary>
        /// Creates a new instance of the HostInstallerImpl class.
        /// </summary>
        public ServiceInstallerImpl()
        {}
        #endregion

        #region Installer overrides
        /// <summary>
        /// Performs the installation.  Executed before the Installer.Install() method is called.
        /// </summary>
        /// <remarks>
        /// Overridden in order to:
        /// - check to make certain we are not installing to a substituted or mapped drive as this will
        ///   not work for a service since substitution/mapping information is maintained on a per-user basis.
        /// </remarks>
        /// <param name="installContextLogWriter"></param>
        /// <param name="installContextParameters">The InstallContext.Parameters, in a ListDictionary instead of a StringDictionary</param>
        /// <param name="stateSaver">An IDictionary used to save information needed to perform a commit, rollback, or uninstall operation.</param>
        public void BeforeInstall(TextWriter installContextLogWriter, IDictionary installContextParameters, IDictionary stateSaver)
        {
            installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "Begin {0}.BeforeInstall() (CodeBase={1})", _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            try
            {
                String assemblyPath = (String) installContextParameters["assemblypath"];

                // Get the user
                String user = InternalUtils.GetConfigValue(ConfigParamType.ServiceAccountUser, installContextParameters);

                // Get the service account type associated with this user
                ServiceAccount serviceAccount = InternalUtils.GetServiceAccountFromString(user);

                // Possible that the user entered no user and we have the default stock account
                // Make sure that the log shows the default that we're using
                string password = null;
                if (serviceAccount != ServiceAccount.User)
                {
                    user = Enum.GetName(typeof (ServiceAccount), serviceAccount);
                }
                else if (!string.IsNullOrEmpty(InternalUtils.GetConfigValue(ConfigParamType.ServiceAccountPassword, installContextParameters)))
                {
                    // Get the password, only applicable to user account
                    // Just show as hidden text
                    password = new string('*', 8);
                }

                // Get other command line or instance config specific values
                string serviceStartType = InternalUtils.GetConfigValue(ConfigParamType.ServiceStartType, installContextParameters);
                string serviceFirstFailureAction = InternalUtils.GetConfigValue(ConfigParamType.ServiceFirstFailureAction, installContextParameters);
                string serviceSecondFailureAction = InternalUtils.GetConfigValue(ConfigParamType.ServiceSecondFailureAction, installContextParameters);
                string serviceSubsequentFailureAction = InternalUtils.GetConfigValue(ConfigParamType.ServiceSubsequentFailureAction, installContextParameters);
                bool serviceDelayedStart = false;
                Boolean.TryParse(
                    InternalUtils.GetConfigValue(ConfigParamType.ServiceDelayedStart, installContextParameters),
                    out serviceDelayedStart);

                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "assemblyPath={0}", assemblyPath));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "user={0}", (string.IsNullOrEmpty(user)) ? "null" : user));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "password={0}", (string.IsNullOrEmpty(password)) ? "null" : password));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "serviceStartType={0}", (string.IsNullOrEmpty(serviceStartType)) ? "null" : serviceStartType));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "serviceDelayedStart={0}", serviceDelayedStart));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "serviceFirstFailureAction={0}", (string.IsNullOrEmpty(serviceFirstFailureAction)) ? "null" : serviceFirstFailureAction));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "serviceSecondFailureAction={0}", (string.IsNullOrEmpty(serviceSecondFailureAction)) ? "null" : serviceSecondFailureAction));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "serviceSubsequentFailureAction={0}", (string.IsNullOrEmpty(serviceSubsequentFailureAction)) ? "null" : serviceSubsequentFailureAction));

                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "ServiceDescription={0}", InternalConfig.ServiceDescription));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "ServiceDisplayName={0}", InternalConfig.ServiceDisplayName));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "ServiceExeFilePath={0}", InternalConfig.ServiceExeFilePath));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "ServiceFileName={0}", InternalConfig.ServiceFileName));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "ServiceName={0}", InternalConfig.ServiceName));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "ServiceProcessRunningMutexName={0}", InternalConfig.ServiceProcessRunningMutexName));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "ServiceReadyMutexName={0}", InternalConfig.ServiceReadyMutexName));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "ServiceRegistrySubKey={0}", InternalConfig.ServiceRegistrySubKey));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "HostingFrameworkServicesFolder={0}", InternalConfig.HostingFrameworkServicesFolder));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "ServiceVersion={0}", InternalConfig.ServiceVersion));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "RemoveUsersPermissionToAppData={0}", InternalConfig.RemoveUsersPermissionToAppData));
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "BlockApplicationIncomingConnections={0}", InternalConfig.BlockApplicationIncomingConnections));

                if(assemblyPath != null && !PathIsToNonSubstAndNonMappedDrive(assemblyPath))
                {
                    throw new InstallException(String.Format(CultureInfo.InvariantCulture, "Assembly path '{0}' is not a local non-substituted and non-mapped drive.  This is an invalid service installation condition.  Installation incomplete.", assemblyPath));
                }
                if (serviceAccount == ServiceAccount.User && string.IsNullOrEmpty(password))
                {
                    // User account without credentials provided
                    throw new InstallException("Must provide a password when installing with a user account.  Installation incomplete.");
                }
                if (serviceAccount == ServiceAccount.User && user != null && user.Length <= 1)
                {
                    // Special case:
                    // Msft's service installer throws an exception when given a
                    // One character account name
                    installContextLogWriter.WriteLine("User account name must be greater than one character in length");
                    throw new Win32Exception((Int32)UnderstoodNativeErrorCodes.ERROR_INVALID_SERVICE_ACCOUNT);
                }
            }
            catch(Exception ex)
            {
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "An exception occurred during installation:\n\n{0}", ex.ToString()));
                throw;
            }
            finally
            {
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "End {0}.BeforeInstall() (CodeBase={1})", _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            }
        }

        /// <summary>
        /// Completes the install transaction.  Executed after the Installer.Commit() method is called.
        /// </summary>
        /// <remarks>
        /// Overridden in order to:
        /// - provide a descrption for the service
        /// - invoke the custom business-logic installer addin
        /// </remarks>
        /// <param name="installContextLogWriter"></param>
        /// <param name="installContextParameters">The InstallContext.Parameters, in a ListDictionary instead of a StringDictionary</param>
        /// <param name="stateSaver">An IDictionary used to save information needed to perform a commit, rollback, or uninstall operation.</param>
        public void AfterCommit(TextWriter installContextLogWriter, IDictionary installContextParameters, IDictionary stateSaver)
        {
            installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "Begin {0}.AfterCommit() (CodeBase={1})", _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            try 
            {
                Directory.CreateDirectory(InternalConfig.InstanceApplicationDataFolder);

                if (InternalUtils.EnableAccountAccessToDirectory(installContextLogWriter, InternalConfig.InstanceApplicationDataFolder, InternalConfig.RemoveUsersPermissionToAppData, installContextParameters))
                {
                    installContextLogWriter.WriteLine(String.Format(@"Successfully enabled service account access to '{0}'", InternalConfig.InstanceApplicationDataFolder));
                }
                else
                {
                    installContextLogWriter.WriteLine(String.Format(@"Failed to enable service account access to '{0}'", InternalConfig.InstanceApplicationDataFolder));
                }

                
                RegistryKey subKey = Registry.LocalMachine.OpenSubKey(InternalConfig.ServiceRegistrySubKey, true);
                if(subKey == null)
                {
                    installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "Failed to LocalMachine.OpenSubKey('{0}')", InternalConfig.ServiceRegistrySubKey));
                }
                else
                {
                    // Give this user read access to the services registry (so that it can read its own values)
                    var user = InternalUtils.GetConfigValue(ConfigParamType.ServiceAccountUser, installContextParameters);
                    var userName = InternalUtils.GetUserNameFromServiceAccountUserString(user);
                    var rs = new RegistrySecurity();
                    rs.AddAccessRule(new RegistryAccessRule(userName, RegistryRights.ReadKey, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.NoPropagateInherit, AccessControlType.Allow));
                    subKey.SetAccessControl(rs);

                    // Set the ErrorControl setting to not display an error message box if the service fails to start
                    // on reboot.  This can happen because it takes "too long" (as far as the SCM is concerned) ... although
                    // everything may be functioning properly.  Prevents user seeing message box when running on older systems.
                    //
                    // set to SERVICE_ERROR_IGNORE (The startup program logs the error but continues the startup operation.)
                    subKey.SetValue("ErrorControl", 0);

                    subKey.Close();
                }

                // Get the failure actions string provided
                string firstFailureActionString = InternalUtils.GetConfigValue(
                    ConfigParamType.ServiceFirstFailureAction, installContextParameters);
                string secondFailureActionString = InternalUtils.GetConfigValue(
                    ConfigParamType.ServiceSecondFailureAction, installContextParameters);
                string subsequentFailureActionString = InternalUtils.GetConfigValue(
                    ConfigParamType.ServiceSubsequentFailureAction, installContextParameters);

                // Convert failure action strings to enums
                SC_ACTION_TYPE firstFailureAction =
                    InternalUtils.GetFailureActionTypeFromString(FailureActionRuleType.First, firstFailureActionString);
                SC_ACTION_TYPE secondFailureAction =
                    InternalUtils.GetFailureActionTypeFromString(FailureActionRuleType.Second, secondFailureActionString);
                SC_ACTION_TYPE subsequentFailureAction =
                    InternalUtils.GetFailureActionTypeFromString(FailureActionRuleType.Subsequent, subsequentFailureActionString);

                // Provide description for service and configure the failure (.e., auto-recovery) actions.
                UInt32 failureActionDelay = Convert.ToUInt32(TimeSpan.FromMinutes(1).TotalMilliseconds);
                var failureActions = 
                    new List<FailureAction>
                    {
                        new FailureAction(firstFailureAction, failureActionDelay),
                        new FailureAction(secondFailureAction, failureActionDelay),
                        new FailureAction(subsequentFailureAction, failureActionDelay)
                    };
                ServiceControlManager.UpdateServiceConfig(
                    installContextLogWriter, 
                    InternalConfig.ServiceName, 
                    InternalConfig.ServiceDescription, 
                    failureActions.AsReadOnly());


                /*
                // Generate some random bytes ... these can be used for cryptographic services.
                byte[] randomBytes = new byte[8];
                Random random = new Random((int) (System.DateTime.Now.Ticks & 0xFFFFFFFF));
                random.NextBytes(randomBytes);


                // load late-bound installer code (if any)
                TypeFactoryReader typeFactoryReader = GetInstallPluginTypeFactoryReader(installContextLogWriter, installContextParameters);

                // invoke the late-bound installer code
                TypeFactory typeFactory = (TypeFactory) typeFactoryReader.TypeFactoriesByTypeLookup["IInstallServiceHost"];
                if(typeFactory != null)
                {
                    IInstallServiceHost installServiceHost = (IInstallServiceHost) typeFactory.GetObject();
                    if(installServiceHost == null)
                    {
                        installContextLogWriter.WriteLine(@"Failed to create IInstallServiceHost");
                    }
                    else
                    {
                        installServiceHost.AfterCommit(installContextLogWriter, installContextParameters, stateSaver, randomBytes);
                    }
                }

                CreateTypeRegistryFile(installContextLogWriter, installContextParameters, randomBytes);
                 * */

                if (!WindowsFirewallConfiguration.AddApplicationRule(installContextLogWriter, InternalConfig.ServiceDisplayName, InternalConfig.ServiceExeFilePath, InternalConfig.BlockApplicationIncomingConnections ? FirewallAPI.NET_FW_ACTION_.NET_FW_ACTION_BLOCK : FirewallAPI.NET_FW_ACTION_.NET_FW_ACTION_ALLOW))
                {
                    if (!InternalConfig.BlockApplicationIncomingConnections)
                    {
                        WindowsFirewallCreationResult creationResult = WindowsFirewallCreationResult.None;
                        INetFwMgr firewallManager = WindowsFirewallConfiguration.TryCreateFirewallManager(out creationResult);
                        if (creationResult == WindowsFirewallCreationResult.Success)
                        {
                            WindowsFirewallConfigurationResult configurationResult = WindowsFirewallConfiguration.AddApplicationException(firewallManager.LocalPolicy.CurrentProfile, InternalConfig.ServiceExeFilePath);
                            if (configurationResult == WindowsFirewallConfigurationResult.Success)
                            {
                                installContextLogWriter.WriteLine(String.Format(@"Successfully added Windows Firewall application exception for '{0}'", InternalConfig.ServiceExeFilePath));
                            }
                            else
                            {
                                installContextLogWriter.WriteLine(String.Format(@"Failed to add Windows Firewall application exception for '{0}'; result was '{1}'.", InternalConfig.ServiceExeFilePath, configurationResult));
                            }
                        }
                        else
                        {
                            installContextLogWriter.WriteLine(String.Format(@"Failed to create Windows Firewall Manager component; result was '{0}'.", creationResult));
                        }
                    }
                    else
                    {
                        installContextLogWriter.WriteLine(String.Format(@"Skipped creation of Windows Firewall application exception because incoming connections are intentionally prohibited for this service."));
                    }
                }

                installContextLogWriter.WriteLine(String.Format(@"Creating event log source {0} in {1} log.", InternalConfig.ServiceDisplayName, EventLogger.LogName));

                EventLogger.CreateEventLogSource(EventLogger.LogName, InternalConfig.ServiceDisplayName);
            }
            catch(Exception ex)
            {
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "An exception occurred during installation:\n\n{0}", ex.ToString()));
                throw;
            }
            finally
            {
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "End {0}.AfterCommit() (CodeBase={1})", _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            }
        }

        /// <summary>
        /// Removes an installation.  Executed after the Installer.Uninstall() method is called.
        /// </summary>
        /// <remarks>
        /// Overridden in order to:
        /// - invoke the custom business-logic uninstaller addin
        /// </remarks>
        /// <param name="installContextLogWriter"></param>
        /// <param name="installContextParameters">The InstallContext.Parameters, in a ListDictionary instead of a StringDictionary</param>
        /// <param name="savedState">An IDictionary that contains the post-installation state of the computer.</param>
        public void AfterUninstall(TextWriter installContextLogWriter, IDictionary installContextParameters, IDictionary savedState)
        {
            installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "Begin {0}.AfterUninstall() (CodeBase={1})", _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            try 
            {
                //// load late-bound installer code (if any)
                //TypeFactoryReader typeFactoryReader = GetInstallPluginTypeFactoryReader(installContextLogWriter, installContextParameters);

                //// invoke the late-bound installer code
                //TypeFactory typeFactory = (TypeFactory) typeFactoryReader.TypeFactoriesByTypeLookup["IInstallServiceHost"];
                //if(typeFactory != null)
                //{   
                //    IInstallServiceHost installServiceHost = (IInstallServiceHost) typeFactory.GetObject();
                //    if(installServiceHost == null)
                //    {
                //        installContextLogWriter.WriteLine(@"Failed to create IInstallServiceHost");
                //    }
                //    else
                //    {
                //        installServiceHost.AfterUninstall(installContextLogWriter, installContextParameters, savedState);
                //    }
                //}

                //RemoveTypeRegistryFile(installContextLogWriter);

                if (!WindowsFirewallConfiguration.RemoveApplicationExceptionAdvanced(installContextLogWriter, InternalConfig.ServiceDisplayName))
                {
                    WindowsFirewallCreationResult creationResult = WindowsFirewallCreationResult.None;
                    INetFwMgr firewallManager = WindowsFirewallConfiguration.TryCreateFirewallManager(out creationResult);
                    if (creationResult == WindowsFirewallCreationResult.Success)
                    {
                        WindowsFirewallConfigurationResult configurationResult = WindowsFirewallConfiguration.RemoveApplicationException(firewallManager.LocalPolicy.CurrentProfile, InternalConfig.ServiceExeFilePath);
                        if (configurationResult == WindowsFirewallConfigurationResult.Success)
                        {
                            installContextLogWriter.WriteLine(String.Format(@"Successfully removed Windows Firewall application exception for '{0}'", InternalConfig.ServiceExeFilePath));
                        }
                        else
                        {
                            installContextLogWriter.WriteLine(String.Format(@"Failed to remove Windows Firewall application exception for '{0}'; result was '{1}'.", InternalConfig.ServiceExeFilePath, configurationResult));
                        }
                    }
                    else
                    {
                        installContextLogWriter.WriteLine(String.Format(@"Failed to create Windows Firewall Manager component; result was '{0}'.", creationResult));
                    }
                }
            }
            catch(Exception ex)
            {
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "An exception occurred during installation:\n\n{0}", ex.ToString()));
                throw;
            }
            finally
            {
                installContextLogWriter.WriteLine(String.Format(CultureInfo.InvariantCulture, "End {0}.AfterUninstall() (CodeBase={1})", _myTypeName, Assembly.GetExecutingAssembly().CodeBase));
            }
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Examines the installContextParameters to see if the "sage.CRE.servicehost.installplugin" parameter was supplied.  If it was, then
        /// return a type factory reader for it.  If it wasn't supplied, then return the type factory asssociated with
        /// the TypeRegistry.dat encrypted Xml file.
        /// </summary>
        /// <param name="installContextLogWriter"></param>
        /// <param name="installContextParameters">The InstallContext.Parameters, in a ListDictionary instead of a StringDictionary</param>
        /// <returns>a TypeFactoryReader</returns>
        //private TypeFactoryReader GetInstallPluginTypeFactoryReader(TextWriter installContextLogWriter, IDictionary installContextParameters)
        //{
        //    string typeRegistryXml = @"<TypeRegistry><ServiceHost></ServiceHost></TypeRegistry>";
        //    if(installContextParameters.Contains(InstallContextParameterNames.InstallPlugin))
        //    {
        //        string xmlFragment = (installContextParameters[InstallContextParameterNames.InstallPlugin] as string);
        //        typeRegistryXml = string.Format(CultureInfo.InvariantCulture, @"<TypeRegistry><ServiceHost>{0}</ServiceHost></TypeRegistry>", xmlFragment);

        //        installContextLogWriter.WriteLine(string.Format(CultureInfo.InvariantCulture, "Using install plugin information from install context:  {0}", xmlFragment));
        //    }
        //    XmlDocument document = new XmlDocument();
        //    document.LoadXml(typeRegistryXml);
        //    XmlNode installPluginActivationNode = document.SelectSingleNode(@"//TypeRegistry/ServiceHost");

        //    return new TypeFactoryReader(installPluginActivationNode);
        //}

        /// <summary>
        /// Uses specified install context parameters to create the TypeRegistry.dat encrypted Xml file.
        /// </summary>
        /// <param name="installContextLogWriter"></param>
        /// <param name="installContextParameters">The InstallContext.Parameters, in a ListDictionary instead of a StringDictionary</param>
        /// <param name="installBytes"></param>
        //private static void CreateTypeRegistryFile(TextWriter installContextLogWriter, IDictionary installContextParameters, byte[] installBytes)
        //{
        //    string typeRegistryXmlFormat = @"<TypeRegistry><InstallBytes value='{0}'/><ServiceHost></ServiceHost></TypeRegistry>";
        //    string typeRegistryXml = string.Format(CultureInfo.InvariantCulture, typeRegistryXmlFormat, Convert.ToBase64String(installBytes));
        //    if(installContextParameters.Contains(InstallContextParameterNames.TypeRegistry))
        //    {
        //        string xmlFragment = (installContextParameters[InstallContextParameterNames.TypeRegistry] as string);
        //        typeRegistryXml = string.Format(CultureInfo.InvariantCulture, @"<TypeRegistry><InstallBytes value='{0}'/><ServiceHost>{1}</ServiceHost></TypeRegistry>", Convert.ToBase64String(installBytes), xmlFragment);

        //        installContextLogWriter.WriteLine(string.Format(CultureInfo.InvariantCulture, "Using type registry information from install context:  {0}", xmlFragment));
        //    }
        //    XmlDocument document = new XmlDocument();
        //    document.LoadXml(typeRegistryXml);

        //    if(File.Exists(TypeRegistry.TypeRegistryFilePath))
        //    {
        //        // turn off read-only attribute
        //        File.SetAttributes(TypeRegistry.TypeRegistryFilePath, (File.GetAttributes(TypeRegistry.TypeRegistryFilePath) & ~FileAttributes.ReadOnly));
        //    }

        //    // create the file
        //    Directory.CreateDirectory(Path.GetDirectoryName(TypeRegistry.TypeRegistryFilePath));
        //    CryptoXmlSerializer.EncryptXmlDocumentToBinaryFile(document, CryptoAlgorithm.DES, CryptoConstants.Key, CryptoConstants.IV, TypeRegistry.TypeRegistryFilePath);

        //    installContextLogWriter.WriteLine(string.Format(CultureInfo.InvariantCulture, "Created {0}", TypeRegistry.TypeRegistryFilePath));
        //}

        /// <summary>
        /// Removes the TypeRegistry.dat encrypted Xml file created at install time.
        /// </summary>
        /// <param name="installContextLogWriter"></param>
        //private static void RemoveTypeRegistryFile(TextWriter installContextLogWriter)
        //{
        //    if(File.Exists(TypeRegistry.TypeRegistryFilePath))
        //    {
        //        // turn off read-only attribute
        //        File.SetAttributes(TypeRegistry.TypeRegistryFilePath, (File.GetAttributes(TypeRegistry.TypeRegistryFilePath) & ~FileAttributes.ReadOnly));

        //        // delete the file
        //        File.Delete(TypeRegistry.TypeRegistryFilePath);

        //        installContextLogWriter.WriteLine(string.Format(CultureInfo.InvariantCulture, "Removed {0}", TypeRegistry.TypeRegistryFilePath));
        //    }
        //}

        /// <summary>
        /// Returns whether the specified path is a path to a local drive letter that is not mapped or subst'ed 
        /// </summary>
        /// <param name="path">the path to test</param>
        /// <returns>true if the path is a path to a local drive letter that is not mapped or subst'ed; otherwise false</returns>
        /// <remarks>Function copied from PathUtils in Sage.STO.Core in order to prevent reference to that assembly at Install time</remarks>
        private static Boolean PathIsToNonSubstAndNonMappedDrive(String path)
        {
            //Don't use Sage.CRE.Core.dll during install
            //ArgumentValidator.ValidateNonEmptyString(path, "path", "PathUtils.PathIsToNonSubstAndNonMappedDrive");

            Boolean result = false;

            if(path != null && path.Length >= 3 && path[1] == ':')
            {
                String driveWithoutTrailingSlash = path.Substring(0, 2);

                StringBuilder buffer = new StringBuilder(260);

                DriveInfo driveInfo = new DriveInfo(driveWithoutTrailingSlash);
                switch(driveInfo.DriveType)
                {
                    case DriveType.Fixed:
                        if(QueryDosDevice(driveWithoutTrailingSlash, buffer, (UInt32) buffer.Capacity) > 0)
                        {
                            // substituted drives will report back with a string beginning with \??\
                            if(!buffer.ToString().StartsWith(@"\??\"))
                            {
                                result = true;
                            }
                        }
                        else
                        {
                            //Don't use Sage.CRE.Core.dll during install
                            //Assertions.Assert(false, string.Format(CultureInfo.InvariantCulture, "QueryDosDevice() failed;  error={0}", Marshal.GetLastWin32Error())); 
                        }
                        break;
                }
            }

            return result;
        }

        
        #endregion

        // Don't reference other Sage assemblies (e.g., Sage.PInvoke) in code that runs during install
        [DllImport(KERNEL32, SetLastError = true)]
        private static extern Int32 QueryDosDevice(String lpDeviceName, [Out] System.Text.StringBuilder lpTargetPath, UInt32 ucchMax);

        #region Private fields
        private const String KERNEL32 = "Kernel32.dll";
        private static String _myTypeName = typeof(ServiceInstallerImpl).FullName;

        //private static class InstallContextParameterNames
        //{
        //    public const string InstallPlugin = "sage.CRE.servicehost.installplugin";
        //    public const string TypeRegistry = "sage.CRE.servicehost.typeregistry";
        //}
        #endregion
    }
}
