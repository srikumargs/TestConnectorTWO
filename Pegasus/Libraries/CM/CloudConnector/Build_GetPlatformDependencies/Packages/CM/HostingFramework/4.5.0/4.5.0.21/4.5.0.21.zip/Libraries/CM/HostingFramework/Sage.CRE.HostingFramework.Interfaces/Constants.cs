﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sage.CRE.HostingFramework.Interfaces
{
    /// <summary>
    /// 
    /// </summary>
    public static class Constants
    {
        // NOTE: If you change the namespace name "http://Sage.CRE.HostingFramework.comm" here, you must also update the reference to "http://Sage.CRE.HostingFramework.com" in App.config and Web.config.

        /// <summary>
        /// 
        /// </summary>
        public const String SERVICE_NAMESPACE = "http://Sage.CRE.HostingFramework.com";
    }
}
