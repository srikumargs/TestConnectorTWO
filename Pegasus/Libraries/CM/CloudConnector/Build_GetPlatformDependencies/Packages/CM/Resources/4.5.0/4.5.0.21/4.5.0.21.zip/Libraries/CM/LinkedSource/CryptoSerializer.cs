using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Xml;

#if !NO_SAGE_DIAGNOSTICS_REFERENCE
using Sage.Diagnostics;
#endif

// This source file resides in the "LinkedSource" source code folder in order to enable multiple assemblies
// to shared the implementation without requiring the Cryptography class to be exposed as a public
// type of any shared assembly.
//
// Requires:
//  - Sage.CRE.Core.dll (unless NO_SAGE_DIAGNOSTICS_REFERENCE is defined)
//  - %SAGE_SANDBOX%\Libraries\Sage\CRE\LinkedSource\Cryptography.cs
namespace Sage.CRE.LinkedSource
{
    /// <summary>
    /// Class used to provide cryptography services for files
    /// </summary>
    internal static class CryptoSerializer
    {
        #region Public methods
        /// <summary>
        /// Encrypts the provided string and writes the encrypted result to a binary file
        /// </summary>
        /// <param name="unencryptedString">The string to encrypt</param>
        /// <param name="cryptoAlgorithm">The crypto algorithm.</param>
        /// <param name="key">The encryption key</param>
        /// <param name="iv">The iv.</param>
        /// <param name="destinationPath">The file path to the destination where the encrypted contents should be written</param>
        public static void EncryptStringToBinaryFile(String unencryptedString, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv, String destinationPath)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoSerializer).FullName + ".EncryptStringToBinaryFile");
            ArgumentValidator.ValidateNonEmptyString(unencryptedString, "unencryptedString", typeof(CryptoSerializer).FullName + ".EncryptStringToBinaryFile");
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoSerializer).FullName + ".EncryptStringToBinaryFile");
#endif

            WriteBytesToBinaryFile(destinationPath, Cryptography.EncryptStringToBytes(unencryptedString, cryptoAlgorithm, key, iv));
        }

        /// <summary>
        /// Encrypts the provided string and writes the encrypted result to a binary file
        /// </summary>
        /// <param name="unencryptedString">The string to encrypt</param>
        /// <param name="cryptoAlgorithm">The crypto algorithm.</param>
        /// <param name="key">The encryption key</param>
        /// <param name="iv">The initial value.</param>
        /// <param name="destinationPath">The file path to the destination where the encrypted contents should be written</param>
        public static void EncryptStringToBinaryFile(String unencryptedString, CryptoAlgorithm cryptoAlgorithm, Byte[] key, out Byte[] iv, String destinationPath)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoSerializer).FullName + ".EncryptStringToBinaryFile");
            ArgumentValidator.ValidateNonEmptyString(unencryptedString, "unencryptedString", typeof(CryptoSerializer).FullName + ".EncryptStringToBinaryFile");
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoSerializer).FullName + ".EncryptStringToBinaryFile");
#endif

            WriteBytesToBinaryFile(destinationPath, Cryptography.EncryptStringToBytes(unencryptedString, cryptoAlgorithm, key, out iv));
        }

        /// <summary>
        /// Reads a binary file, unencrypts it, and returns the contents as a string
        /// </summary>
        /// <param name="sourcePath">The file path to the source from which the encrypted contents should be read</param>
        /// <param name="cryptoAlgorithm">The crypto algorithm.</param>
        /// <param name="key">The encryption key</param>
        /// <param name="iv">The initial value.</param>
        /// <returns>The unencrytped string</returns>
        public static string DecryptBinaryFileToString(String sourcePath, CryptoAlgorithm cryptoAlgorithm, Byte[] key, Byte[] iv)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonNullReference(key, "key", typeof(CryptoSerializer).FullName + ".DecryptBinaryFileToString");
            ArgumentValidator.ValidateNonEmptyString(sourcePath, "sourcePath", typeof(CryptoSerializer).FullName + ".DecryptBinaryFileToString");
#endif

            return Cryptography.DecryptBytesToString(ReadBytesFromBinaryFile(sourcePath), cryptoAlgorithm, key, iv);
        }

        /// <summary>
        /// Writes provided bytes to the specified binary file
        /// </summary>
        /// <param name="destinationPath">The file path to the destination where the bytes should be written</param>
        /// <param name="bytes">The bytes to write</param>
        public static void WriteBytesToBinaryFile(String destinationPath, Byte[] bytes)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateNonEmptyString(destinationPath, "destinationPath", typeof(CryptoSerializer).FullName + ".WriteBytesToBinaryFile");
            ArgumentValidator.ValidateNonNullReference(bytes, "bytes", typeof(CryptoSerializer).FullName + ".WriteBytesToBinaryFile");
#endif

            using(Stream stream = File.Open(destinationPath, FileMode.Create))
            {
                using(BinaryWriter writer = new BinaryWriter(stream))
                {
                    writer.Write(bytes);
                }
            }
        }

        /// <summary>
        /// Reads bytes from the specified binary file
        /// </summary>
        /// <param name="sourcePath">The file path to the source from which the bytes should be read</param>
        /// <returns>The bytes that were read</returns>
        public static byte[] ReadBytesFromBinaryFile(String sourcePath)
        {
#if !NO_SAGE_DIAGNOSTICS_REFERENCE
            ArgumentValidator.ValidateFileExists(sourcePath, "sourcePath", typeof(CryptoSerializer).FullName + ".ReadBytesFromBinaryFile");
#endif

            Byte[] bytes = null;
            if(File.Exists(sourcePath))
            {
                using(FileStream stream = new FileStream(sourcePath, FileMode.Open, FileAccess.Read))
                {
                    using(BinaryReader reader = new BinaryReader(stream))
                    {
                        bytes = reader.ReadBytes((int) stream.Length);
                    }
                }
            }

            return bytes;
        }
        #endregion
    }
}
