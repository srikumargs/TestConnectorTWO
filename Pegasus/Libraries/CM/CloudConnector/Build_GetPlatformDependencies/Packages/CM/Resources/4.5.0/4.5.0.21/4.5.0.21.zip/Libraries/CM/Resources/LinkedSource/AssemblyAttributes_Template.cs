using System.Reflection;
using System.Runtime.CompilerServices;
using System.Resources;

[assembly: AssemblyCompany("TAG_CREBuildSystem_Company")]
[assembly: AssemblyCopyright("TAG_CREBuildSystem_Copyright")]
[assembly: AssemblyTrademark("TAG_CREBuildSystem_Trademark")]
[assembly: AssemblyConfiguration("TAG_CREBuildSystem_Configuration")]

// AssemblyVersion changes only by release
[assembly: AssemblyVersion("TAG_CREBuildSystem_AssemblyVersion")]

// AssemblyFileVersion and AssemblyInformationalVersion change with each build
[assembly: AssemblyFileVersion("TAG_CREBuildSystem_FileVersion")]
[assembly: AssemblyInformationalVersion("TAG_CREBuildSystem_AssemblyInformationalVersion")]

[assembly: NeutralResourcesLanguageAttribute("en-US")]
